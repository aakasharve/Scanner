﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Options;
using Moq;
using Shouldly;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Xunit;

namespace Neighborly.Chassis.EtagCache
{
   
    public class EtagCacheValidateTests
    {
        private static string _id = "ServiceAppointmentId:model";
        private static string _serviceName = "_Template_Service";      
        [Fact]
        public void EtagCacheValidatePut()
        {
            var opts = Options.Create<MemoryDistributedCacheOptions>(new MemoryDistributedCacheOptions());
            IDistributedCache cache = new MemoryDistributedCache(opts);
            var request = new Mock<HttpRequest>();
            request.SetupGet(r => r.ContentType).Returns("application/json");
            HttpContext httpContextn = new DefaultHttpContext();
            httpContextn.Request.Method = "PUT";
            var routeData = new RouteData();
            routeData.Values.Add("ServiceAppointmentId", "dfcdsvfdhh");
            var actionDescriptor = new ControllerActionDescriptor
            {
              
                BoundProperties = new List<ParameterDescriptor>(),
                Parameters = new List<ParameterDescriptor>
                {
                    new ParameterDescriptor
                    {
                        Name = "ServiceAppointmentId",
                        ParameterType = typeof(Guid),
                        BindingInfo = new BindingInfo(),
                    }
                },
                FilterDescriptors = new List<FilterDescriptor>()
            };
            var ActionExecutingContext = new ActionContext
            {
                ActionDescriptor = actionDescriptor,
                HttpContext = httpContextn,
                RouteData = routeData,
            };
            var actionArguments = new Dictionary<string, object>();
            actionArguments.Add("model", "adcbdfdgg");
            actionArguments.Add("ServiceAppointmentId", "adcbdfdgg");
            cache.SetString("", "avcfdfdsgfddd44446gff");
            var filter = new EtagCacheValidateAttribute(_id, cache, _serviceName);
            var metadata = new List<IFilterMetadata>();
            var context = new ActionExecutingContext(
                ActionExecutingContext,
                metadata,
                actionArguments, "");
            filter.OnActionExecuting(context);
            httpContextn.Response.Headers.TryGetValue("Etag", out Microsoft.Extensions.Primitives.StringValues value0).ShouldNotBeNull();
            value0.ShouldNotBeNull();


            //Executed Method

            HttpContext httpExecutingContext = new DefaultHttpContext();
            httpExecutingContext.Request.Method = "PUT";
            httpExecutingContext.Response.Headers.Add("ETagKey", "adcbdfdgg_Template_Service");

            var ActionExecutedContext = new ActionContext
            {
                ActionDescriptor = actionDescriptor,
                HttpContext = httpExecutingContext,
                RouteData = routeData,
            };
            cache.SetString("adcbdfdgg_Template_Service", "avcfdfdsgfddd44446gff");
            var contextExecuted = new ActionExecutedContext(
               ActionExecutedContext,
               metadata,
               ""
               );
            filter.OnActionExecuted(contextExecuted);

        }
    }
}
