﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using Moq;

using Shouldly;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using Xunit;

namespace Neighborly.Chassis.EtagCache
{
    public class EtagCacheCreateValidateTests
    {
        private static string _id = "id";
        private static string _serviceName = "_Template_Service";
        [Fact]
        public void EtagCacheCreateValidateGetOnActionExecuting()
        {
            var opts = Options.Create<MemoryDistributedCacheOptions>(new MemoryDistributedCacheOptions());
            IDistributedCache cache = new MemoryDistributedCache(opts);
            var request = new Mock<HttpRequest>();
            request.SetupGet(r => r.ContentType).Returns("application/json");
            HttpContext httpContextn = new DefaultHttpContext();
            httpContextn.Request.Method = "GET";
            var routeData = new RouteData(); //
            routeData.Values.Add("id", "dfcdsvfdhh");        
            var actionDescriptor = new ControllerActionDescriptor
            {
               
                BoundProperties = new List<ParameterDescriptor>(),
               

                Parameters = new List<ParameterDescriptor>
                {
                    new ParameterDescriptor
                    {
                        Name = "id",
                        ParameterType = typeof(Guid),
                        BindingInfo = new BindingInfo(),
                    }
                },
                 
                
                FilterDescriptors = new List<FilterDescriptor>()
            };
            var ActionExecutingContext = new ActionContext
            {
                ActionDescriptor = actionDescriptor,
                HttpContext = httpContextn,
                RouteData = routeData,
            };
            var actionArguments = new Dictionary<string, object>();
            actionArguments.Add("id", "adcbdfdgg");
            ConfigurationRoot ConfigurationMVCC = (ConfigurationRoot)new ConfigurationBuilder()
              .SetBasePath(Directory.GetCurrentDirectory())
              .AddJsonFile("appsettings.json", true, true).Build();
            var filter = new EtagCacheCreateValidateAttribute(_id, _serviceName, cache, ConfigurationMVCC);
                    var metadata = new List<IFilterMetadata>();
            var context = new ActionExecutingContext(
                ActionExecutingContext,
                metadata,
                actionArguments, "");
         filter.OnActionExecuting(context);
            httpContextn.Response.Headers.TryGetValue("Etag", out Microsoft.Extensions.Primitives.StringValues value0).ShouldNotBeNull();
            value0.ShouldNotBeNull();


            //Act 2

            HttpContext httpContext2 = new DefaultHttpContext();
            httpContext2.Request.Method = "GET";
            cache.SetString("adcbdfdgg_Template_Service", "avcfdfdsgfddd44446gff");
            httpContext2.Request.Headers.Add("If-None-Match", "avcfdfdsgfddd44446gff");
            var ActionExecutingContext2 = new ActionContext
            {
                ActionDescriptor = actionDescriptor,
                HttpContext = httpContext2,
                RouteData = routeData,
            };

            var context2 = new ActionExecutingContext(
                ActionExecutingContext2,
                metadata,
                actionArguments, "");

            filter.OnActionExecuting(context2);


            //Act 3

            HttpContext httpContext3 = new DefaultHttpContext();
            httpContext3.Request.Method = "GET";
            cache.SetString("adcbdfdgg_Template_Service", "avcfdfdsgfddd44446gff");
            httpContext3.Request.Headers.Add("If-None-Match", "avcfdfdsg446gff");
            var ActionExecutingContext3 = new ActionContext
            {
                ActionDescriptor = actionDescriptor,
                HttpContext = httpContext3,
                RouteData = routeData,
            };

            var context3 = new ActionExecutingContext(
                ActionExecutingContext3,
                metadata,
                actionArguments, "");

            filter.OnActionExecuting(context3);


        }
    }
}
