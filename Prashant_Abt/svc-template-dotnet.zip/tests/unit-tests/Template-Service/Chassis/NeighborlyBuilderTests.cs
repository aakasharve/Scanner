﻿using Microsoft.Extensions.DependencyInjection;
using Moq;
using Neighborly.Chassis;
using System;
using Xunit;

namespace Neighborly.Chassis
{
    public class NeighborlyBuilderTests
    {
        private MockRepository mockRepository;

        private Mock<IServiceCollection> mockServiceCollection;

        public NeighborlyBuilderTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockServiceCollection = this.mockRepository.Create<IServiceCollection>();
        }

        private INeighborlyBuilder CreateNeighborlyBuilder()
        {
            IServiceCollection services = new ServiceCollection();
            return NeighborlyBuilder.Create(services);
        }

        [Fact]
        public void Create_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var builder = CreateNeighborlyBuilder();
            //Act
            builder.TryRegister("Test");
        }

        [Fact]
        public void AddBuildAction_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var neighborlyBuilder = this.CreateNeighborlyBuilder();
            Action<IServiceProvider> execute = new Action<IServiceProvider>(s=> { });

            // Act
            neighborlyBuilder.AddBuildAction(
                execute);
        }

        [Fact]
        public void AddInitializer_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var neighborlyBuilder = this.CreateNeighborlyBuilder();
            IInitializer initializer = null;

            // Act
            neighborlyBuilder.AddInitializer(
                initializer);

        }

        [Fact]
        public void AddInitializer_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var neighborlyBuilder = this.CreateNeighborlyBuilder();

            // Act
            neighborlyBuilder.AddInitializer<StartupInitializer>();

        }

        [Fact]
        public void Build_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var neighborlyBuilder = this.CreateNeighborlyBuilder();

            // Act
            var result = neighborlyBuilder.Build();

        }
    }
}
