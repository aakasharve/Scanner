﻿using Azure;
using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Moq;
using Neighborly.Chassis.Storage.Blobs;
using Neighborly.Helper;
using System;
using Xunit;

namespace Neighborly.Chassis.Storage.Blobs
{
    public class AzConvertTests
    {
        private MockRepository mockRepository;
        StorageOptions options = ConfigHelper.GetAppSettingsStorage();
        public string connectionString = null;
        public string containerName = null;

        public AzConvertTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
            connectionString = options.BlobCredentials.ConnectionString;
            containerName= options.BlobCredentials.Container;
        }



        [Fact]
        public void ToBlob_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            BlobContainerClient client = new BlobContainerClient(connectionString, containerName);

            // Act
            var result = AzConvert.ToBlob(
                client);

            // Assert
            Assert.IsType<Blob>(result);
            this.mockRepository.VerifyAll();
        }




        [Fact]
        public void toblob_stateundertest_expectedbehavior3()
        {
            // arrange
            Mock<BlobContainerProperties> properties = new Mock<BlobContainerProperties>();

            // act
            var result = AzConvert.ToBlob(
                "mycontainer",
                properties.Object);
            
        }

        //[Fact]
        //public void ToBlob_StateUnderTest_ExpectedBehavior4()
        //{
        //    // Arrange
        //    string path = null;
        //    Response<BlobProperties> properties = null;

        //    // Act
        //    var result = AzConvert.ToBlob(
        //        containerName,
        //        path,
        //        properties);

        //    // Assert
        //    Assert.IsType<Blob>(result);
        //    this.mockRepository.VerifyAll();
        //}

        //[Fact]
        //public void ToBlob_StateUnderTest_ExpectedBehavior5()
        //{
        //    // Arrange
        //    string path = null;
        //    BlobProperties properties = null;

        //    // Act
        //    var result = AzConvert.ToBlob(
        //        containerName,
        //        path,
        //        properties);

        //    // Assert
        //    Assert.IsType<Blob>(result);
        //    this.mockRepository.VerifyAll();
        //}
    }
}
