﻿using Moq;
using Neighborly.Chassis.Storage.Blobs;
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Storage.Blobs
{
    public class BlobStorageExtensionsTests
    {
        private MockRepository mockRepository;
        IBlobStorage _storage;
        public BlobStorageExtensionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
            _storage = StorageFactory.Blobs.AzureBlobStorageWithSharedKey(
                 "nblyservicebusstorage",
                 "+QUfZ72IQVPBrRIjS7KLEyCOErzdW4GYpCKuAy6fL4xniJJRzHjrrxeLuFpdE896M7L+jAPslWTCPG/RmsUWVw==");
        }

        [Fact]
        public async Task ListFilesAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            ListOptions options = new ListOptions { };
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            var result = await _storage.ListFilesAsync(
                options,
                cancellationToken);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }


        [Fact]
        public async Task ListFilesAsync_StateUnderTest_ExpectedBehavior_ContainerNotFount()
        {
            // Arrange
            ListOptions options = new ListOptions { FolderPath = "mycontainer5/someid", MaxResults = 5 };
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            var result = await _storage.ListFilesAsync(
                options,
                cancellationToken);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task ListFilesAsync_StateUnderTest_ExpectedBehavior_1()
        {
            // Arrange
            ListOptions options = new ListOptions { FolderPath = "mycontainer/someid", MaxResults = 5 };
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            var result = await _storage.ListFilesAsync(
                options,
                cancellationToken);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task ListAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string folderPath = "mycontainer/someid";
            Func<Blob, bool> browseFilter = new Func<Blob, bool>(p => true);
            string filePrefix = "test";
            bool recurse = false;
            int? maxResults = 5;
            bool includeAttributes = false;
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            var result = await _storage.ListAsync(
                folderPath,
                browseFilter,
                filePrefix,
                recurse,
                maxResults,
                includeAttributes,
                cancellationToken);

        }

        [Fact]
        public async Task Write_read_object()
        {
            var input = new MyClass { Name = "test" };
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);
            //CheckIfExists
            bool isexists = _storage.ExistsAsync("mycontainer/someid", cancellationToken).Result;

            //upload it
            await _storage.WriteTextAsync("mycontainer/someid", "test content");

            //read back
            string content = await _storage.ReadTextAsync("mycontainer/someid");
            Assert.Equal("test content", content);
        }


        [Fact]
        public async Task DeleteAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);
            try
            {
                // Act
                await _storage.DeleteAsync(
                    "mycontainer/someid",
                    cancellationToken);
                // Assert
                Assert.True(true);
            }
            catch (Exception ex)
            {
                // Assert
                Assert.True(false);
            }

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task DeleteAsync_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            List<Blob> blobs = null;
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            try
            {
                // Act
                await _storage.DeleteAsync(
                    "mycontainer/someid",
                    cancellationToken);
                // Assert
                Assert.True(true);
            }
            catch (Exception ex)
            {
                // Assert
                Assert.True(false);
            }

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task GetBlob()
        {
            //Get blob
            var blobdetails = await _storage.GetBlobAsync(@"mycontainer/myjson.json");
            Assert.IsType<Blob>(blobdetails);
        }

        //[Fact]
        //public async Task GetBlob_EmptyPath()
        //{
        //    //Get blob
        //    var blobdetails = await _storage.GetBlobAsync(@"");
        //    Assert.IsType<Blob>(blobdetails);
        //}

        [Fact]
        public async Task SetBlob()
        {
            Blob blob = new Blob($"mycontainer/myjson.json") { };
            //Get blob
            try
            {
                await _storage.SetBlobAsync(blob);
                Assert.True(true);
            }
            catch (Exception)
            {
                Assert.True(false);
            }
        }

        [Fact]
        public async Task WriteAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string fullPath = $"mycontainer/myjson.json";
            byte[] data = null;
            bool append = false;
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);
            var stream = new MemoryStream();
            // Act
            await _storage.WriteAsync(fullPath,
                stream,
                append,
                cancellationToken);

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task ReadBytesAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string fullPath = $"mycontainer/myjson.json";
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            var result = await _storage.ReadBytesAsync(
                fullPath,
                cancellationToken);

            // Assert
            Assert.IsType<byte[]>(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task ReadToStreamAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string fullPath = $"mycontainer/myjson.json";
            Stream targetStream = new MemoryStream();
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            await _storage.ReadToStreamAsync(
            fullPath,
            targetStream,
            cancellationToken);
        }

        [Fact]
        public async Task ReadToStreamAsync_StateUnderTest_ExpectedBehavior_null()
        {
            // Arrange
            string fullPath = $"mycontainer/myjson.json";
            Stream targetStream = null;
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            try
            {
                await _storage.ReadToStreamAsync(
                fullPath,
                targetStream,
                cancellationToken);
            }
            catch (Exception ex)
            {
                Assert.Contains("Value cannot be null",ex.Message);
            }

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task Write_read_File()
        {
            string currentDir = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(currentDir).Parent.Parent.FullName;
            string fullpath = $"{projectDirectory}//Test Files//Test.pdf";
            string fullName = $"{projectDirectory}//Test Files//Test1.pdf";
            
            //const char namespaceSeparator = '.';
            //// get calling assembly
            //var assembly = Assembly.GetCallingAssembly();

            //// compute resource name suffix
            //var relativeName = ".Test Files/Test.pdf"
            //    .Replace('\\', namespaceSeparator)
            //    .Replace('/', namespaceSeparator)
            //    .Replace(' ', '_');

            //// get resource stream
            //var fullName = assembly
            //    .GetManifestResourceNames()
            //    .FirstOrDefault(name => name.EndsWith(relativeName, StringComparison.InvariantCulture));

            //upload it
            await _storage.WriteFileAsync("mycontainer/someid.pdf", fullpath);

            //read back
            await _storage.ReadToFileAsync("mycontainer/someid.pdf", fullName);
        }

        [Fact]
        public async Task Write_read_Json()
        {
            var input = new MyClass { Name = "test" };

            //upload it
            await _storage.WriteJsonAsync("mycontainer/myjson.json", input);

            //read back
            var content = await _storage.ReadJsonAsync<MyClass>("mycontainer/myjson.json");
            Assert.Equal("test", content.Name);
        }

        //[Fact]
        //public async Task CopyToAsync_StateUnderTest_ExpectedBehavior()
        //{
        //    // Arrange
        //    string blobId = "myjson.json";
        //    IBlobStorage targetStorage = null;
        //    string newId = null;
        //    CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

        //    // Act
        //    await _storage.CopyToAsync(
        //        blobId,
        //        targetStorage,
        //        newId,
        //        cancellationToken);

        //    // Assert
        //    Assert.True(true);
        //    this.mockRepository.VerifyAll();
        //}

        [Fact]
        public async Task GetMD5HashAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            Blob blob = new Blob("mycontainer/myjson.json");
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            var result = await _storage.GetMD5HashAsync(
                blob,
                cancellationToken);

            // Assert
            Assert.NotEmpty(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task RenameAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string oldPath = "mycontainer/someid";
            string newPath = "someid1";
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            try
            {
                await _storage.RenameAsync(
                   oldPath,
                   newPath,
                   cancellationToken);

            }
            catch (Exception ex)
            {
                
            }
            

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task CreateFolderAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string folderPath = "mycontainer/myjson1.json";
            string dummyFileName = "Test";
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            await _storage.CreateFolderAsync(
                folderPath,
                dummyFileName,
                cancellationToken);

            this.mockRepository.VerifyAll();
        }

        private class MyClass
        {
            public string Name { get; set; }
        }
    }
}
