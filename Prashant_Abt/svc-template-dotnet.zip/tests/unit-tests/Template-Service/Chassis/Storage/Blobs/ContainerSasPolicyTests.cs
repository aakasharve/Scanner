﻿using Azure.Storage;
using Moq;
using Neighborly.Chassis.Storage.Blobs;
using Neighborly.Helper;
using System;
using Xunit;

namespace Neighborly.Chassis.Storage.Blobs
{
    public class ContainerSasPolicyTests
    {
        private MockRepository mockRepository;

        public ContainerSasPolicyTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        private ContainerSasPolicy CreateContainerSasPolicy()
        {
            DateTimeOffset dateTimeOffset = new DateTimeOffset();
            TimeSpan timeSpan = new TimeSpan();
            return new ContainerSasPolicy(
                dateTimeOffset,
                timeSpan);
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var containerSasPolicy = this.CreateContainerSasPolicy();

            // Act
            StorageOptions options = ConfigHelper.GetAppSettingsStorage();
            var credential = new StorageSharedKeyCredential(options.BlobCredentials.AccountName, options.BlobCredentials.AccountKey);
            // Act
            try
            {
                containerSasPolicy.StartTime = new DateTimeOffset();
                containerSasPolicy.Permissions = new ContainerSasPermission { };
                containerSasPolicy.Duration = new TimeSpan();
                containerSasPolicy.ToSasQuery(credential, options.BlobCredentials.Container);
                // Assert
            }
            catch (Exception ex)
            {
                Assert.IsType<InvalidOperationException>(ex);
            }

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void TestMethod_SasNull()
        {
            // Arrange
            var containerSasPolicy = this.CreateContainerSasPolicy();

            // Act
            StorageOptions options = ConfigHelper.GetAppSettingsStorage();
            var credential = new StorageSharedKeyCredential(options.BlobCredentials.AccountName, options.BlobCredentials.AccountKey);
            // Act
            try
            {
                containerSasPolicy.StartTime = new DateTimeOffset();
                containerSasPolicy.Permissions = new ContainerSasPermission { };
                containerSasPolicy.Duration = new TimeSpan();
                containerSasPolicy.ToSasQuery(credential, options.BlobCredentials.Container);
                // Assert
            }
            catch (Exception ex)
            {
                Assert.Contains("SAS is missing required parameter: ExpiresOn", ex.Message);
            }

            this.mockRepository.VerifyAll();
        }
    }
}
