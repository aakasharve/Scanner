﻿using Azure.Storage.Blobs;
using Moq;
using Neighborly.Chassis.Storage.Blobs;
using Neighborly.Helper;
using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Storage.Blobs
{
    public class AzureContainerBrowserTests
    {
        private MockRepository mockRepository;

        StorageOptions options = ConfigHelper.GetAppSettingsStorage();
        public string connectionString = null;
        public string containerName = null;
        private BlobContainerClient BlobContainerClient;
        public AzureContainerBrowserTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
            connectionString = options.BlobCredentials.ConnectionString;
            containerName = options.BlobCredentials.Container;
            BlobContainerClient = new BlobContainerClient(connectionString, containerName);
        }

        private AzureContainerBrowser CreateAzureContainerBrowser()
        {
            return new AzureContainerBrowser(
                BlobContainerClient,
                true,
                5);
        }

        [Fact]
        public async Task ListFolderAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var azureContainerBrowser = this.CreateAzureContainerBrowser();
            ListOptions options = new ListOptions { Recurse = true };
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            var result = await azureContainerBrowser.ListFolderAsync(
                options,
                cancellationToken);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void Dispose_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var azureContainerBrowser = this.CreateAzureContainerBrowser();

            // Act
            azureContainerBrowser.Dispose();
            this.mockRepository.VerifyAll();
        }
    }
}
