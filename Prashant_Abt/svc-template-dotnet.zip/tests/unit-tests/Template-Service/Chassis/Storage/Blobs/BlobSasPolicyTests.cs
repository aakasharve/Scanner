﻿using Azure.Storage;
using Moq;
using Neighborly.Chassis.Storage.Blobs;
using Neighborly.Helper;
using System;
using Xunit;

namespace Neighborly.Chassis.Storage.Blobs
{
    public class BlobSasPolicyTests
    {
        private MockRepository mockRepository;
        StorageOptions options = ConfigHelper.GetAppSettingsStorage();

        public BlobSasPolicyTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        private BlobSasPolicy CreateBlobSasPolicy()
        {

            DateTimeOffset dateTimeOffset = new DateTimeOffset();
            TimeSpan timeSpan = new TimeSpan();
            return new BlobSasPolicy(
                dateTimeOffset,
                timeSpan);
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var blobSasPolicy = this.CreateBlobSasPolicy();

            // Act
            StorageOptions options = ConfigHelper.GetAppSettingsStorage();
            var credential = new StorageSharedKeyCredential(options.BlobCredentials.AccountName, options.BlobCredentials.AccountKey);
            // Act
            try
            {
                blobSasPolicy.StartTime = new DateTimeOffset();
                blobSasPolicy.Permissions = new BlobSasPermission { };
                blobSasPolicy.Duration = new TimeSpan();
                blobSasPolicy.ToSasQuery(credential, options.BlobCredentials.Container,"someid");
                // Assert
            }
            catch (Exception ex)
            {
                Assert.IsType<InvalidOperationException>(ex);
            }

            this.mockRepository.VerifyAll();
        }
        [Fact]
        public void TestMethod_SasNull()
        {
            // Arrange
            var blobSasPolicy = this.CreateBlobSasPolicy();

            // Act
            StorageOptions options = ConfigHelper.GetAppSettingsStorage();
            StorageSharedKeyCredential credential = null;
            // Act
            try
            {
                blobSasPolicy.StartTime = new DateTimeOffset();
                blobSasPolicy.Permissions = new BlobSasPermission { };
                blobSasPolicy.Duration = new TimeSpan();
                blobSasPolicy.ToSasQuery(credential, options.BlobCredentials.Container, "someid");
                // Assert
            }
            catch (Exception ex)
            {
                Assert.IsType<ArgumentNullException>(ex);
            }

            this.mockRepository.VerifyAll();
        }
    }
}
