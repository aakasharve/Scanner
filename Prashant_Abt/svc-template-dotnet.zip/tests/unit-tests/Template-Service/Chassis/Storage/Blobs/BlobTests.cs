﻿using Moq;
using Neighborly.Chassis.Storage.Blobs;
using NetBox.Extensions;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Neighborly.Chassis.Storage.Blobs
{
    public class BlobTests
    {
        private MockRepository mockRepository;
        public BlobTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        private Blob CreateBlob()
        {
            return new Blob(
                "mycontainer/someid");
        }

        [Fact]
        public void TryGetProperty_StateUnderTest_ExpectedBehavior_NameNull()
        {
            // Arrange
            var blob = this.CreateBlob();
            string name = null;
            MyClass value = default(MyClass);
            MyClass defaultValue = default(MyClass);

            // Act
            var result = blob.TryGetProperty(
                name,
                out value,
                defaultValue);

            // Assert
            Assert.False(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void TryGetProperty_StateUnderTest_ExpectedBehavior_T()
        {
            // Arrange
            var blob = this.CreateBlob();
            string name = "NameTest";
            MyClass value = default(MyClass);
            MyClass defaultValue = new MyClass();
            defaultValue.Name = "NameTest";
            IDictionary<string, string> source = new Dictionary<string, string>();
            source.Add("NameTest", "NameTest");
            source.Add("test2", "test2");
            blob.Properties["NameTest"] = defaultValue;
            // Act
            var result = blob.TryGetProperty(
                name,
                out value,
                defaultValue);
        }

        [Fact]
        public void TryGetProperty_StateUnderTest_ExpectedBehavior_string()
        {
            // Arrange
            var blob = this.CreateBlob();
            string name = "NameTest";
            MyClass value = default(MyClass);
            MyClass defaultValue = new MyClass();
            defaultValue.Name = "NameTest";
            IDictionary<string, string> source = new Dictionary<string, string>();
            source.Add("NameTest", "NameTest");
            source.Add("test2", "test2");
            blob.Properties["NameTest"] = "defaultValue";
            // Act
            var result = blob.TryGetProperty(
                name,
                out value,
                defaultValue);
        }

        [Fact]
        public void TryAddProperties_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var blob = this.CreateBlob();

            // Act
            blob.TryAddProperties(
                "IsContainer", true);
        }

        [Fact]
        public void TryAddPropertiesWithPrefix_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var blob = this.CreateBlob();
            string prefix = null;

            // Act
            blob.TryAddPropertiesWithPrefix(
                prefix,
                "IsContainer", true);
        }

        [Fact]
        public void TryAddPropertiesFromDictionary_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var blob = this.CreateBlob();
            IDictionary<string, string> source = new Dictionary<string,string>();
            source.Add("test", "test");
            source.Add("test2", "test2");
            string[] keyNames = {"test","Test2" };

            // Act
            blob.TryAddPropertiesFromDictionary(
                source,
                keyNames);

        }

        [Fact]
        public void ToString_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var blob = this.CreateBlob();

            // Act
            var result = blob.ToString();
        }

        [Fact]
        public void Equals_StateUnderTest_ExpectedBehavior_null()
        {
            // Arrange
            var blob = this.CreateBlob();
            Blob other = null;

            // Act
            var result = blob.Equals(
                other);

            // Assert
            Assert.False(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void Equals_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var blob = this.CreateBlob();
            Blob other = this.CreateBlob();

            // Act
            var result = blob.Equals(
                other);

            // Assert
            Assert.True(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void Equals_StateUnderTest_ExpectedBehavior1_null()
        {
            // Arrange
            var blob = this.CreateBlob();
            object other = null;

            // Act
            var result = blob.Equals(
                other);

            // Assert
            Assert.False(result);
            this.mockRepository.VerifyAll();
        }

        public void Equals_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var blob = this.CreateBlob();
            object other = this.CreateBlob();

            // Act
            var result = blob.Equals(
                other);

            // Assert
            Assert.True(result);
            this.mockRepository.VerifyAll();
        }

        public void Equals_StateUnderTest_ExpectedBehavior_Other()
        {
            // Arrange
            var blob = this.CreateBlob();
            object other = new object();

            // Act
            var result = blob.Equals(
                other);

            // Assert
            Assert.False(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void GetHashCode_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var blob = this.CreateBlob();

            // Act
            var result = blob.GetHashCode();

            // Assert
            Assert.IsType<int>(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void AttributesToByteArray_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var blob = this.CreateBlob();
            IDictionary<string, string> source = new Dictionary<string, string>();
            source.Add("test", "test");
            source.Add("test2", "test2");
            blob.Metadata.MergeRange(source);
            // Act
            var result = blob.AttributesToByteArray();

            // Assert
            Assert.IsType<byte[]>(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void AppendAttributesFromByteArray_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var blob = this.CreateBlob();
            byte[] data = Encoding.ASCII.GetBytes("Hi");

            // Act
           Assert.Throws<ArgumentException>(()=> blob.AppendAttributesFromByteArray(
                data));

        }


        [Fact]
        public void PrependPath_StateUnderTest_ExpectedBehavior_Null()
        {
            // Arrange
            var blob = this.CreateBlob();
            string path = null;

            // Act
            blob.PrependPath(
                path);

        }

        [Fact]
        public void PrependPath_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var blob = this.CreateBlob();
            string path = "Test/Test";

            // Act
            blob.PrependPath(
                path);

        }


        [Fact]
        public void SetFullPath_StateUnderTest_ExpectedBehavior_root()
        {
            // Arrange
            var blob = this.CreateBlob();
            string fullPath = null;

            // Act
            blob.SetFullPath(
                fullPath);
        }

        [Fact]
        public void SetFullPath_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var blob = this.CreateBlob();
            string fullPath = "a/b";

            // Act
            blob.SetFullPath(
                fullPath);
        }

        [Fact]
        public void Clone_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var blob = this.CreateBlob();

            // Act
            var result = blob.Clone();
        }
    }
    public class MyClass
    {
        public string Name { get; set; }
    }
}
