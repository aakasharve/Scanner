﻿using Azure.Storage;
using Moq;
using Neighborly.Chassis.Storage.Blobs;
using Neighborly.Helper;
using System;
using Xunit;

namespace Neighborly.Chassis.Storage.Blobs
{
    public class AccountSasPolicyTests
    {
        private MockRepository mockRepository;

        public AccountSasPolicyTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        private AccountSasPolicy CreateAccountSasPolicy()
        {
            DateTimeOffset dateTimeOffset = new DateTimeOffset();
            TimeSpan timeSpan = new TimeSpan(); 
            return new AccountSasPolicy(
                dateTimeOffset, timeSpan);
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var accountSasPolicy = this.CreateAccountSasPolicy();
            StorageOptions options = ConfigHelper.GetAppSettingsStorage();
            var credential = new StorageSharedKeyCredential(options.BlobCredentials.AccountName, options.BlobCredentials.AccountKey);
            // Act
            try
            {
                accountSasPolicy.StartTime = new DateTimeOffset();
                accountSasPolicy.Permissions = new AccountSasPermission {  };
                accountSasPolicy.Duration = new TimeSpan();
                accountSasPolicy.ToSasQuery(credential);
                // Assert
            }
            catch (Exception ex)
            {
                Assert.IsType<InvalidOperationException> (ex);
            }
          
            
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void TestMethod_SasNull()
        {
            // Arrange
            var accountSasPolicy = this.CreateAccountSasPolicy();
            StorageOptions options = ConfigHelper.GetAppSettingsStorage();
            StorageSharedKeyCredential credential = null;
            // Act
            try
            {
                accountSasPolicy.ToSasQuery(credential);
                // Assert
            }
            catch (Exception ex)
            {
                Assert.IsType<ArgumentNullException>(ex);
            }


            this.mockRepository.VerifyAll();
        }
    }
}
