﻿using Moq;
using Neighborly.Chassis.Formatter;
using System;
using Xunit;

namespace Neighborly.Chassis.Formatter
{
    public class TypeConverterExtensionTests
    {
        private MockRepository mockRepository;


        public TypeConverterExtensionTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        [Fact]
        public void ToDateTime_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "02-02-2021";

            // Act
            var result = TypeConverterExtension.ToDateTime(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ToInt16_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "1";

            // Act
            var result = TypeConverterExtension.ToInt16(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ToInt32_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "1";

            // Act
            var result = TypeConverterExtension.ToInt32(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ToInt64_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "10";

            // Act
            var result = TypeConverterExtension.ToInt64(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ToBoolean_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "0";

            // Act
            var result = TypeConverterExtension.ToBoolean(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ToFloat_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "1";

            // Act
            var result = TypeConverterExtension.ToFloat(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ToDecimal_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "1.11";

            // Act
            var result = TypeConverterExtension.ToDecimal(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ToDouble_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "7";

            // Act
            var result = TypeConverterExtension.ToDouble(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsNumber_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "1";

            // Act
            var result = TypeConverterExtension.IsNumber(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsWholeNumber_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "2";

            // Act
            var result = TypeConverterExtension.IsWholeNumber(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsDecimalNumber_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "2.12";

            // Act
            var result = TypeConverterExtension.IsDecimalNumber(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsBoolean_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string value = "true";

            // Act
            var result = TypeConverterExtension.IsBoolean(
                value);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
