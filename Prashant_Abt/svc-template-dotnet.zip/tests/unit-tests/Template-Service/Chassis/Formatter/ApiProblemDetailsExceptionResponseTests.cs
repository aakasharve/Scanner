﻿using Moq;
using Neighborly.Chassis.Formatter;
using Neighborly.Helper;
using System;
using System.Collections.Generic;
using Xunit;
using static Neighborly.Chassis.Formatter.ApiProblemDetailsExceptionResponse;

namespace Neighborly.Chassis.Formatter
{
    public class ApiProblemDetailsExceptionResponseTests
    {
        private MockRepository mockRepository;



        public ApiProblemDetailsExceptionResponseTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        private ApiProblemDetailsExceptionResponse CreateApiProblemDetailsExceptionResponse()
        {
            return new ApiProblemDetailsExceptionResponse();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var apiProblemDetailsExceptionResponse = this.CreateApiProblemDetailsExceptionResponse();
            IEnumerable<ValidationError> validationError = null;
            Exception exc = new Exception();
            ApiException exp = new ApiException(exc) { };
            ApiProblemDetailsExceptionResponse.ErrorDetails apierrorDetails = new ErrorDetails() { Message = "", Raw = "", Source = "Source", Type = "type" };
            string Message = apierrorDetails.Message; string Raw = apierrorDetails.Raw; string Source = apierrorDetails.Source; string Type = apierrorDetails.Type;
            // Act
            apiProblemDetailsExceptionResponse.Errors = new ApiProblemDetailsExceptionResponse.ErrorDetails { Message = "Message", Source = "Source", Type = "Type", Raw = "strRaw", };
            var errorJson = JsonHelper.ToJson(new ApiError("GET Request successful.") { ExceptionMessage = "ExMessage", ReferenceErrorCode = "ErrorCode", ReferenceDocumentLink = "link", Details = "Details", ValidationErrors = validationError }, null);
            var errorJsonObj = JsonHelper.ToJson(new ApiError("GET Request successful.", validationError) { ExceptionMessage = "ExMessage", ReferenceErrorCode = "ErrorCode", ReferenceDocumentLink = "link", Details = "Details", ValidationErrors = validationError }, null);
            var apiExceptionJson = JsonHelper.ToJson(new ApiException("GET Request successful.") { CustomError = "cError", IsModelValidatonError = false, ReferenceErrorCode = "", ReferenceDocumentLink = "link", IsCustomErrorObject = false, StatusCode = 501, Errors = validationError }, null);
            var apiExceptionJsonParams = JsonHelper.ToJson(new ApiException("GET Request successful.", 200) { CustomError = "cError", IsModelValidatonError = false, ReferenceErrorCode = "", ReferenceDocumentLink = "link", IsCustomErrorObject = false, StatusCode = 501, Errors = validationError }, null);
            var apiExceptionJsonParams2 = JsonHelper.ToJson(new ApiException(validationError, 200) { CustomError = "cError", IsModelValidatonError = false, ReferenceErrorCode = "", ReferenceDocumentLink = "link", IsCustomErrorObject = false, StatusCode = 501, Errors = validationError }, null);
            var apiProblemDetailsJson = JsonHelper.ToJson(new ApiProblemDetails(500) { Title = "TestTitle", Type = "TypeTest", IsError = false, Status = 200, Detail = "TestDetail", Errors = null }, null);
            var apiProblemDetailsExceptionJson = JsonHelper.ToJson(new ApiProblemDetailsException(500) { HResult = 1, HelpLink = "strLink", Source = "TestSource" }, null);
            var apiPrbDetailsString = apiProblemDetailsExceptionJson.ToString();
            var apiProblemDetailsExceptionResponseJson = JsonHelper.ToJson(new ApiProblemDetailsExceptionResponse() { IsError = false, Status = 200, Title = "TestTitle", Detail = "testDetail" }, null);
            var apiProblemDetailsMemberJson = JsonHelper.ToJson(new ApiProblemDetailsMember(), null);
            var apiProblemDetailsResponseMemberJson = JsonHelper.ToJson(new ApiProblemDetailsResponse() { Status = 200, IsError = false, Title = "Title", Detail = "details", Type = "testType" }, null);
            var apiProblemDetailsValidationErrorResponseJson = JsonHelper.ToJson(new ApiProblemDetailsValidationErrorResponse() { Status = 200, Title = "Title", IsError = false, ValidationErrors = validationError }, null);
            var apiResultResponseJson = JsonHelper.ToJson(new ApiResultResponse<object>() { Message = "TestMessage", Result = "Ok" }, null);
            var autoWrapIgnoreAttributeJson = JsonHelper.ToJson(new AutoWrapIgnoreAttribute() { ShouldLogRequestData = true }, null);
            var camelCaseContractResolverJsonSettingsJson = JsonHelper.ToJson(new CamelCaseContractResolverJsonSettings(), null);
            var customContractResolverJson = JsonHelper.ToJson(new CustomContractResolver<object>(true), null);
            var customContractResolverJsonSettingsJson = JsonHelper.ToJson(new CustomContractResolverJsonSettings<object>(), null);
            var formatterExcludePathJson = JsonHelper.ToJson(new FormatterExcludePath("api/test"), null);
            var formatterOptionsTestsJson = JsonHelper.ToJson(new FormatterOptionsTests(), null);
            var formatterPropertyMapAttributeJson = JsonHelper.ToJson(new FormatterPropertyMapAttribute("api"), null);
            var requestDataLogIgnoreAttributeJson = JsonHelper.ToJson(new RequestDataLogIgnoreAttribute() { }, null);
            var responseMessageJson = JsonHelper.ToJson(new ResponseMessage(), null);
            var ValidationErrorJson = JsonHelper.ToJson(new ValidationError("name", "reason"), null);

            var errorDetails = new ErrorDetails() { Message = "test", Source = "source", Raw = "raw", Type = "Type" };

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
