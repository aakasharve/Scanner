﻿using Moq;
using Xunit;

namespace Neighborly.Chassis.Formatter
{
    public class ApiResponseTests
    {
        private MockRepository mockRepository;

        public ApiResponseTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        private ApiResponse CreateApiResponse()
        {
            return new ApiResponse(
                "message",
                null,
                200,
                "1.0.0.0");
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var apiResponse = this.CreateApiResponse();

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
