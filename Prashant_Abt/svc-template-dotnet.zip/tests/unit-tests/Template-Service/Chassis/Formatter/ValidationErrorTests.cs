﻿using Moq;
using Xunit;

namespace Neighborly.Chassis.Formatter
{
    public class ValidationErrorTests
    {
        private MockRepository mockRepository;

        public ValidationErrorTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        private ValidationError CreateValidationError()
        {
            return new ValidationError(
                null,
                null); ;
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var validationError = this.CreateValidationError();

            // Assert
            Assert.NotNull(validationError);
            this.mockRepository.VerifyAll();
        }
    }
}
