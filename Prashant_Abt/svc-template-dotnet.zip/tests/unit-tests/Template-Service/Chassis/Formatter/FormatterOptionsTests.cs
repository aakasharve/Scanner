﻿using Moq;
using Neighborly.Chassis.Formatter;
using Newtonsoft.Json;
using System;
using Xunit;

namespace Neighborly.Chassis.Formatter
{
    public class FormatterOptionsTests
    {
        private MockRepository mockRepository;



        public FormatterOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private FormatterOptions CreateFormatterOptions()
        {
            return new FormatterOptions();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var formatterOptions = this.CreateFormatterOptions();
            ReferenceLoopHandling refHandling = new ReferenceLoopHandling();

            // Act
            var formatterOption = new FormatterOptions() { ExcludePaths = null, ReferenceLoopHandling = refHandling };
            var result = (formatterOptions.UseCustomSchema,
                           formatterOptions.ReferenceLoopHandling,
                           formatterOptions.UseCustomExceptionFormat,
                           formatterOptions.UseApiProblemDetailsException,
                           formatterOptions.LogRequestDataOnException,
                           formatterOptions.ShouldLogRequestData,
                           formatterOptions.SwaggerPath,
                           formatterOptions.ExcludePaths);

            // Assert
            Assert.True(result.LogRequestDataOnException);
            this.mockRepository.VerifyAll();
        }
    }
}
