﻿using Moq;
using Neighborly.Chassis.Formatter;
using System;
using Xunit;

namespace Neighborly.Chassis.Formatter
{
    public class ApiProblemDetailsExceptionTests
    {
        private MockRepository mockRepository;



        public ApiProblemDetailsExceptionTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        private ApiProblemDetailsException CreateApiProblemDetailsException()
        {
            return new ApiProblemDetailsException(200
                );
        }

        [Fact]
        public void ToString_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var apiProblemDetailsException = this.CreateApiProblemDetailsException();

            // Act
            var result = apiProblemDetailsException.ToString();

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
