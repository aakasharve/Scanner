﻿using Moq;
using Neighborly.Chassis.Formatter;
using System;
using Xunit;

namespace Neighborly.Chassis.Formatter
{
    public class FormatterPropertyMapAttributeTests
    {
        private MockRepository mockRepository;

        public FormatterPropertyMapAttributeTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

       
        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var formatterPropertyMapAttribute = this.CreateFormatterPropertyMapAttribute();

            // Act
            var objFormatterPropertyMapAttribute = new FormatterPropertyMapAttribute() {PropertyName = "propertyName"};
            var formatterPropertyMapAttributeObj = new FormatterPropertyMapAttribute();

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        private FormatterPropertyMapAttribute CreateFormatterPropertyMapAttribute()
        {
            return new FormatterPropertyMapAttribute();
        }

    }
}
