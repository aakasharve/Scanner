﻿using Moq;
using Neighborly.Models;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using Xunit;

namespace Neighborly.Chassis.Formatter
{
    public class JSONHelperTests
    {
        private MockRepository mockRepository;
        public JSONHelperTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [Fact]
        public void GetJSONSettings_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            bool ignoreNull = false;
            ReferenceLoopHandling referenceLoopHandling = default(global::Newtonsoft.Json.ReferenceLoopHandling);
            bool useCamelCaseNaming = false;

            // Act
            var result = JSONHelper.GetJSONSettings(
                ignoreNull,
                referenceLoopHandling,
                useCamelCaseNaming);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void GetJSONSettings_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            bool ignoreNull = false;
            ReferenceLoopHandling referenceLoopHandling = default(global::Newtonsoft.Json.ReferenceLoopHandling);
            bool useCamelCaseNaming = false;

            // Act
            var result = JSONHelper.GetJSONSettings<ToDoItemEntity>(
                ignoreNull,
                referenceLoopHandling,
                useCamelCaseNaming);

            // Assert
            Assert.NotNull(result.Settings);
            Assert.NotNull(result.Mappings);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void HasProperty_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            dynamic jsonObject = new JObject();
            jsonObject.Date = DateTime.Now;
            jsonObject.Album = "Me Against the world";
            jsonObject.Year = 1995;
            jsonObject.Artist = "2Pac";
            string name = "Year";

            // Act
            var result = JSONHelper.HasProperty(
                jsonObject,
                name);

            // Assert
            Assert.True(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void HasProperty_StateUnderTest_ExpectedBehavior_DoesNotHaveProperty()
        {
            // Arrange
            dynamic jsonObject = new JObject();
            jsonObject.Date = DateTime.Now;
            jsonObject.Album = "Me Against the world";
            jsonObject.Year = 1995;
            jsonObject.Artist = "2Pac";
            string name = "ID";

            // Act
            var result = JSONHelper.HasProperty(
                jsonObject,
                name);

            // Assert
            Assert.False(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void HasProperty_StateUnderTest_ExpectedBehavior_NotJObject()
        {
            // Arrange
            dynamic jsonObject = "String";
            string name = "ID";
            // Act
            var result = JSONHelper.HasProperty(
                jsonObject,
                name);

            // Assert
            Assert.False(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void RemoveEmptyChildren_StateUnderTest_ExpectedBehavior_JObjectwithValues()
        {
            // Arrange
            String json = "{\"part\":{ \"values\": [\"engine\",\"body\",\"door\"], \"isDelivered\": \"true\"},\"manufacturer\":{\"values\": [\"Mercedes\"],\"isDelivered\": \"false\"}}";
            JObject jObject = JObject.Parse(json);
            JToken token = jObject;

            // Act
            var result = JSONHelper.RemoveEmptyChildren(
                token);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }


        [Fact]
        public void RemoveEmptyChildren_StateUnderTest_ExpectedBehavior_JObjectwithoutValues()
        {
            // Arrange
            dynamic jsonObject = new JObject();
            jsonObject.Date = DateTime.Now;
            jsonObject.Album = null;
            jsonObject.Year = 1995;
            jsonObject.Artist = string.Empty;
            JToken token = jsonObject;

            // Act
            var result = JSONHelper.RemoveEmptyChildren(
                token);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }


        [Fact]
        public void RemoveEmptyChildren_StateUnderTest_ExpectedBehavior_JArraywithValues()
        {
            // Arrange
            String json = "{\"part\":{ \"values\": [\"engine:1\",\"body:1\",\"door:1\"], \"isDelivered\": \"true\"},\"manufacturer\":{\"values\": [\"Mercedes\"],\"isDelivered\": \"false\"}}";
            JObject jObject = JObject.Parse(json);
            JArray jsonArray = (JArray)jObject["part"]["values"];
            JToken token = jsonArray;
            // Act
            var result = JSONHelper.RemoveEmptyChildren(
                token);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void RemoveEmptyChildren_StateUnderTest_ExpectedBehavior_JtokenNull()
        {
            // Arrange
            String json = "{\"part\":{ \"values\": [\"engine:1\",\"body:1\",\"door:1\"], \"isDelivered\": \"true\"},\"manufacturer\":{\"values\": [\"Mercedes\"],\"isDelivered\": \"false\"}}";
            JToken token = json;
            // Act
            var result = JSONHelper.RemoveEmptyChildren(
                token);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsEmpty_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            JToken token = new JArray();

            // Act
            var result = JSONHelper.IsEmpty(
                token);

            // Assert
            Assert.False(result);
            this.mockRepository.VerifyAll();
        }
    }
}
