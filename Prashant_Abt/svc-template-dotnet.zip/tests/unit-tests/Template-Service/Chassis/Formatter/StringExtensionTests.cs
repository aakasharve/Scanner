﻿using Moq;
using Neighborly.Chassis.Formatter;
using System;
using Xunit;

namespace Neighborly.Chassis.Formatter
{
    public class StringExtensionTests
    {
        private MockRepository mockRepository;


        public StringExtensionTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }


        [Fact]
        public void IsValidJson_StateUnderTest_ExpectedBehavior()
        {
            // Arrange

            string text = "[" +"test" + ",test2"+"]";

            // Act
            var result = StringExtension.IsValidJson(
                text);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void VerifyBodyContent_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            //var stringExtension = this.CreateStringExtension();
            string text = null;

            // Act
            var result = StringExtension.VerifyBodyContent(
                text);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsHtml_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string text = "test";

            // Act
            var result = StringExtension.IsHtml(
                text);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ToCamelCase_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            string str = "test";

            // Act
            var result = StringExtension.ToCamelCase(
                str);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ToCamelCase_StateUnderTest_NegativeExpectedBehavior()
        {
            // Arrange
            string str = string.Empty;

            // Act
            var result = StringExtension.ToCamelCase(
                str);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
        [Fact]
        public void IsValidJson_StateUnderTest_Exception()
        {
            // Arrange
            try
            {
                string text = "{" + "test" + ",test2" + "}"+"}";

                // Act
                var result = StringExtension.IsValidJson(
                    text);
                Assert.True(result);

            }
            catch (Exception)
            {

                Assert.True(true);
            }
            this.mockRepository.VerifyAll();
        }
        [Fact]
        public void VerifyBodyContent_StateUnderTest_Exception()
        {
            // Arrange
            //var stringExtension = this.CreateStringExtension();
            try
            {
                string text = "{12345:";

                // Act
                var result = StringExtension.VerifyBodyContent(
                    text);

                // Assert
                Assert.NotNull(result.ParsedText);
                Assert.True(result.IsEncoded);
            }
            catch (Exception)
            {

                Assert.False(false);
            }
          
            this.mockRepository.VerifyAll();
        }
        [Fact]
        public void ToCamelCase_StateUnderTest_ExpectedBeha()
        {
            // Arrange
            string str = "testCases";

            // Act
            var result = StringExtension.ToCamelCase(
                str);

            // Assert
            Assert.Equal(result,str);
            this.mockRepository.VerifyAll();
        }

    }
}
