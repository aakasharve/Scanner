﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Moq;
using Neighborly.Chassis.Formatter;
using System;
using System.Threading.Tasks;
using Xunit;
using static Neighborly.Chassis.Formatter.ApiProblemDetailsMember;

namespace Neighborly.Chassis.Formatter
{
    public class ApiProblemDetailsMemberTests
    {
        private MockRepository mockRepository;
        private Mock<HttpRequest> mockRequest;
        private Mock<HttpResponse> mockResponse;
        private Mock<HttpContext> mockContext;
        private Mock<IActionResultExecutor<ObjectResult>> mockActionResult;
        private IActionResultExecutor<ObjectResult> _executor { get; }


        public ApiProblemDetailsMemberTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
            this.mockContext = this.mockRepository.Create<HttpContext>();
            this.mockRequest = this.mockRepository.Create<HttpRequest>();
            this.mockActionResult = this.mockRepository.Create<IActionResultExecutor<ObjectResult>>();

        }

        private ApiProblemDetailsMember CreateApiProblemDetailsMember()
        {
            return new ApiProblemDetailsMember();
        }

        [Fact]
        public async Task WriteProblemDetailsAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var apiProblemDetailsMember = this.CreateApiProblemDetailsMember();
            HttpContext context1 = this.mockContext.Object;
            HttpContext context = new DefaultHttpContext();
           
            object body = new object();
            Exception exception = new Exception() { HelpLink = "https://www.includehelp.com" };
            ExceptionFallback excFallback = new ExceptionFallback(exception);
            DebugExceptionetails debugDetailsObject = new DebugExceptionetails(excFallback);
            Exception exceptionObj = new Exception() { HelpLink = "www.google.com" };
            ExceptionFallback excFallbackObj = new ExceptionFallback(exceptionObj);
            DebugExceptionetails debugDetailsObj = new DebugExceptionetails(excFallbackObj);
            bool isDebug = false;
            mockActionResult.Setup(x => x.ExecuteAsync(It.IsAny<ActionContext>(), It.IsAny<ObjectResult>())).Returns(Task.CompletedTask);

            await apiProblemDetailsMember.WriteProblemDetailsAsync(
                context,
                mockActionResult.Object,
                body,
                exception,
                isDebug);

            // Assert
            Assert.NotNull(apiProblemDetailsMember);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task WriteProblemDetailsAsync_StateUnderTest_ExpectedBehaviorForNullException()
        {
            // Arrange
            var apiProblemDetailsMember = this.CreateApiProblemDetailsMember();
            
            HttpContext context1 = this.mockContext.Object;
            HttpContext context = new DefaultHttpContext();
            object body = new object();
            Exception exception = null;
            bool isDebug = false;
            mockActionResult.Setup(x => x.ExecuteAsync(It.IsAny<ActionContext>(), It.IsAny<ObjectResult>())).Returns(Task.CompletedTask);

            await apiProblemDetailsMember.WriteProblemDetailsAsync(
                context,
                mockActionResult.Object,
                body,
                exception,
                isDebug);

            // Assert
            Assert.NotNull(apiProblemDetailsMember);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task WriteProblemDetailsAsync_StateUnderTest_ExpectedBehaviorForWithIsDebugTrue()
        {
            // Arrange
            var apiProblemDetailsMember = this.CreateApiProblemDetailsMember();

            HttpContext context1 = this.mockContext.Object;
            HttpContext context = new DefaultHttpContext();
            object body = new object();
            Exception exception = new Exception();
            bool isDebug = true;
            mockActionResult.Setup(x => x.ExecuteAsync(It.IsAny<ActionContext>(), It.IsAny<ObjectResult>())).Returns(Task.CompletedTask);

            await apiProblemDetailsMember.WriteProblemDetailsAsync(
                context,
                mockActionResult.Object,
                body,
                exception,
                isDebug);

            // Assert
            Assert.NotNull(apiProblemDetailsMember);
            this.mockRepository.VerifyAll();
        }
    }
}
