﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Moq;
using Neighborly.Chassis.Formatter;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Formatter
{
    public class FormatterMembersTests
    {
        private MockRepository mockRepository;
        private Mock<HttpRequest> mockRequest;
        private Mock<FormatterOptions> mockFormatterOptions;
        private Mock<ILogger<FormatterMiddleware>> mockLogger;
        private Mock<JsonSerializerSettings> mockJsonSerializerSettings;
        private Mock<Dictionary<string, string>> mockDictionary;

        public FormatterMembersTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockFormatterOptions = this.mockRepository.Create<FormatterOptions>();
            this.mockLogger = this.mockRepository.Create<ILogger<FormatterMiddleware>>();
            this.mockJsonSerializerSettings = this.mockRepository.Create<JsonSerializerSettings>();
            this.mockDictionary = this.mockRepository.Create<Dictionary<string, string>>();
            this.mockRequest = this.mockRepository.Create<HttpRequest>();
        }

        private FormatterMembers CreateFormatterMembers()
        {
            mockFormatterOptions.Object.UseCustomExceptionFormat = true;
            return new FormatterMembers(
                this.mockFormatterOptions.Object,
                null,
                this.mockJsonSerializerSettings.Object,
                this.mockDictionary.Object
                );
        }



        [Fact]
        public async Task ReadResponseBodyStreamAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            Stream bodyStream = new MemoryStream();

            // Act
            var result = await formatterMembers.ReadResponseBodyStreamAsync(
                bodyStream);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }


        [Fact]
        public async Task HandleExceptionAsync_StateUnderTest_ExpectedBehaviorForUnAuthException()
        {
            // Arrange
            try
            {
                var formatterMembers = this.CreateFormatterMembers();
                HttpContext context = new DefaultHttpContext();

                UnauthorizedAccessException exception = new UnauthorizedAccessException();

                // Act
                await formatterMembers.HandleExceptionAsync(
                    context,
                    exception);
            }
            // Assert
            catch (Exception)
            {
                Assert.False(false);
            }

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleExceptionAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            try
            {
                var formatterMembers = this.CreateFormatterMembers();
                HttpContext context = new DefaultHttpContext();
                Exception exception = new Exception();

                // Act
                await formatterMembers.HandleExceptionAsync(
                    context,
                    exception);
            }
            // Assert
            catch (Exception)
            {
                Assert.False(false);
            }

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleExceptionAsync_StateUnderTest_ExpectedBehaviorForApiException()
        {
            try
            {
                // Arrange
                var formatterMembers = this.CreateFormatterMembers();
                HttpContext context = new DefaultHttpContext();
                ApiException exception = new ApiException("", 200, "", "");
                exception.IsModelValidatonError = true;
                mockFormatterOptions.Object.UseCustomExceptionFormat = false;
                // Act
                await formatterMembers.HandleExceptionAsync(
                    context,
                    exception);
            }
            // Assert
            catch (Exception)
            {
                Assert.False(false);
            }

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleUnsuccessfulRequestAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            object body = new object();
            int httpStatusCode = 0;

            // Act
            await formatterMembers.HandleUnsuccessfulRequestAsync(
                context,
                body,
                httpStatusCode);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }


        [Fact]
        public async Task HandleNotApiRequestAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();

            // Act
            await formatterMembers.HandleNotApiRequestAsync(
                context);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }


        [Fact]
        public void IsExclude_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();

            // Act
            var result = formatterMembers.IsExclude(
                context,
                null);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsExclude_StateUnderTest_ExpectedBehaviorForFormatterExcludePath()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            IEnumerable<FormatterExcludePath> objn = new List<FormatterExcludePath> { new FormatterExcludePath("") { } };
            // Act
            var result = formatterMembers.IsExclude(
                 context,
                 objn);

            // Assert
            Assert.True(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsApi_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();

            // Act
            var result = formatterMembers.IsApi(
                context);

            // Assert
            Assert.True(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task WrapIgnoreAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            object body = new object();

            // Act
            await formatterMembers.WrapIgnoreAsync(
                context,
                body);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsRequestSuccessful_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            int statusCode = 201;

            // Act
            var result = formatterMembers.IsRequestSuccessful(
                statusCode);

            // Assert
            Assert.True(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsRequestSuccessful_StateUnderTest_ExpectedBehaviorConditonOne()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            int statusCode = 501;

            // Act
            var result = formatterMembers.IsRequestSuccessful(
                statusCode);

            // Assert
            Assert.False(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsRequestSuccessful_StateUnderTest_ExpectedBehaviorConditionTwo()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            int statusCode = 100;

            // Act
            var result = formatterMembers.IsRequestSuccessful(
                statusCode);

            // Assert
            Assert.False(result);
            this.mockRepository.VerifyAll();
        }
        [Fact]
        public async Task GetRequestBodyAsync_StateUnderTest_ExpectedBehavior()
        {
            //Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext httpContext = new DefaultHttpContext();
            System.IO.Stream _memoryStream = new System.IO.MemoryStream();
            mockRequest.Setup(x => x.Method).Returns("POST");
            mockRequest.Setup(x => x.Body).Returns(_memoryStream);

            // Act
            var result = await formatterMembers.GetRequestBodyAsync(
                mockRequest.Object);

            //Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task GetRequestBodyAsync_StateUnderTest_ExpectedBehaviorForRequestBody()
        {
            //Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext httpContext = new DefaultHttpContext();
            System.IO.Stream _memoryStream = new System.IO.MemoryStream();
            mockRequest.Setup(x => x.Method).Returns("ABC");
            mockRequest.Setup(x => x.Body).Returns(_memoryStream);

            // Act
            var result = await formatterMembers.GetRequestBodyAsync(
                mockRequest.Object);

            //Assert
            Assert.NotNull(result);
        }

        [Fact]
        public async Task HandleExceptionAsync_StateUnderTest_ExpectedBehaviorForApiExceptionModelValidationError()
        {
            try
            {
                // Arrange
                var formatterMembers = this.CreateFormatterMembers();
                HttpContext context = new DefaultHttpContext();
                ApiException exception = new ApiException("", 200, "", "");
                exception.IsModelValidatonError = false;

                // Act
                await formatterMembers.HandleExceptionAsync(
                    context,
                    exception);
            }
            // Assert
            catch (Exception)
            {
                Assert.False(false);
            }

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleExceptionAsync_StateUnderTest_ExpectedBehaviorOptions()
        {
            // Arrange
            try
            {
                var formatterMembers = this.CreateFormatterMembers();
                mockFormatterOptions.Object.UseCustomExceptionFormat = false;
                HttpContext context = new DefaultHttpContext();

                UnauthorizedAccessException exception = new UnauthorizedAccessException();

                // Act
                await formatterMembers.HandleExceptionAsync(
                    context,
                    exception);
            }
            // Assert
            catch (Exception)
            {
                Assert.False(false);
            }

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleExceptionAsync_StateUnderTest_ExpectedBehaviorOptionsIsDebugCondition()
        {
            // Arrange
            try
            {
                var formatterMembers = this.CreateFormatterMembers();
                mockFormatterOptions.Object.UseCustomExceptionFormat = false;
                mockFormatterOptions.Object.IsDebug = true;
                HttpContext context = new DefaultHttpContext();

                Exception exception = new Exception();

                // Act
                await formatterMembers.HandleExceptionAsync(
                    context,
                    exception);
            }
            // Assert
            catch (Exception)
            {
                Assert.False(false);
            }

            this.mockRepository.VerifyAll();
        }


        [Fact]
        public async Task HandleUnsuccessfulRequestAsync_StateUnderTest_ExpectedBehaviorWithBody()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            object body = "Test";
            int httpStatusCode = 0;

            // Act
            await formatterMembers.HandleUnsuccessfulRequestAsync(
                context,
                body,
                httpStatusCode);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleUnsuccessfulRequestAsync_StateUnderTest_ExpectedBehaviorWithEmptyBody()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            object body = "";
            int httpStatusCode = 204;

            // Act
            await formatterMembers.HandleUnsuccessfulRequestAsync(
                context,
                body,
                httpStatusCode);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleUnsuccessfulRequestAsync_StateUnderTest_ExpectedBehaviorForUseCustomException()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            string plainText = "trxt";
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            var testStr = System.Convert.ToBase64String(plainTextBytes);
            string encodedStr = Convert.ToBase64String(Encoding.UTF8.GetBytes("inputStr"));
            string inputStr = Encoding.UTF8.GetString(Convert.FromBase64String(encodedStr));


            string unicodeString = "Maths use \u03a0 (Pi) for calculations";
            HttpContext context = new DefaultHttpContext();
            byte[] asciiBytes = Encoding.ASCII.GetBytes(unicodeString);
            // You can convert a byte array into a char array
            char[] asciiChars = Encoding.ASCII.GetChars(asciiBytes);
            string asciiString = new string(asciiChars);

            //string body = "Test"
            int httpStatusCode = 0;

            // Act
            await formatterMembers.HandleUnsuccessfulRequestAsync(
                context,
                encodedStr,
                httpStatusCode);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsExclude_StateUnderTest_ExpectedBehaviorForFormatterExcludeModeStartsWith()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();

            IEnumerable<FormatterExcludePath> objn = new List<FormatterExcludePath> { new FormatterExcludePath("") { ExcludeMode = ExcludeMode.StartWith } };

            // Act
            var result = formatterMembers.IsExclude(
               context,
               objn);

            // Assert
            Assert.True(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsExclude_StateUnderTest_ExpectedBehaviorForFormatterExcludeModeRegEx()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            IEnumerable<FormatterExcludePath> objn = new List<FormatterExcludePath> { new FormatterExcludePath("") { ExcludeMode = ExcludeMode.Regex } };
            // Act
            var result = formatterMembers.IsExclude(
                context,
                objn);

            // Assert
            Assert.True(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void IsApi_StateUnderTest_ExpectedBehaviorWithIsApiOnly()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            mockFormatterOptions.Object.IsApiOnly = false;
            // Act
            var result = formatterMembers.IsApi(
                context);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task WrapIgnoreAsync_StateUnderTest_ExpectedBehaviorForConditionTwo()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            object body = "test";

            // Act
            await formatterMembers.WrapIgnoreAsync(
                context,
                body);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleUnsuccessfulRequestAsync_StateUnderTest_ExpectedBehaviorStatusCode400()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            object body = string.Empty;
            int httpStatusCode = 400;

            // Act
            await formatterMembers.HandleUnsuccessfulRequestAsync(
                context,
                body,
                httpStatusCode);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleUnsuccessfulRequestAsync_StateUnderTest_ExpectedBehaviorStatusCode401()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            object body = string.Empty;
            int httpStatusCode = 401;

            // Act
            await formatterMembers.HandleUnsuccessfulRequestAsync(
                context,
                body,
                httpStatusCode);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleUnsuccessfulRequestAsync_StateUnderTest_ExpectedBehaviorStatusCode404()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            object body = "";
            int httpStatusCode = 404;

            // Act
            await formatterMembers.HandleUnsuccessfulRequestAsync(
                context,
                body,
                httpStatusCode);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleUnsuccessfulRequestAsync_StateUnderTest_ExpectedBehaviorStatusCode405()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            object body = string.Empty;
            int httpStatusCode = 405;

            // Act
            await formatterMembers.HandleUnsuccessfulRequestAsync(
                context,
                body,
                httpStatusCode);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleUnsuccessfulRequestAsync_StateUnderTest_ExpectedBehaviorStatusCode415()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            object body = string.Empty;
            int httpStatusCode = 415;

            // Act
            await formatterMembers.HandleUnsuccessfulRequestAsync(
                context,
                body,
                httpStatusCode);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleExceptionAsync_StateUnderTest_ExpectedBehaviorOptionsCondition3()
        {
            // Arrange
            try
            {
                var formatterMembers = this.CreateFormatterMembers();
                mockFormatterOptions.Object.UseCustomExceptionFormat = false;
                mockFormatterOptions.Object.IsDebug = true;
                mockFormatterOptions.Object.ShowStatusCode = true;
                mockFormatterOptions.Object.EnableExceptionLogging = false;

                HttpContext context = new DefaultHttpContext();

                Exception exception = new Exception();

                // Act
                await formatterMembers.HandleExceptionAsync(
                    context,
                    exception);
            }
            // Assert
            catch (Exception)
            {
                Assert.False(false);
            }

            this.mockRepository.VerifyAll();
        }



        [Fact]
        public async Task HandleExceptionAsync_StateUnderTest_ExpectedBehaviorOptionsWithIsDebugFalse()
        {
            // Arrange
            try
            {
                var formatterMembers = this.CreateFormatterMembers();
                mockFormatterOptions.Object.UseCustomExceptionFormat = false;
                mockFormatterOptions.Object.IsDebug = false;
                mockFormatterOptions.Object.ShowStatusCode = true;
                mockFormatterOptions.Object.EnableExceptionLogging = false;

                HttpContext context = new DefaultHttpContext();

                Exception exception = new Exception();

                // Act
                await formatterMembers.HandleExceptionAsync(
                    context,
                    exception);
            }
            // Assert
            catch (Exception)
            {
                Assert.False(false);
            }

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task HandleUnsuccessfulRequestAsync_StateUnderTest_ExpectedBehaviorStatusCodeInvalid()
        {
            // Arrange
            var formatterMembers = this.CreateFormatterMembers();
            HttpContext context = new DefaultHttpContext();
            object body = string.Empty;
            int httpStatusCode = 100;

            // Act
            await formatterMembers.HandleUnsuccessfulRequestAsync(
                context,
                body,
                httpStatusCode);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

    }
}
