﻿using Neighborly.Chassis.Formatter;
using System;
using System.Collections.Generic;
using System.Text;

namespace Neighborly.Models
{
    public class MapResponseCustomErrorObject
    {
        [FormatterPropertyMap(Prop.ResponseException)]
        public object Error { get; set; }
    }
    public class Error
    {
        public string Message { get; set; }

        public string Code { get; set; }
        public InnerError InnerError { get; set; }

        public Error(string message, string code, InnerError inner)
        {
            this.Message = message;
            this.Code = code;
            this.InnerError = inner;
        }

    }

    public class InnerError
    {
        public string RequestId { get; set; }
        public long Date { get; set; }

        public InnerError(string reqId, long reqDate)
        {
            this.RequestId = reqId;
            this.Date = reqDate;
        }
    }
}
