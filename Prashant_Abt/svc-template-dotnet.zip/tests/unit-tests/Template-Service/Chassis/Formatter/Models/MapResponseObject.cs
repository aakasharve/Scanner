﻿
using Neighborly.Chassis.Formatter;

namespace Neighborly.Models
{
    public class MapResponseObject
    {
        [FormatterPropertyMap(Prop.Result)]
        public object Data { get; set; }
    }
}
