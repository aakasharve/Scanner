﻿using Neighborly.Chassis.Repository;

namespace Neighborly.Models
{
    public class MoqItemEntity : ItemBase
    {
        /// <summary>
        ///     Title of the To-Do-Item
        /// </summary>
        public string Title { get; set; }

    }
}
