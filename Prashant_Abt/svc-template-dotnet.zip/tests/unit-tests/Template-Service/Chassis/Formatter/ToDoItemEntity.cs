﻿namespace Neighborly.Chassis.Formatter
{
    internal class ToDoItemEntity
    {
    }
}