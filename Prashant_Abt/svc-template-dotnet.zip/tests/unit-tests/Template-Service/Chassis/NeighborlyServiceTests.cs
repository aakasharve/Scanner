﻿using Moq;
using Neighborly.Chassis;
using System;
using Xunit;

namespace Neighborly.Chassis
{
    public class NeighborlyServiceTests
    {
        private MockRepository mockRepository;



        public NeighborlyServiceTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private NeighborlyService CreateService()
        {
            return new NeighborlyService();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var service = this.CreateService();

            // Act
            var result = (service.Id);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
    }
}
