﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Moq;
using Neighborly.Chassis.Logging;
using System;
using System.Threading.Tasks;
using Xunit;
using System.Threading;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace Neighborly.Chassis.Logging
{
    public class CorrelationContextLoggingMiddlewareTests
    {  
        private MockRepository mockRepository;
        
        private Mock<ILogger<CorrelationContextLoggingMiddleware>> mockLogger;

        public CorrelationContextLoggingMiddlewareTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockLogger = this.mockRepository.Create<ILogger<CorrelationContextLoggingMiddleware>>();
        }

        private CorrelationContextLoggingMiddleware CreateCorrelationContextLoggingMiddleware()
        {
            return new CorrelationContextLoggingMiddleware(
                this.mockLogger.Object);
        }

        [Fact]
        public async Task InvokeAsync_StateUnderTest_ExpectedBehavior()
        {
            //Arrange
           //var correlationContextLoggingMiddleware = this.CreateCorrelationContextLoggingMiddleware();
           // HttpContext context = ;
          //  RequestDelegate next = new RequestDelegate() { } ;

           // // Act
           // await correlationContextLoggingMiddleware.InvokeAsync(
           //     context,
           //     next);

           // // Assert
           // Assert.True(true);
           // this.mockRepository.VerifyAll();

            // var correlationContextLoggingMiddleware = this.CreateCorrelationContextLoggingMiddleware();
            // HttpContext context = null;
            // RequestDelegate next = null;//default(global::System.Threading.Tasks.RequestDelegate);
            //// mockLogger.Setup(s => s.LogInformation(It.IsAny<string>(), It.IsAny<Type>()));
            // // Act
            // await correlationContextLoggingMiddleware.InvokeAsync(
            //     context,
            //     next);

            // // Assert
            // Assert.True(true);
            // this.mockRepository.VerifyAll();

        }

        [Fact]
        public async Task UserCorrelationContextLogging()
        {
            var services = new ServiceCollection();
            IServiceProvider serviceprovider = services.BuildServiceProvider();
            IApplicationBuilder app = new ApplicationBuilder(serviceprovider);
            app.UserCorrelationContextLogging();

            CorrelationContextLoggingMiddleware obj = new CorrelationContextLoggingMiddleware(mockLogger.Object);
            HttpContext ctx =

            new DefaultHttpContext()
            {
            };
            RequestDelegate next = (HttpContext hc) => Task.CompletedTask;
            await obj.InvokeAsync(ctx, next);

            //Assert
            Assert.True(true);
        }
    }
}
