﻿using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Channel;
using Microsoft.ApplicationInsights.Extensibility;
using Moq;
using Neighborly.Chassis.Logging;
using System;
using System.Collections.Concurrent;
using Xunit;

namespace Neighborly.Chassis.Logging
{
    public class NeighborlyTelemetryClientTests
    {
        private MockRepository mockRepository;

        private Mock<TelemetryConfiguration> mockTelemetryConfiguration;

        public NeighborlyTelemetryClientTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            //this.mockTelemetryConfiguration = this.mockRepository.Create<TelemetryConfiguration>();
        }

        private NeighborlyTelemetryClient CreateNeighborlyTelemetryClient(TelemetryConfiguration mockTelemetryConfig)
        {
            return new NeighborlyTelemetryClient(
               mockTelemetryConfig);
        }

        [Fact]
        public void Dispose_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            MockTelemetryChannel mockTelemetryChannel = new MockTelemetryChannel();
            TelemetryConfiguration mockTelemetryConfig = new TelemetryConfiguration
            {
                TelemetryChannel = mockTelemetryChannel,
                InstrumentationKey = Guid.NewGuid().ToString(),
            };

            //// Act
            var neighborlyTelemetryClient = this.CreateNeighborlyTelemetryClient(mockTelemetryConfig);

            var result = (neighborlyTelemetryClient.TelemetryClient);

            neighborlyTelemetryClient.Dispose();

            //// Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();

        }
    }

    public class MockTelemetryChannel : ITelemetryChannel
    {
        public ConcurrentBag<ITelemetry> SentTelemtries = new ConcurrentBag<ITelemetry>();
        public bool IsFlushed { get; private set; }
        public bool? DeveloperMode { get; set; }
        public string EndpointAddress { get; set; }

        public void Send(ITelemetry item)
        {
            this.SentTelemtries.Add(item);
        }

        public void Flush()
        {
            this.IsFlushed = true;
        }

        public void Dispose()
        {

        }
    }
}
