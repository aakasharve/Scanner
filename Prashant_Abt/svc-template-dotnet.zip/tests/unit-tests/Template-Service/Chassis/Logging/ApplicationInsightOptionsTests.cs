﻿using Moq;
using Neighborly.Chassis.Logging;
using System;
using Xunit;

namespace Neighborly.Chassis.Logging
{
    public class ApplicationInsightOptionsTests
    {
        private MockRepository mockRepository;



        public ApplicationInsightOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private ApplicationInsightOptions CreateApplicationInsightOptions()
        {
            return new ApplicationInsightOptions();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var applicationInsightOptions = this.CreateApplicationInsightOptions();
            applicationInsightOptions.Enabled = true;
            applicationInsightOptions.InstrumentationKey = "test";
            // Act
            var result = (applicationInsightOptions.Enabled,
                           applicationInsightOptions.InstrumentationKey);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
    }
}
