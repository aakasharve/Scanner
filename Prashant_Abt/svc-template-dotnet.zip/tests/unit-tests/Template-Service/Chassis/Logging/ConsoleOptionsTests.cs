﻿using Moq;
using Neighborly.Chassis.Logging;
using System;
using Xunit;

namespace Neighborly.Chassis.Logging
{
    public class ConsoleOptionsTests
    {
        private MockRepository mockRepository;



        public ConsoleOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private ConsoleOptions CreateConsoleOptions()
        {
            return new ConsoleOptions();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var consoleOptions = this.CreateConsoleOptions();
            consoleOptions.Enabled = true;
            // Act
            var result = (consoleOptions.Enabled);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
    }
}
