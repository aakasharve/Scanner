﻿using Moq;
using Neighborly.Chassis.Logging;
using System;
using Xunit;

namespace Neighborly.Chassis.Logging
{
    public class FileOptionsTests
    {
        private MockRepository mockRepository;



        public FileOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private FileOptions CreateFileOptions()
        {
            return new FileOptions();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var fileOptions = this.CreateFileOptions();
            fileOptions.Enabled = true;
            fileOptions.Interval = "test";
            fileOptions.Path = "test";
            // Act
            var result = ( fileOptions.Enabled,
                           fileOptions.Interval,
                           fileOptions.Path);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
    }
}
