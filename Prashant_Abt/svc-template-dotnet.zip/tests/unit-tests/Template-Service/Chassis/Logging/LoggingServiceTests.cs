﻿using Moq;
using Neighborly.Chassis.Logging;
using System;
using Xunit;

namespace Neighborly.Chassis.Logging
{
    public class LoggingServiceTests
    {
        private MockRepository mockRepository;



        public LoggingServiceTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private LoggingService CreateService()
        {
            return new LoggingService();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var service = this.CreateService();

            // Act


            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
