﻿using Moq;
using Neighborly.Chassis.Logging;
using System;
using System.Collections.Generic;
using Xunit;

namespace Neighborly.Chassis.Logging
{
    public class HandlerLogTemplateTests
    {
        private MockRepository mockRepository;



        public HandlerLogTemplateTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private HandlerLogTemplate CreateHandlerLogTemplate()
        {
            return new HandlerLogTemplate();
        }

       
        [Fact]
        public void GetExceptionTemplate_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var handlerLogTemplate = this.CreateHandlerLogTemplate();
            handlerLogTemplate.Before = "testBefore";
            handlerLogTemplate.After = "testAfter";
            handlerLogTemplate.OnError = new Dictionary<Type, string>();
            Exception exc = new Exception();
            var result = (handlerLogTemplate.After,
            handlerLogTemplate.Before,
            handlerLogTemplate.OnError);
            // Assert
            //Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void GetExceptionTemplate_StateUnderTest_ExpectedBehaviorTwo()
        {
            // Arrange
            var handlerLogTemplate = this.CreateHandlerLogTemplate();
            Exception exc = new Exception();

            var res = handlerLogTemplate.GetExceptionTemplate(exc);
            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void GetExceptionTemplate_StateUnderTest_ExpectedBehaviorTwo_OnError()
        {
            // Arrange
            var handlerLogTemplate = this.CreateHandlerLogTemplate();
            handlerLogTemplate.OnError = new Dictionary<Type, string>
            {

            };
            Exception exc = new Exception();

            var res = handlerLogTemplate.GetExceptionTemplate(exc);
            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
