﻿namespace Neighborly.Chassis.Logging
{
    internal interface ITelemetryConfiguration
    {
    }
}