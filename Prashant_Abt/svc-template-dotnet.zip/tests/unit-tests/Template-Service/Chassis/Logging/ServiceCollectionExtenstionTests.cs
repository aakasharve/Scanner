﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Moq;
using Neighborly.Chassis.Formatter;
using Neighborly.Chassis.Logging;
using Neighborly.Chassis.Swagger;
using Serilog;
using System;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Logging
{
    public class ServiceCollectionExtenstionTests
    {
        private MockRepository mockRepository;

        public ServiceCollectionExtenstionTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [Fact]
        public void UseLogging_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var builder = new WebHostBuilder();
               //.ConfigureServices(services => services
               //         .AddNeighborly()
               //         .AddCorrelationContextLogging()
               //         .AddSwaggerDocs()
               //         .Build())
               //     .Configure(app => app
               //         .UseNeighborly());
             
            Action<LoggerConfiguration> configure = null;
            string loggerSectionName = "logger";
            string appSectionName = "NeighborlyService";
            try
            {
                // Act
                var result = builder.UseLogging(
                    configure,
                    loggerSectionName,
                    appSectionName);
            }
            catch (Exception ex)
            {

                throw;
            }
         

            // Assert
;
        }

        [Fact]
        public void UseLogging_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var builder = new WebHostBuilder()
               .ConfigureServices(services => services
                        .AddNeighborly()
                        .AddCorrelationContextLogging()                       
                        .Build())
                    .Configure(app => app
                        .UseNeighborly());
            Action<LoggerConfiguration> configure = null;
            string loggerSectionName = "logger";
            string appSectionName = null;

            // Act
            var result = ServiceCollectionExtenstion.UseLogging(
                builder,
                configure,
                loggerSectionName,
                appSectionName);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void MapLogLevelHandler_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            //IEndpointRouteBuilder builder = null;
            //string endpointRoute = null;

            //// Act
            //var result = ServiceCollectionExtenstion.MapLogLevelHandler(
            //    builder,
            //    endpointRoute);

            //// Assert
            //Assert.True(false);
            //this.mockRepository.VerifyAll();
        }

        [Fact]
        public void AddCorrelationContextLogging_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            //INeighborlyBuilder builder = null;

            //// Act
            //var result = ServiceCollectionExtenstion.AddCorrelationContextLogging(
            //    builder);

            //// Assert
            //Assert.True(false);
            //this.mockRepository.VerifyAll();
        }

        [Fact]
        public void UserCorrelationContextLogging_StateUnderTest_ExpectedBehavior()
        {
            //// Arrange
            //IApplicationBuilder app = null;

            //// Act
            //var result = ServiceCollectionExtenstion.UserCorrelationContextLogging(
            //    app);

            //// Assert
            //Assert.True(false);
            //this.mockRepository.VerifyAll();
        }
    }
}
