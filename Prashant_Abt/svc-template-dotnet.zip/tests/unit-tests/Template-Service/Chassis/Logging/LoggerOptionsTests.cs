﻿using Moq;
using Neighborly.Chassis.Logging;
using System;
using System.Collections.Generic;
using Xunit;

namespace Neighborly.Chassis.Logging
{
    public class LoggerOptionsTests
    {
        private MockRepository mockRepository;



        public LoggerOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private LoggerOptions CreateLoggerOptions()
        {
            return new LoggerOptions();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var loggerOptions = this.CreateLoggerOptions();

            // Act
            loggerOptions.Level = "Level";
            loggerOptions.Console = new ConsoleOptions { Enabled = true };
            loggerOptions.File = new FileOptions { Enabled = true, Interval = "2", Path = "testpath" };
            loggerOptions.ApplicationInsight = new ApplicationInsightOptions { Enabled = true, InstrumentationKey = "dsadas9d87as9dad" };
            loggerOptions.MinimumLevelOverrides = new Dictionary<string, string>();
            loggerOptions.ExcludePaths = new List<string>();
            loggerOptions.ExcludeProperties = new List<string>();
            loggerOptions.Tags = new Dictionary<string, object>();
            LoggerOptions options = new LoggerOptions
            {
                Level = loggerOptions.Level,
                Console = loggerOptions.Console,
                File = loggerOptions.File,
                ApplicationInsight = loggerOptions.ApplicationInsight,
                MinimumLevelOverrides = loggerOptions.MinimumLevelOverrides,
                ExcludePaths = loggerOptions.ExcludePaths,
                ExcludeProperties = loggerOptions.ExcludeProperties,
                Tags = loggerOptions.Tags

            };
            ILoggingService loggingServiceInterface = new LoggingService();
            loggingServiceInterface.SetLoggingLevel("Fatal");

            //Assert
            Assert.True(true);

        }
    }
}
