﻿using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Mediator
{
    public class MediatorTests
    {
        private MockRepository mockRepository;
        private readonly Mock<IMediatorServiceProvider> mockServiceProvider;
        public MediatorTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Loose);
            this.mockServiceProvider = this.mockRepository.Create<IMediatorServiceProvider>();
        }

        private Mediator CreateMediator()
        {
            return new Mediator(mockServiceProvider.Object);
        }

        [Fact]
        public async Task SendAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mediator = this.CreateMediator();
            ICommand cmd = new MockCommand { };
            IEnumerable<IPipeline> p = Enumerable.Empty<IPipeline>();
            ICommandHandler<MockCommand> ch = new MockCommandHandler();
            ISender<MockCommand> mockResponse = new Sender<MockCommand>(ch, p);
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            mockServiceProvider.Setup(x => x.BuildService<ISender<MockCommand>>()).Returns(mockResponse);

            try
            {
                // Act
                await mediator.SendAsync(
                 cmd,
                 ct);
                // Assert
                Assert.True(true);
            }
            catch
            {
                // Assert
                Assert.True(false);
            }

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task SendAsync_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var mediator = this.CreateMediator();
            ICommand<object> cmd = new MockResultCommand();
            IEnumerable<IPipeline> p = Enumerable.Empty<IPipeline>();
            ICommandHandler<MockResultCommand, object> ch = new MockResultCommandHandler();
            ISender<MockResultCommand, object> mockResponse = new Sender<MockResultCommand, object>(ch, p);
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            mockServiceProvider.Setup(x => x.BuildService<ISender<MockResultCommand, object>>()).Returns(mockResponse);

            try
            {
                // Act
                await mediator.SendAsync<object>(
                               cmd,
                               ct);
                // Assert
                Assert.True(true);
            }
            catch
            {
                // Assert
                Assert.True(false);
            }

            this.mockRepository.VerifyAll();
        }

        [Fact]
        public async Task BroadcastAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var mediator = this.CreateMediator();
            IEvent evt = new MockEvent();
            IEnumerable<IPipeline> p = Enumerable.Empty<IPipeline>();
            IEnumerable<IEventHandler<MockEvent>> ch = Enumerable.Empty<MockEventHandler>();
            IBroadcaster<MockEvent> mockResponse = new Broadcaster<MockEvent>(ch, p);
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            mockServiceProvider.Setup(x => x.BuildService<IBroadcaster<MockEvent>>()).Returns(mockResponse);

            try
            {
                // Act
                await mediator.BroadcastAsync(
                    evt,
                    ct);
                // Assert
                Assert.True(true);
            }
            catch
            {
                // Assert
                Assert.True(false);
            }

            this.mockRepository.VerifyAll();
        }

        //[Fact]
        //public async Task FetchAsync_StateUnderTest_ExpectedBehavior()
        //{
        //    // Arrange
        //    var mediator = this.CreateMediator();
        //    IQuery<ToDoItemEntity> query = null;
        //    CancellationToken ct = default(global::System.Threading.CancellationToken);
        //    IEnumerable<IPipeline> p = Enumerable.Empty<IPipeline>();
        //    ICommandHandler<MockResultCommand, object> ch = new MockResultCommandHandler();
        //    ISender<MockResultCommand, object> mockResponse = new Sender<MockResultCommand, object>(ch, p);
        //    mockServiceProvider.Setup(x => x.BuildService<ISender<MockResultCommand, object>>()).Returns(mockResponse);
            
        //    // Act
        //    var result = await mediator.FetchAsync(
        //        query,
        //        ct);

        //    // Assert
        //    Assert.True(false);
        //    this.mockRepository.VerifyAll();
        //}
    }
}
