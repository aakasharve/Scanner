﻿using System;
using Xunit;

namespace Neighborly
{
    public class EventTests
    {
        [Fact]
        public void GivenAnEventWhenUsingDefaultConstructorThenDefaultValuesMustBeUsed()
        {
            var now = DateTimeOffset.Now;

            var evt = new MockEvent();

            Assert.NotEqual(default, evt.Id);
            Assert.NotEqual(default, evt.CreatedOn);
            Assert.True(now <= evt.CreatedOn && evt.CreatedOn <= DateTimeOffset.Now);
            Assert.Null(evt.CreatedBy);
        }

        [Fact]
        public void GivenAnEventWhenUsingConstructorWithParametersThenAllValuesMustBeEqual()
        {
            var id = Guid.NewGuid();
            var createdOn = DateTimeOffset.Now.AddMinutes(-1);
            const string createdBy = "test-user";

            var evt = new MockEvent(id, createdOn, createdBy);

            Assert.Equal(id, evt.Id);
            Assert.Equal(createdOn, evt.CreatedOn);
            Assert.Equal(createdBy, evt.CreatedBy);
        }
    }
}
