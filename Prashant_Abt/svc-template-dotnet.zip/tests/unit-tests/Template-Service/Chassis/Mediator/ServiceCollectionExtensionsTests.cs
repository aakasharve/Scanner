﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Moq;
using Neighborly.Chassis.Mediator.Behaviour.Logging;
using Neighborly.Chassis.Mediator.Behaviour.Validation;
using Serilog;
using System;
using System.Reflection;
using Xunit;

namespace Neighborly.Chassis.Mediator
{
    public class ServiceCollectionExtensionsTests
    {
        private MockRepository mockRepository;



        public ServiceCollectionExtensionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        public class MyClass
        { 
            public string Id { get; set; } 
        }
        
        [Fact]
        public void AddMediator_StateUnderTest_ExpectedBehavior()
        {
            // Arrange

            IServiceCollection services = new ServiceCollection();
            Action<MediatorOptions> config = null;

            // Act
            ServiceCollectionExtensions.AddMediator(
                services,
                config);

            // Assert
            this.mockRepository.VerifyAll();
            Assert.True(true);
        }

        [Fact]
        public void AddPipeline_StateUnderTest_ExpectedBehavior_Null()
        {
            // Arrange
            MediatorOptions options = null;
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            Assert.Throws<ArgumentNullException>(() =>
           ServiceCollectionExtensions.AddPipeline<ValidationPipeline>(
                options,
                lifetime)
                  );

            //Assert
            Assert.True(true);

        }

        [Fact]
        public void AddPipeline_StateUnderTest_ExpectedBehavior_NotNull()
        {
            // Arrange
            MediatorOptions options = new MediatorOptions(new ServiceCollection());
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act

            ServiceCollectionExtensions.AddPipeline<ValidationPipeline>(
                 options,
                 lifetime);

            //Assert
            Assert.True(true);


        }

        [Fact]
        public void AddPipeline_StateUnderTest_ExpectedBehavior1_Null()
        {
            // Arrange
            MediatorOptions options = null;
            Func<IServiceProvider, IPipeline> factory = null;
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            Assert.Throws<ArgumentNullException>(() => ServiceCollectionExtensions.AddPipeline(
                options,
                factory,
                lifetime));

            //Assert
            Assert.True(true);
        }
        [Fact]
        public void AddPipeline_StateUnderTest_ExpectedBehavior1_NotNull()
        {
            // Arrange
            MediatorOptions options = new MediatorOptions(new ServiceCollection()) { Lifetime = new ServiceLifetime(),ServiceProviderLifetime = new ServiceLifetime()};
            IOptions<LoggingPipelineOptions> voptions = null;
            ILogger logger = null;
            Func<IServiceProvider, IPipeline> factory = new Func<IServiceProvider, IPipeline>(delegate { return new LoggingPipeline(voptions, logger); });
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            ServiceCollectionExtensions.AddPipeline(
                options,
                factory,
                lifetime);

            //Assert
            Assert.True(true);
        }


        [Fact]
        public void AddPipeline_StateUnderTest_ExpectedBehavior2_NullOptions()
        {
            // Arrange
            MediatorOptions options = null;
            LoggingPipeline instance = null;

            // Act
            Assert.Throws<ArgumentNullException>(() => ServiceCollectionExtensions.AddPipeline(
                options,
                instance));

            //Assert
            Assert.True(true);

        }

        [Fact]
        public void AddPipeline_StateUnderTest_ExpectedBehavior2_NullInstance()
        {
            // Arrange
            MediatorOptions options = new MediatorOptions(new ServiceCollection());
            LoggingPipeline instance = null;

            // Act
            Assert.Throws<ArgumentNullException>(() => ServiceCollectionExtensions.AddPipeline(
                options,
                instance));

            //Assert
            Assert.True(true);

        }

        [Fact]
        public void AddPipeline_StateUnderTest_ExpectedBehavior2_NotNull()
        {
            // Arrange
            MediatorOptions options = new MediatorOptions(new ServiceCollection());
            Mock<IOptions<LoggingPipelineOptions>> voptions = new Mock<IOptions<LoggingPipelineOptions>>();
            Mock<ILogger> logger = new Mock<ILogger>();
            var instance = new LoggingPipeline(voptions.Object, logger.Object);

            // Act
            ServiceCollectionExtensions.AddPipeline(
                  options,
                  instance);

            //Assert
            Assert.True(true);

        }


        [Fact]
        public void AddHandlersFromAssemblyOf_StateUnderTest_ExpectedBehavior_NotNull()
        {
            // Arrange
            MediatorOptions options = new MediatorOptions(new ServiceCollection()); 
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            ServiceCollectionExtensions.AddHandlersFromAssemblyOf<MyClass>(
                options,
                lifetime);

            //Assert
            Assert.True(true);
        }

        [Fact]
        public void AddHandlersFromAssembly_StateUnderTest_ExpectedBehavior_NullOptions()
        {
            // Arrange
            MediatorOptions options = null;
            Assembly assembly = null;
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            Assert.Throws<ArgumentNullException>(() => ServiceCollectionExtensions.AddHandlersFromAssembly(
                options,
                assembly,
                lifetime));

            //Assert
            Assert.True(true);

        }

        [Fact]
        public void AddHandlersFromAssembly_StateUnderTest_ExpectedBehavior_NullAssembly()
        {
            // Arrange
            MediatorOptions options = new MediatorOptions(new ServiceCollection()); ;
            Assembly assembly = null;
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            Assert.Throws<ArgumentNullException>(() => ServiceCollectionExtensions.AddHandlersFromAssembly(
                options,
                assembly,
                lifetime));

            //Assert
            Assert.True(true);

        }

        
    }
}
