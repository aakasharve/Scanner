﻿using Microsoft.Extensions.Options;
using Moq;
using Neighborly.Chassis.Mediator.Behaviour.Logging;
using Serilog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Mediator
{
    public class SenderTests
    {
        private MockRepository mockRepository;
        private Mock<ICommandHandler<MockCommand>> mockCommandHandler;
        //IEnumerable<IPipeline> p = Enumerable.Empty<IPipeline>();

        //Mock<IOptions<LoggingPipelineOptions>> voptions = new Mock<IOptions<LoggingPipelineOptions>>();
        //Mock<ILogger> logger = new Mock<ILogger>();

        public SenderTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockCommandHandler = this.mockRepository.Create<ICommandHandler<MockCommand>>();
        }

        private Sender<MockCommand> CreateSender()
        {
            var voptions = Options.Create(new LoggingPipelineOptions { LogCommandResult = true, LogEvent = true, LogQuery = true });
            ILogger logger = new LoggerConfiguration()
                    .WriteTo.Console()
                    .CreateLogger();
            //Mock<ILogger> logger = new Mock<ILogger>();
            var instance = new LoggingPipeline(voptions, logger);
            List<IPipeline> p = new List<IPipeline>();
            p.Add(instance);
            p.ToList().Add(new LoggingPipeline(voptions, logger));
            return new Sender<MockCommand>(
                this.mockCommandHandler.Object,
                p);
        }

        [Fact]
        public async Task SendAsync_StateUnderTest_ExpectedBehavior_exception()
        {
            // Arrange
            var sender = this.CreateSender();
            MockCommand cmd = null;
            CancellationToken ct = default(global::System.Threading.CancellationToken);

            // Act
            try
            {
                await sender.SendAsync(
                cmd,
                ct);

            }
            catch (Exception ex)
            {
                Assert.True(true);
            }
        }

        [Fact]
        public async Task SendAsync_StateUnderTest_ExpectedBehavior_PipelineCountZero()
        {
            //Arrange
            var sender = this.CreateSender();
            MockCommand cmd = new MockCommand { };
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            Mock<ICommandHandler<MockCommand>> handler = new Mock<ICommandHandler<MockCommand>>();
            handler.Setup(s => s.HandleAsync(It.IsAny<MockCommand>(), It.IsAny<CancellationToken>())).Returns(Task<MockCommand>.CompletedTask);

            try
            {
                // Act
                await sender.SendAsync(
                cmd,
                ct);
            }
            catch (Exception ex)
            {

                Assert.True(true);
            }

        }
    }
}
