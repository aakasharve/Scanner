﻿using Microsoft.Extensions.DependencyInjection;
using Moq;
using Neighborly.Chassis.Mediator.Behaviour.Logging;
using System;
using Xunit;

namespace Neighborly.Chassis.Mediator.Behaviour
{
    public class LogginePipelineServiceExtensionTests
    {
        private MockRepository mockRepository;
        public LogginePipelineServiceExtensionTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [Fact]
        public void AddPipelineForLogging_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            MediatorOptions options = new MediatorOptions(new ServiceCollection());
            Action<LoggingPipelineOptions> config = null;
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            var result = LogginePipelineServiceExtension.AddPipelineForLogging(
                options,
                config,
                lifetime);

            //Assert
            Assert.True(true);

        }

        [Fact]
        public void AddPipelineForLogging_StateUnderTest_ExpectedBehavior_NotNull()
        {
            // Arrange
            MediatorOptions options = new MediatorOptions(new ServiceCollection());
            Action<LoggingPipelineOptions> config = new Action<LoggingPipelineOptions>(s=> { });
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            var result = LogginePipelineServiceExtension.AddPipelineForLogging(
                options,
                config,
                lifetime);

            //Assert
            Assert.True(true);

        }

        [Fact]
        public void AddPipelineForLogging_StateUnderTest_ExpectedBehavior_Null()
        {
            // Arrange
            MediatorOptions options = null;
            Action<LoggingPipelineOptions> config = null;
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            Assert.Throws<ArgumentNullException>(() =>
            LogginePipelineServiceExtension.AddPipelineForLogging(
                options,
                config,
                lifetime)
                   );

            //Assert
            Assert.True(true);
        }
    }
}
