﻿using FluentValidation.Results;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;
using Moq;
using Neighborly.Chassis.Mediator.Behaviour.Validation;
using Serilog;
using Serilog.Events;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Mediator.Behaviour
{
    public class ValidationPipelineTests
    {
        private MockRepository mockRepository;

        private Mock<IServiceProvider> mockServiceProvider;
        private Mock<IOptions<ValidationPipelineOptions>> mockOptions;
        private Mock<ILogger> mockLogger;

        public ValidationPipelineTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockServiceProvider = this.mockRepository.Create<IServiceProvider>();
            this.mockOptions = this.mockRepository.Create<IOptions<ValidationPipelineOptions>>();
            this.mockLogger = this.mockRepository.Create<ILogger>();
        }

        private ValidationPipeline CreateValidationPipeline(ValidationPipelineOptions app)
        {
            var services = new ServiceCollection();
            IServiceProvider serviceprovider = services.BuildServiceProvider();

            mockOptions.Setup(ap => ap.Value).Returns(app);
            mockLogger.Setup(l => l.ForContext<ValidationPipeline>()).Returns(mockLogger.Object);
            return new ValidationPipeline(
                serviceprovider,
                this.mockOptions.Object,
                this.mockLogger.Object);
        }

        [Fact]
        public async Task OnCommandAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            ValidationPipelineOptions app = new ValidationPipelineOptions() { FailIfValidatorNotFound = true, ValidateCommand = true, ValidateEvent = true, ValidateQuery = true };
            var validationPipeline = this.CreateValidationPipeline(app);
            Func<ICommand, CancellationToken, Task> next = new Func<ICommand, CancellationToken, Task>(delegate { return Task.FromResult("Test"); });
            //CreateCommand<CreateToDoItemCommand> cmd = new CreateToDoItemCommand("");
            Command cmd = null;
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            //var validator = (IValidator<Command>)Activator.CreateInstance(typeof(Command));

            var serviceProvider = new Mock<IServiceProvider>();
            //serviceProvider
            //    .Setup(x => x.GetService(typeof(IValidator<Command>)))
            //    .Returns();
            //mockServiceProvider.Setup(x => x.GetService(It.IsAny<Type>()));
            // Act
            try
            {
                await validationPipeline.OnCommandAsync(
             next,
             cmd,
             ct);
            }
            catch (Exception e)
            {
                Assert.IsType<InvalidOperationException>(e);
            }


            // Assert
            Assert.True(true);
        }

        //[Fact]
        //public async Task OnCommandAsync_StateUnderTest_ExpectedBehavior1()
        //{
        //    // Arrange
        //    var validationPipeline = this.CreateValidationPipeline();
        //    Func next = null;
        //    TCommand cmd = null;
        //    CancellationToken ct = default(global::System.Threading.CancellationToken);

        //    // Act
        //    var result = await validationPipeline.OnCommandAsync(
        //        next,
        //        cmd,
        //        ct);

        //    // Assert
        //    Assert.True(false);
        //    this.mockRepository.VerifyAll();
        //}

        //[Fact]
        //public async Task OnEventAsync_StateUnderTest_ExpectedBehavior()
        //{
        //    // Arrange
        //    var validationPipeline = this.CreateValidationPipeline();
        //    Func next = null;
        //    TEvent evt = null;
        //    CancellationToken ct = default(global::System.Threading.CancellationToken);

        //    // Act
        //    await validationPipeline.OnEventAsync(
        //        next,
        //        evt,
        //        ct);

        //    // Assert
        //    Assert.True(false);
        //    this.mockRepository.VerifyAll();
        //}

        //[Fact]
        //public async Task OnQueryAsync_StateUnderTest_ExpectedBehavior()
        //{
        //    // Arrange
        //    var validationPipeline = this.CreateValidationPipeline();
        //    Func next = null;
        //    TQuery query = null;
        //    CancellationToken ct = default(global::System.Threading.CancellationToken);

        //    // Act
        //    var result = await validationPipeline.OnQueryAsync(
        //        next,
        //        query,
        //        ct);

        //    // Assert
        //    Assert.True(false);
        //    this.mockRepository.VerifyAll();
        //}
    }
}
