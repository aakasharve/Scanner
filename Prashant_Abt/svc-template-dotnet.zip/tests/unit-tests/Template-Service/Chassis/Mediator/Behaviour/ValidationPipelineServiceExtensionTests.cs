﻿using Microsoft.Extensions.DependencyInjection;
using Moq;
using Neighborly.Chassis.Formatter;
using Neighborly.Chassis.Mediator.Behaviour.Validation;

using System;
using System.Reflection;
using Xunit;

namespace Neighborly.Chassis.Mediator.Behaviour
{
    public class ValidationPipelineServiceExtensionTests
    {
        private MockRepository mockRepository;

        public ValidationPipelineServiceExtensionTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [Fact]
        public void AddPipelineForValidation_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            MediatorOptions options = new MediatorOptions(new ServiceCollection());
            Action<ValidationPipelineOptions> config = new Action<ValidationPipelineOptions>(delegate { return ; });
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            ValidationPipelineOptions valOptions = new ValidationPipelineOptions() { FailIfValidatorNotFound = false, ValidateCommand = false, ValidateEvent = false, ValidateQuery = false, OnFailedValidation =null};
            ValidationPipelineServiceExtension.AddPipelineForValidation(
                options,
                config,
                lifetime);

            //Assert
            Assert.True(true);

        }

        [Fact]
        public void AddPipelineForValidation_StateUnderTest_ExpectedBehavior_Null()
        {
            // Arrange
            MediatorOptions options = new MediatorOptions(new ServiceCollection());
            Action<ValidationPipelineOptions> config = null;
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            ValidationPipelineServiceExtension.AddPipelineForValidation(
                 options,
                 config,
                 lifetime);

            //Assert
            Assert.True(true);

        }

        [Fact]
        public void AddValidatorsFromAssembly_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            MediatorOptions options = new MediatorOptions(new ServiceCollection()); 
            Assembly assembly = typeof(ToDoItemEntity).Assembly;
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            var result = ValidationPipelineServiceExtension.AddValidatorsFromAssembly(
                options,
                assembly,
                lifetime);

            //Assert
            Assert.True(true);

        }

        [Fact]
        public void AddValidatorsFromAssemblyOf_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            MediatorOptions options = null;
            ServiceLifetime lifetime = default(global::Microsoft.Extensions.DependencyInjection.ServiceLifetime);

            // Act
            ValidationPipelineServiceExtension.AddValidatorsFromAssemblyOf<Person>(
                options,
                lifetime);

            //Assert
            Assert.True(true);

        }
    }
}
