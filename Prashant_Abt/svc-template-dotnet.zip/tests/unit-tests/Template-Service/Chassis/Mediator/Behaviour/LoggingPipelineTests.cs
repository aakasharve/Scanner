﻿using Microsoft.Extensions.Options;
using Moq;
using Neighborly.Chassis.Mediator.Behaviour.Logging;
using Serilog;
using Serilog.Events;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Mediator.Behaviour
{
    public class LoggingPipelineTests
    {
        private MockRepository mockRepository;

        private Mock<IOptions<LoggingPipelineOptions>> mockOptions;
        private Mock<ILogger> mockLogger;
        
        public LoggingPipelineTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockOptions = this.mockRepository.Create<IOptions<LoggingPipelineOptions>>();
            this.mockLogger = this.mockRepository.Create<ILogger>();
        }

        private LoggingPipeline CreateLoggingPipeline(LoggingPipelineOptions app)
        {
            mockOptions.Setup(ap => ap.Value).Returns(app);
            mockLogger.Setup(l => l.ForContext<LoggingPipeline>()).Returns(mockLogger.Object);
            return new LoggingPipeline(
                this.mockOptions.Object,
                this.mockLogger.Object);
        }

        [Fact]
        public async Task LoggingPipelineOptions_Info()
        {
            // Arrange
            LoggingPipelineOptions app = new LoggingPipelineOptions() { Level = LogEventLevel.Debug, LogCommand = true, LogQueryResult = true };
            var loggingPipeline = this.CreateLoggingPipeline(app);
            Func<ICommand, CancellationToken,Task> next = new Func<ICommand, CancellationToken, Task>(delegate { return Task.FromResult("Test"); });
            Command cmd = null;
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            mockLogger.Setup(s => s.Debug(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockLogger.Setup(s => s.IsEnabled(It.IsAny<LogEventLevel>())).Returns(true);
            // Act
            await loggingPipeline.OnCommandAsync<ICommand>(
                next,
                cmd,
                ct);

            //Assert
            Assert.True(true);
        }


        [Fact]
        public async Task LoggingPipelineOptions_Debug()
        {
            // Arrange
            LoggingPipelineOptions app = new LoggingPipelineOptions() { Level = LogEventLevel.Debug, LogCommand = true, LogQueryResult = true };
            var loggingPipeline = this.CreateLoggingPipeline(app);
            Func<ICommand, CancellationToken, Task> next = new Func<ICommand, CancellationToken, Task>(delegate { return Task.FromResult("Test"); });
            Command cmd = null;
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            mockLogger.Setup(s => s.Debug(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockLogger.Setup(s => s.IsEnabled(It.IsAny<LogEventLevel>())).Returns(true);
            // Act
            await loggingPipeline.OnCommandAsync<ICommand>(
                next,
                cmd,
                ct);

            //Assert
            Assert.True(true);
        }

        [Fact]
        public async Task LoggingPipelineOptions_Error()
        {
            // Arrange
            LoggingPipelineOptions app = new LoggingPipelineOptions() { Level = LogEventLevel.Error, LogCommand = true, LogQueryResult = true };
            var loggingPipeline = this.CreateLoggingPipeline(app);
            Func<ICommand, CancellationToken, Task> next = new Func<ICommand, CancellationToken, Task>(delegate { return Task.FromResult("Test"); });
            Command cmd = null;
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            mockLogger.Setup(s => s.Error(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockLogger.Setup(s => s.IsEnabled(It.IsAny<LogEventLevel>())).Returns(true);
            // Act
            await loggingPipeline.OnCommandAsync<ICommand>(
                next,
                cmd,
                ct);

            //Assert
            Assert.True(true);
        }

        [Fact]
        public async Task LoggingPipelineOptions_Warning()
        {
            // Arrange
            LoggingPipelineOptions app = new LoggingPipelineOptions() { Level = LogEventLevel.Warning, LogCommand = true, LogQueryResult = true };
            var loggingPipeline = this.CreateLoggingPipeline(app);
            Func<ICommand, CancellationToken, Task> next = new Func<ICommand, CancellationToken, Task>(delegate { return Task.FromResult("Test"); });
            Command cmd = null;
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            mockLogger.Setup(s => s.Warning(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockLogger.Setup(s => s.IsEnabled(It.IsAny<LogEventLevel>())).Returns(true);
            // Act
            await loggingPipeline.OnCommandAsync<ICommand>(
                next,
                cmd,
                ct);

            //Assert
            Assert.True(true);
        }

        [Fact]
        public async Task LoggingPipelineOptions_Fatal()
        {
            // Arrange
            LoggingPipelineOptions app = new LoggingPipelineOptions() { Level = LogEventLevel.Fatal, LogCommand = true, LogQueryResult = true };
            var loggingPipeline = this.CreateLoggingPipeline(app);
            Func<ICommand, CancellationToken, Task> next = new Func<ICommand, CancellationToken, Task>(delegate { return Task.FromResult("Test"); });
            Command cmd = null;
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            mockLogger.Setup(s => s.Fatal(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockLogger.Setup(s => s.IsEnabled(It.IsAny<LogEventLevel>())).Returns(true);
            // Act
            await loggingPipeline.OnCommandAsync<ICommand>(
                next,
                cmd,
                ct);

            //Assert
            Assert.True(true);
        }

        [Fact]
        public async Task OnCommandAsync_StateUnderTest_ExpectedBehavior1_Info()
        {
            // Arrange
            LoggingPipelineOptions app = new LoggingPipelineOptions() { Level = LogEventLevel.Debug, LogCommand = true, LogQueryResult = true };
            var loggingPipeline = this.CreateLoggingPipeline(app);
            Func<ICommand<object>, CancellationToken, Task<object>> next = new Func<ICommand<object>, CancellationToken, Task<object>>(delegate { return Task.FromResult<object>(""); });
            Command<object> cmd = null;
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            mockLogger.Setup(s => s.Debug(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockLogger.Setup(s => s.IsEnabled(It.IsAny<LogEventLevel>())).Returns(true);
            // Act
            var result = await loggingPipeline.OnCommandAsync<ICommand<object>, object>(
                next,
                cmd,
                ct);

            //Assert
            Assert.True(true);
        }

        [Fact]
        public async Task OnEventAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            LoggingPipelineOptions app = new LoggingPipelineOptions() { Level = LogEventLevel.Debug, LogCommand = true, LogQueryResult = true };
            var loggingPipeline = this.CreateLoggingPipeline(app);
            Func<IEvent, CancellationToken, Task> next = new Func<IEvent, CancellationToken, Task>(delegate { return Task.FromResult("Test"); });
            Event evt = null;
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            mockLogger.Setup(s => s.Debug(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockLogger.Setup(s => s.IsEnabled(It.IsAny<LogEventLevel>())).Returns(true);
            // Act
            await loggingPipeline.OnEventAsync(
                next,
                evt,
                ct);

            //Assert
            Assert.True(true);
        }

        [Fact]
        public async Task OnQueryAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            LoggingPipelineOptions app = new LoggingPipelineOptions() { Level = LogEventLevel.Debug, LogCommand = true, LogQueryResult = true };
            var loggingPipeline = this.CreateLoggingPipeline(app);
            Func<IQuery<object>, CancellationToken, Task<object>> next = new Func<IQuery<object>, CancellationToken, Task<object>>(delegate { return Task.FromResult<object>(""); });
            Query<object> query = null;
            CancellationToken ct = default(global::System.Threading.CancellationToken);
            mockLogger.Setup(s => s.Debug(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockLogger.Setup(s => s.IsEnabled(It.IsAny<LogEventLevel>())).Returns(true);
            // Act
            var result = await loggingPipeline.OnQueryAsync(
                next,
                query,
                ct);

            //Assert
            Assert.True(true);
        }
    }
}
