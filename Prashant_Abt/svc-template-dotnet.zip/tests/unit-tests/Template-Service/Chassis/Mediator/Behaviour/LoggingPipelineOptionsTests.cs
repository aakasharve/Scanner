﻿using Moq;
using Neighborly.Chassis.Mediator.Behaviour.Logging;
using System;
using Xunit;

namespace Neighborly.Chassis.Mediator.Behaviour
{
    public class LoggingPipelineOptionsTests
    {
        private MockRepository mockRepository;



        public LoggingPipelineOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private LoggingPipelineOptions CreateLoggingPipelineOptions()
        {
            return new LoggingPipelineOptions();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var loggingPipelineOptions = this.CreateLoggingPipelineOptions();

            // Act
            loggingPipelineOptions.Level = Serilog.Events.LogEventLevel.Debug;
            loggingPipelineOptions.LogCommand = true;
            loggingPipelineOptions.LogCommandResult = true;
            loggingPipelineOptions.LogEvent = true;
            loggingPipelineOptions.LogQuery = true;
            loggingPipelineOptions.LogQueryResult = true;
            loggingPipelineOptions.Serializer = str => str.ToString();

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
