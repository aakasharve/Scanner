﻿namespace Neighborly.Chassis.Mediator.Behaviour
{
    internal class Person
    {
    }
}