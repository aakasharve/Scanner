﻿using Moq;
using Neighborly.Models;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Mediator
{
    public class MediatorExtensionsTests
    {
        private MockRepository mockRepository;

        Mock<IMediator> mockMediator = new Mock<IMediator>();

        public MediatorExtensionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        


        [Fact]
        public void Broadcast_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            IEvent evt = null;
            StorageEntity storageEntity = new StorageEntity { Id = Guid.NewGuid() };
            mockMediator.Setup(x => x.BroadcastAsync(It.IsAny<StorageCreatedEvent>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(storageEntity));

            // Act
            MediatorExtensions.Broadcast(
                mockMediator.Object,
                evt);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void Broadcast_StateUnderTest_ExpectedBehavior_null()
        {
            // Arrange
            IEvent evt = null;
            StorageEntity storageEntity = new StorageEntity { Id = Guid.NewGuid() };
            mockMediator.Setup(x => x.BroadcastAsync(It.IsAny<StorageCreatedEvent>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(storageEntity));

            // Act
            Assert.Throws<ArgumentNullException>(() => MediatorExtensions.Broadcast(
                null,
                evt));
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void Fetch_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            IQuery<StorageEntity> query = null;
            ToDoItemEntity storageEntity = new ToDoItemEntity { Id = Guid.NewGuid() };
            mockMediator.Setup(x => x.FetchAsync(It.IsAny<GetToDoItemByIdQuery>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(storageEntity));

            // Act
            var result = MediatorExtensions.Fetch(
                mockMediator.Object,
                query);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void Fetch_StateUnderTest_ExpectedBehavior_null()
        {
            // Arrange
            IMediator mediator = null;
            IQuery<StorageEntity> query = null;
            ToDoItemEntity storageEntity = new ToDoItemEntity { Id = Guid.NewGuid() };
            mockMediator.Setup(x => x.FetchAsync(It.IsAny<GetToDoItemByIdQuery>(), It.IsAny<CancellationToken>())).Returns(Task.FromResult(storageEntity));

            // Act
            Assert.Throws<ArgumentNullException>(() => MediatorExtensions.Fetch(
                mediator,
                query));

            this.mockRepository.VerifyAll();
        }
    }
}
