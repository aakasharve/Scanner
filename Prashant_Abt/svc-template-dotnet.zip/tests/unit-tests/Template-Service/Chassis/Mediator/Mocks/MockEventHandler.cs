using Neighborly.Chassis.Mediator;
using System.Threading;
using System.Threading.Tasks;

namespace Neighborly
{
    public class MockEventHandler : IEventHandler<MockEvent>
    {
        public Task HandleAsync(MockEvent evt, CancellationToken ct)
        {
            return Task.CompletedTask;
        }
    }
}