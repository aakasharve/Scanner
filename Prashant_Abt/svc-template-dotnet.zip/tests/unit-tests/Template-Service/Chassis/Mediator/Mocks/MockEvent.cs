using Neighborly.Chassis.Mediator;
using System;

namespace Neighborly
{
    public class MockEvent : Event
    {
        public MockEvent()
        {

        }

        public MockEvent(Guid id, DateTimeOffset createdOn, string createdBy)
        {
            Id = id;
            CreatedOn = createdOn;
            CreatedBy = createdBy;
        }
    }
}