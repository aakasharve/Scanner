﻿using Neighborly.Service.BaseQuery;
using System;


namespace Neighborly.Models
{
    /// <summary>
    /// Class GetToDoItemByIdQuery.
    /// Implements the <see cref="Service.BaseQuery.SingleItemQuery{Neighborly.Service.ToDoItem.Domain.ToDoItemEntity}" />
    /// </summary>
    /// <seealso cref="Service.BaseQuery.SingleItemQuery{Neighborly.Service.ToDoItem.Domain.ToDoItemEntity}" />
    public class GetToDoItemByIdQuery : SingleItemQuery<ToDoItemEntity>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="GetToDoItemByIdQuery"/> class.
        /// </summary>
        /// <param name="identity">The identity.</param>
        public GetToDoItemByIdQuery(string identity) : base(identity)
        {

        }
        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public Guid ItemId { get; set; }
    }
}
