﻿using Neighborly.Chassis.Repository;

namespace Neighborly.Models
{
    /// <summary>
    /// Class ToDoItemEntity.
    /// Implements the <see cref="Chassis.Repository.ItemBase" />
    /// </summary>
    /// <seealso cref="Chassis.Repository.ItemBase" />
    public class ToDoItemEntity : ItemBase
    {
        /// <summary>
        /// Category which the To-Do-Item belongs to
        /// </summary>
        /// <value>The category.</value>
        public string Category { get; set; }
        /// <summary>
        /// Title of the To-Do-Item
        /// </summary>
        /// <value>The title.</value>
        public string Title { get; set; }

        /// <summary>
        /// Whether the To-Do-Item is done
        /// </summary>
        /// <value><c>true</c> if this instance is completed; otherwise, <c>false</c>.</value>
        public bool IsCompleted { get; private set; }

        /// <summary>
        /// Marks the complete.
        /// </summary>
        public void MarkComplete()
        {
            IsCompleted = true;
        }

        /// <summary>
        /// Returns a <see cref="System.String" /> that represents this instance.
        /// </summary>
        /// <returns>A <see cref="System.String" /> that represents this instance.</returns>
        public override string ToString()
        {
            string status = IsCompleted ? "Done!" : "Not done.";
            return $"{Id}: Status: {status} - {Title}";
        }
    }
}
