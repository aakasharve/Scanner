﻿using Neighborly.Chassis.Mediator;

namespace Neighborly.Models
{
    /// <summary>
    /// Class StorageCreatedEvent.
    /// Implements the <see cref="Neighborly.Chassis.Mediator.Event" />
    /// </summary>
    /// <seealso cref="Neighborly.Chassis.Mediator.Event" />
    public class StorageCreatedEvent : Event
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="StorageCreatedEvent"/> class.
        /// </summary>
        /// <param name="todoItem">The todo item.</param>
        public StorageCreatedEvent(StorageEntity storage)
        {
            storageEntity = storage;
        }

        /// <summary>
        /// Converts to doitementity.
        /// </summary>
        /// <value>To do item entity.</value>
        public StorageEntity storageEntity { get; }
    }
}