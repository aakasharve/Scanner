﻿using Neighborly.Chassis.Repository;
using Neighborly.Chassis.Storage.Blobs;
using System.Reflection.Metadata;

namespace Neighborly.Models
{
    /// <summary>
    /// Class StorageEntity.
    /// Implements the <see cref="Chassis.Repository.ItemBase" />
    /// </summary>
    /// <seealso cref="Chassis.Repository.ItemBase" />
    public class StorageEntity : ItemBase
    {
        /// <summary>
        /// Storage Account Name
        /// </summary>
        public string AccountName { get; set; }
        /// <summary>
        /// Container Id
        /// </summary>
        public string ContainerId { get; set; }
        /// <summary>
        /// <summary>
        /// File Id
        /// </summary>
        /// <value>ID.</value>
        public string BlobId { get; set; }
        /// Url of the File
        /// </summary>
        /// <value>URL.</value>
        public string FileUrl { get; set; }
        /// <summary>
        /// Metadata
        /// </summary>
        public Blob BlobMetaData { get; set; }

    }
}
