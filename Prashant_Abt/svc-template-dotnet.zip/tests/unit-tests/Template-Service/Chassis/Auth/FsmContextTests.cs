﻿using Moq;
using Xunit;

namespace Neighborly.Chassis.Auth
{
    public class FsmContextTests
    {
        private readonly MockRepository mockRepository;

        public FsmContextTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        private FsmContext CreateFsmContext()
        {
            return new FsmContext();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var fsmContext = this.CreateFsmContext();

            // Act
            fsmContext.CmId = System.Guid.Empty;
            fsmContext.BuId = System.Guid.Empty;
            fsmContext.BgId = System.Guid.Empty;
            fsmContext.LoBId = System.Guid.Empty;
            fsmContext.CoId = 1;

            FsmContext fsmContext1 = new FsmContext();
            fsmContext1.CmId = fsmContext.CmId;
            fsmContext1.BuId = fsmContext.BuId;
            fsmContext1.BgId = fsmContext.BgId;
            fsmContext1.LoBId = fsmContext.LoBId;
            fsmContext1.CoId = fsmContext.CoId;
            
            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
