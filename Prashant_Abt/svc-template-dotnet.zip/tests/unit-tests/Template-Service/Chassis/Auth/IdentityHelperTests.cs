﻿using Moq;
using Xunit;
using static Neighborly.Chassis.Auth.IdentityHelper;

namespace Neighborly.Chassis.Auth
{
    public class IdentityHelperTests
    {
        private readonly MockRepository mockRepository;

        public IdentityHelperTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        private UserClaims CreateUserClaims()
        {
            return new UserClaims();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var userClaim = this.CreateUserClaims();

            // Act
            userClaim.Name = "Name";
            userClaim.Email = "Name";
            userClaim.UserId = "Name";
            userClaim.Roles = new System.Collections.Generic.List<string>();
            userClaim.Sub = "Name";
            userClaim.Oid = "Name";
            userClaim.IsExternalUser = false;
            userClaim.UserTimeZone = "Name";
            userClaim.Offset = "Name";
            userClaim.UserCultureCode = "Name";
            userClaim.FsmContext = new FsmContext();

            UserClaims userClaims1 = new UserClaims();
            userClaims1.Name = userClaim.Name;
            userClaims1.Email = userClaim.Email;
            userClaims1.UserId = userClaim.UserId;
            userClaims1.Roles = userClaim.Roles;
            userClaims1.Sub = userClaim.Sub;
            userClaims1.Oid = userClaim.Oid;
            userClaims1.IsExternalUser = userClaim.IsExternalUser;
            userClaims1.UserTimeZone = userClaim.UserTimeZone;
            userClaims1.Offset = userClaim.Offset;
            userClaims1.UserCultureCode = userClaim.UserCultureCode;
            userClaims1.FsmContext = userClaim.FsmContext;

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
}
}
