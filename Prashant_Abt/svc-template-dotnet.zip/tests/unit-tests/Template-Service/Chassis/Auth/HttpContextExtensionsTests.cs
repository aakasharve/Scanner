﻿using Microsoft.AspNetCore.Http;
using Moq;
using Neighborly.Chassis.Auth;
using System;
using System.IO;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Auth
{
    public class HttpContextExtensionsTests
    {
        private MockRepository mockRepository;
        public HttpContextExtensionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            DefaultHttpContext httpContext = new DefaultHttpContext();
            httpContext.Response.Body = new MemoryStream();
            httpContext.Response.Body.Position = 0;

            // Act
            HttpContextExtensions.SetUnauthorizedErrorResponse(httpContext, "Error");

            // Assert
            Assert.True(true);
        }
    }
}