﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Moq;
using Shouldly;
using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Auth
{
    public class JwtParserMiddlewareTest
    {
        public IConfigurationRoot Configuration = new ConfigurationBuilder()
         .SetBasePath(Directory.GetCurrentDirectory())
         .AddJsonFile("appsettings.json", true, true).Build();

        [Fact]
        public async Task Middleware_Authorized()
        {
            // Arrange:

            HttpContext ctx =

            new DefaultHttpContext()
            {
            };
            var configSection = new Mock<IConfigurationSection>();
            configSection.Setup(x => x.Value).Returns("fake value");
            Mock<IConfiguration> mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.Setup(x => x.GetSection(It.IsAny<string>())).Returns(configSection.Object);

            ctx.Request.Headers.Add("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiJkZjczMjQ0NS0xNDFiLTQxYjMtODAwNC03ZjI0MjUzZWJlYWEiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vZDIzOTJjNDAtMzZkOC00ODIxLTkxNmYtOTI1ZWZlMDdkMjY2L3YyLjAiLCJpYXQiOjE2MTg4MTk5MDAsIm5iZiI6MTYxODgxOTkwMCwiZXhwIjoxNjE4ODIzODAwLCJhaW8iOiJBVFFBeS84VEFBQUFTcWRnODRWQUVuTjVlYjBadEV1d0VTOTBXNUcwTEFvSnlISVgvb2tHSkdEL3NYQlBVbmVtdTlJa29NUUczQlE2IiwiYXpwIjoiZGY3MzI0NDUtMTQxYi00MWIzLTgwMDQtN2YyNDI1M2ViZWFhIiwiYXpwYWNyIjoiMSIsIm5hbWUiOiJOaWxlc2ggTmFya2hlZGUiLCJvaWQiOiIyNjAxZjIwMS0xODliLTQ3ZTAtYWMxNC1jMjE5MTAzZDVhYjEiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiIxMTk2MmRkNC0zNWUzLTQ2NWYtYTEyMy03ZWE0Y2Q3MDEzMWZAZnNtZGV2Lm9ubWljcm9zb2Z0LmNvbSIsInJoIjoiMC5BUlVBUUN3NTB0ZzJJVWlSYjVKZV9nZlNaa1VrYzk4YkZMTkJnQVJfSkNVLXZxb2VBUE0uIiwic2NwIjoiRmlsZXMuUmVhZCIsInN1YiI6Ii12aWxSUWZacHU4RC1VQ1RRaF91alNyRXd5dVdoVUljNHg0c1N6Vmw4X3ciLCJ0aWQiOiJkMjM5MmM0MC0zNmQ4LTQ4MjEtOTE2Zi05MjVlZmUwN2QyNjYiLCJ1dGkiOiJNZ1k2bTI1SkUwcTMySDJVSjY2LUFBIiwidmVyIjoiMi4wIn0.arsy_ECkd5NN_osjO3FXYqCLiXUEoS2HLnFRO1lvR6dv-ka8PF2ra9wZoUPKyOR6gcCoeZ-sQDDOZJmaSslw2tpmXClBJVLKDA3q4OJkGQ1XMNi64HNHnXdc15Lhuo_woJzhnMnI3a7USA6sAVjBGI0LsyrlNsNLZcQVmEvVH3aLA2q-jiZd1ItxeAmt4apOAWwrw8s42XotUO0TnVg7Q2XiU87FXQMavQPxOeItyBiXFyvU6vGm9R5S2KbPevJ1swmSKRVGYULjW_hQ09PEYWNZp7GT919NITY_oz9CS8jk_erKtqyyIvOgzJxdCr7sOoC_-lF0jOpmkDMapP9GJQ");

            RequestDelegate next = (HttpContext hc) => Task.CompletedTask;
            var claim = new Dictionary<string, string>()
                {
                    { "azpacr","1" },
                    { "k2","v2" },
                    { "k3","v3"}
                };

            JwtParserMiddleware mw = new JwtParserMiddleware(next, claim);

            // Act - Part 1: InvokeAsync set-up:

            await mw.InvokeAsync(ctx);

            // Assert - Part 1

            ctx.Response.Headers.TryGetValue("k1", out Microsoft.Extensions.Primitives.StringValues value0).ShouldBeFalse();
            value0.ShouldBeEmpty();

            // Act - Part 2

            await ctx.Response.StartAsync(default);
        }

        [Fact]
        public async Task Middleware_Invalid_Bearer()
        {
            // Arrange:

            HttpContext ctx =

            new DefaultHttpContext()
            {
            };
            var configSection = new Mock<IConfigurationSection>();
            configSection.Setup(x => x.Value).Returns("fake value");
            Mock<IConfiguration> mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.Setup(x => x.GetSection(It.IsAny<string>())).Returns(configSection.Object);
            ctx.Request.Headers.Add("Authorization", "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiJkZjczMjQ0NS0xNDFiLTQxYjMtODAwNC03ZjI0MjUzZWJlYWEiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vZDIzOTJjNDAtMzZkOC00ODIxLTkxNmYtOTI1ZWZlMDdkMjY2L3YyLjAiLCJpYXQiOjE2MTg4MTk5MDAsIm5iZiI6MTYxODgxOTkwMCwiZXhwIjoxNjE4ODIzODAwLCJhaW8iOiJBVFFBeS84VEFBQUFTcWRnODRWQUVuTjVlYjBadEV1d0VTOTBXNUcwTEFvSnlISVgvb2tHSkdEL3NYQlBVbmVtdTlJa29NUUczQlE2IiwiYXpwIjoiZGY3MzI0NDUtMTQxYi00MWIzLTgwMDQtN2YyNDI1M2ViZWFhIiwiYXpwYWNyIjoiMSIsIm5hbWUiOiJOaWxlc2ggTmFya2hlZGUiLCJvaWQiOiIyNjAxZjIwMS0xODliLTQ3ZTAtYWMxNC1jMjE5MTAzZDVhYjEiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiIxMTk2MmRkNC0zNWUzLTQ2NWYtYTEyMy03ZWE0Y2Q3MDEzMWZAZnNtZGV2Lm9ubWljcm9zb2Z0LmNvbSIsInJoIjoiMC5BUlVBUUN3NTB0ZzJJVWlSYjVKZV9nZlNaa1VrYzk4YkZMTkJnQVJfSkNVLXZxb2VBUE0uIiwic2NwIjoiRmlsZXMuUmVhZCIsInN1YiI6Ii12aWxSUWZacHU4RC1VQ1RRaF91alNyRXd5dVdoVUljNHg0c1N6Vmw4X3ciLCJ0aWQiOiJkMjM5MmM0MC0zNmQ4LTQ4MjEtOTE2Zi05MjVlZmUwN2QyNjYiLCJ1dGkiOiJNZ1k2bTI1SkUwcTMySDJVSjY2LUFBIiwidmVyIjoiMi4wIn0.arsy_ECkd5NN_osjO3FXYqCLiXUEoS2HLnFRO1lvR6dv-ka8PF2ra9wZoUPKyOR6gcCoeZ-sQDDOZJmaSslw2tpmXClBJVLKDA3q4OJkGQ1XMNi64HNHnXdc15Lhuo_woJzhnMnI3a7USA6sAVjBGI0LsyrlNsNLZcQVmEvVH3aLA2q-jiZd1ItxeAmt4apOAWwrw8s42XotUO0TnVg7Q2XiU87FXQMavQPxOeItyBiXFyvU6vGm9R5S2KbPevJ1swmSKRVGYULjW_hQ09PEYWNZp7GT919NITY_oz9CS8jk_erKtqyyIvOgzJxdCr7sOoC_-lF0jOpmkDMapP9GJQ");

            RequestDelegate next = (HttpContext hc) => Task.CompletedTask;
            var claim = new Dictionary<string, string>()
                {
                    { "k1","v1" },
                    { "k2","v2" },
                    { "k3","v3"}
                };

            JwtParserMiddleware mw = new JwtParserMiddleware(next, claim);

            // Act - Part 1: InvokeAsync set-up:

            await mw.InvokeAsync(ctx);

            // Assert - Part 1

            ctx.Response.Headers.TryGetValue("k1", out Microsoft.Extensions.Primitives.StringValues value0).ShouldBeFalse();
            value0.ShouldBeEmpty();

            // Act - Part 2

            await ctx.Response.StartAsync(default);
        }

        [Fact]
        public async Task Middleware_QueryString_Authorized()
        {
            // Arrange:

            HttpContext ctx =

            new DefaultHttpContext()
            {
            };
            var configSection = new Mock<IConfigurationSection>();
            configSection.Setup(x => x.Value).Returns("fake value");
            Mock<IConfiguration> mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.Setup(x => x.GetSection(It.IsAny<string>())).Returns(configSection.Object);

            ctx.Request.Headers.Add("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6Im5PbzNaRHJPRFhFSzFqS1doWHNsSFJfS1hFZyJ9.eyJhdWQiOiJkZjczMjQ0NS0xNDFiLTQxYjMtODAwNC03ZjI0MjUzZWJlYWEiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vZDIzOTJjNDAtMzZkOC00ODIxLTkxNmYtOTI1ZWZlMDdkMjY2L3YyLjAiLCJpYXQiOjE2MTg4MTk5MDAsIm5iZiI6MTYxODgxOTkwMCwiZXhwIjoxNjE4ODIzODAwLCJhaW8iOiJBVFFBeS84VEFBQUFTcWRnODRWQUVuTjVlYjBadEV1d0VTOTBXNUcwTEFvSnlISVgvb2tHSkdEL3NYQlBVbmVtdTlJa29NUUczQlE2IiwiYXpwIjoiZGY3MzI0NDUtMTQxYi00MWIzLTgwMDQtN2YyNDI1M2ViZWFhIiwiYXpwYWNyIjoiMSIsIm5hbWUiOiJOaWxlc2ggTmFya2hlZGUiLCJvaWQiOiIyNjAxZjIwMS0xODliLTQ3ZTAtYWMxNC1jMjE5MTAzZDVhYjEiLCJwcmVmZXJyZWRfdXNlcm5hbWUiOiIxMTk2MmRkNC0zNWUzLTQ2NWYtYTEyMy03ZWE0Y2Q3MDEzMWZAZnNtZGV2Lm9ubWljcm9zb2Z0LmNvbSIsInJoIjoiMC5BUlVBUUN3NTB0ZzJJVWlSYjVKZV9nZlNaa1VrYzk4YkZMTkJnQVJfSkNVLXZxb2VBUE0uIiwic2NwIjoiRmlsZXMuUmVhZCIsInN1YiI6Ii12aWxSUWZacHU4RC1VQ1RRaF91alNyRXd5dVdoVUljNHg0c1N6Vmw4X3ciLCJ0aWQiOiJkMjM5MmM0MC0zNmQ4LTQ4MjEtOTE2Zi05MjVlZmUwN2QyNjYiLCJ1dGkiOiJNZ1k2bTI1SkUwcTMySDJVSjY2LUFBIiwidmVyIjoiMi4wIn0.arsy_ECkd5NN_osjO3FXYqCLiXUEoS2HLnFRO1lvR6dv-ka8PF2ra9wZoUPKyOR6gcCoeZ-sQDDOZJmaSslw2tpmXClBJVLKDA3q4OJkGQ1XMNi64HNHnXdc15Lhuo_woJzhnMnI3a7USA6sAVjBGI0LsyrlNsNLZcQVmEvVH3aLA2q-jiZd1ItxeAmt4apOAWwrw8s42XotUO0TnVg7Q2XiU87FXQMavQPxOeItyBiXFyvU6vGm9R5S2KbPevJ1swmSKRVGYULjW_hQ09PEYWNZp7GT919NITY_oz9CS8jk_erKtqyyIvOgzJxdCr7sOoC_-lF0jOpmkDMapP9GJQ");
            //ctx.Request.QueryString.Add("jwt", "xyz") ;
            //ctx.Request.Query.Keys.Add("jwt", "xyz");
            ctx.Request.QueryString = ctx.Request.QueryString.Add("jwt", "xyz");
            RequestDelegate next = (HttpContext hc) => Task.CompletedTask;


            var claim = new Dictionary<string, string>()
                {
                    { "k1","v1" },
                    { "k2","v2" },
                    { "k3","v3"}
                };

            JwtParserMiddleware mw = new JwtParserMiddleware(next, claim);

            // Act - Part 1: InvokeAsync set-up:

            await mw.InvokeAsync(ctx);

            // Assert - Part 1

            ctx.Response.Headers.TryGetValue("k1", out Microsoft.Extensions.Primitives.StringValues value0).ShouldBeFalse();
            value0.ShouldBeEmpty();

            // Act - Part 2

            await ctx.Response.StartAsync(default);
        }


        [Fact]
        public async Task Middleware_Unauthorized()
        {
            // Arrange:

            HttpContext ctx =

            new DefaultHttpContext()
            { };
            var configSection = new Mock<IConfigurationSection>();
            configSection.Setup(x => x.Value).Returns("fake value");
            Mock<IConfiguration> mockConfiguration = new Mock<IConfiguration>();
            mockConfiguration.Setup(x => x.GetSection(It.IsAny<string>())).Returns(configSection.Object);

            RequestDelegate next = (HttpContext hc) => Task.CompletedTask;
            var claim = new Dictionary<string, string>()
        {
            { "k1","v1" },
            { "k2","v2" },
            { "k3","v3"}
        };

            JwtParserMiddleware mw = new JwtParserMiddleware(next, claim);

            // Act - Part 1: InvokeAsync set-up:

            await mw.InvokeAsync(ctx);

            // Assert - Part 1

            ctx.Response.Headers.TryGetValue("k1", out Microsoft.Extensions.Primitives.StringValues value0).ShouldBeFalse();
            value0.ShouldBeEmpty();

            // Act - Part 2

            await ctx.Response.StartAsync(default);


        }
    }
}
