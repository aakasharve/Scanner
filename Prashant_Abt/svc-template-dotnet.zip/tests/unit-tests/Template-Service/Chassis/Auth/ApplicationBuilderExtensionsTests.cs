﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Moq;
using Neighborly.Chassis.Auth;
using Shouldly;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Auth
{
    public class ApplicationBuilderExtensionsTests
    {
        private MockRepository mockRepository;

        public ApplicationBuilderExtensionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }


        [Fact]
        public void UseNeighborlyJwtParserForFranforceIdentity_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            //Mock<IApplicationBuilder> builder = new Mock<IApplicationBuilder>();
            var serviceCollection = new ServiceCollection();
            var builder = new ApplicationBuilder(serviceCollection.BuildServiceProvider());

            // Act
            var result = ApplicationBuilderExtensions.UseNeighborlyJwtParserForFranforceIdentity(
                builder);
            Assert.IsType<ApplicationBuilder>(result);
        }

        [Fact]
        public void UseNeighborlyPrivatePublicAuthorization_StateUnderTest_ExpectedBehavior()
        {
            // Arrange

            var serviceCollection = new ServiceCollection();
            var builder = new ApplicationBuilder(serviceCollection.BuildServiceProvider());

            // Act
            var result = ApplicationBuilderExtensions.UseNeighborlyPrivatePublicAuthorization(
                builder);

            // Assert
            Assert.IsType<ApplicationBuilder>(result);
        }

        [Fact]
        public void UseNeighborlyJwtParserForAzureB2C_StateUnderTest_ExpectedBehavior()
        {
            // Arrange

            var serviceCollection = new ServiceCollection();
            var builder = new ApplicationBuilder(serviceCollection.BuildServiceProvider());

            // Act
            var result = ApplicationBuilderExtensions.UseNeighborlyJwtParserForAzureB2C(
                builder);

            // Assert
            Assert.IsType<ApplicationBuilder>(result);
        }

        [Fact]
        public void UseSerilogEnricherMiddleware_StateUnderTest_ExpectedBehavior()
        {
            // Arrange

            var serviceCollection = new ServiceCollection();
            var builder = new ApplicationBuilder(serviceCollection.BuildServiceProvider());

            // Act
            var result = ApplicationBuilderExtensions.UseSerilogEnricherMiddleware(
                builder);

            // Assert
            Assert.IsType<ApplicationBuilder>(result);
        }

        [Fact]
        public void UseNeighborlyJwtParser_StateUnderTest_ExpectedBehavior()
        {
            // Arrange

            var serviceCollection = new ServiceCollection();
            var builder = new ApplicationBuilder(serviceCollection.BuildServiceProvider());
            Dictionary<string, string> claimTypeMaps = null;

            // Act
            var result = ApplicationBuilderExtensions.UseNeighborlyJwtParser(
                builder,
                claimTypeMaps);

            // Assert
            Assert.IsType<ApplicationBuilder>(result);
        }
    }
}