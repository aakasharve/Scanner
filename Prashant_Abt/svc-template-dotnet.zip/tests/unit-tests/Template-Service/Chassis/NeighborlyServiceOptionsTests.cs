﻿using Moq;
using Neighborly.Chassis;
using System;
using Xunit;

namespace Neighborly.Chassis
{
    public class NeighborlyServiceOptionsTests
    {
        private MockRepository mockRepository;



        public NeighborlyServiceOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private NeighborlyServiceOptions CreateNeighborlyServiceOptions()
        {
            return new NeighborlyServiceOptions();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var neighborlyServiceOptions = this.CreateNeighborlyServiceOptions();

            // Act
            var result = (neighborlyServiceOptions.Name,
                           neighborlyServiceOptions.Description,
                           neighborlyServiceOptions.Instance,
                           neighborlyServiceOptions.Version,
                           neighborlyServiceOptions.DisplayBanner,
                           neighborlyServiceOptions.DisplayVersion);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
    }
}
