﻿using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class AzureServiceBusSubscriptionHealthCheckTests
    {
        private MockRepository mockRepository;



        public AzureServiceBusSubscriptionHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private AzureServiceBusSubscriptionHealthCheck CreateAzureServiceBusSubscriptionHealthCheck()
        {
            return new AzureServiceBusSubscriptionHealthCheck(
                "context",
                "cancellationToken",
                "topic name"
                );
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var azureServiceBusSubscriptionHealthCheck = this.CreateAzureServiceBusSubscriptionHealthCheck();
            //HealthCheckContext context = null;
            //CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            //// Act
            //var result = await azureServiceBusSubscriptionHealthCheck.CheckHealthAsync(
            //    context,
            //    cancellationToken);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
