﻿using Moq;

namespace Neighborly.Chassis.Healthcheck
{
    internal class CertificateValidationCallback
    {
        public CertificateValidationCallback()
        {
        }

        internal class Equals
        {
            private MockRepository mockRepository;

            public Equals(MockRepository mockRepository)
            {
                this.mockRepository = mockRepository;
            }
        }
    }
}