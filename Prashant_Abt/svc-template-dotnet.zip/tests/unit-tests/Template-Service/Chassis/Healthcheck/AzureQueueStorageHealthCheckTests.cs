﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class AzureQueueStorageHealthCheckTests
    {
        private MockRepository mockRepository;



        public AzureQueueStorageHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private AzureQueueStorageHealthCheck CreateAzureQueueStorageHealthCheck()
        {
            return new AzureQueueStorageHealthCheck(
                "context",
                "CancellationToken");
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var azureQueueStorageHealthCheck = this.CreateAzureQueueStorageHealthCheck();
            //HealthCheckContext context = new HealthCheckContext();// null;
            //CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            //// Act
            //var result = await azureQueueStorageHealthCheck.CheckHealthAsync(
            //    context,
            //    cancellationToken);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
