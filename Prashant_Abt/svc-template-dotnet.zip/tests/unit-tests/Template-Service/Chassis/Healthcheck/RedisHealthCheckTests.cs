﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class RedisHealthCheckTests
    {
        private MockRepository mockRepository;



        public RedisHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private RedisHealthCheck CreateRedisHealthCheck()
        {
            return new RedisHealthCheck(
                "context");
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var redisHealthCheck = this.CreateRedisHealthCheck();
           
            // Act
           

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
