﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class AzureEventHubHealthCheckTests
    {
        private MockRepository mockRepository;



        public AzureEventHubHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private AzureEventHubHealthCheck CreateAzureEventHubHealthCheck()
        {
            return new AzureEventHubHealthCheck(
                "context",
                "cancellationToken");
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            //var azureEventHubHealthCheck = this.CreateAzureEventHubHealthCheck();
            //HealthCheckContext context = null;
            //CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            //// Act
            //var result = await azureEventHubHealthCheck.CheckHealthAsync(
            //    context,
            //    cancellationToken);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
