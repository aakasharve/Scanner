﻿using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class ApplicationInsightsPublisherTests
    {
        private MockRepository mockRepository;

        private Mock<IOptions<TelemetryConfiguration>> mockOptions;

        public ApplicationInsightsPublisherTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockOptions = this.mockRepository.Create<IOptions<TelemetryConfiguration>>();
        }

        private ApplicationInsightsPublisher CreateApplicationInsightsPublisher()
        {
            return new ApplicationInsightsPublisher(
                this.mockOptions.Object,
                "cortex"
                );
        }

        [Fact]
        public async Task PublishAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange

            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }
    }
}
