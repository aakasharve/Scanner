﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class DocumentDbHealthCheckTests
    {
        private MockRepository mockRepository;

        private Mock<DocumentDbOptions> mockDocumentDbOptions;

        public DocumentDbHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockDocumentDbOptions = this.mockRepository.Create<DocumentDbOptions>();
        }

        private DocumentDbHealthCheck CreateDocumentDbHealthCheck()
        {
            return new DocumentDbHealthCheck(
                this.mockDocumentDbOptions.Object);
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }
    }
}
