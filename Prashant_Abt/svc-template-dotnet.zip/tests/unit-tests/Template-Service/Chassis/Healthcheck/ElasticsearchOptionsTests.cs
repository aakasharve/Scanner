﻿using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class ElasticsearchOptionsTests
    {
        private MockRepository mockRepository;

        public ElasticsearchOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

        }

        private ElasticsearchOptions CreateElasticsearchOptions()
        {
            return new ElasticsearchOptions();
        }

        [Fact]
        public void UseBasicAuthentication_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var elasticsearchOptions = this.CreateElasticsearchOptions();
            string name = "ABC";
            string password = "XYZ";

            // Act
            var result = elasticsearchOptions.UseBasicAuthentication(
                name,
                password);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void UseCertificate_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var elasticsearchOptions = this.CreateElasticsearchOptions();
            X509Certificate certificate = new X509Certificate();

            // Act
            var result = elasticsearchOptions.UseCertificate(
                certificate);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void UseServer_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var elasticsearchOptions = this.CreateElasticsearchOptions();
            string uri = "PQR";

            // Act
            var result = elasticsearchOptions.UseServer(
                uri);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void UseCertificateValidationCallback_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var elasticsearchOptions = this.CreateElasticsearchOptions();
            Func<object, X509Certificate, X509Chain, SslPolicyErrors, bool> callback = new Func<object, X509Certificate, X509Chain, SslPolicyErrors, bool>(delegate { return true; });
            
            // Act
            var result = elasticsearchOptions.UseCertificateValidationCallback(
                callback);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();

            //public ElasticsearchOptions UseCertificateValidationCallback(Func<object, X509Certificate, X509Chain, SslPolicyErrors, bool> callback)
            //{
            //    CertificateValidationCallback = callback;
            //    return this;
            //}
        }
    }
}
