﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class ElasticsearchHealthCheckTests
    {
        private MockRepository mockRepository;

        private Mock<ElasticsearchOptions> mockElasticsearchOptions;

        public ElasticsearchHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockElasticsearchOptions = this.mockRepository.Create<ElasticsearchOptions>();
        }

        private ElasticsearchHealthCheck CreateElasticsearchHealthCheck()
        {
            return new ElasticsearchHealthCheck(
                this.mockElasticsearchOptions.Object);
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }
    }
}
