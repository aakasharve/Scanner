﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class AzureServiceBusHealthCheckBuilderExtensionsTests
    {
        private MockRepository mockRepository;



        public AzureServiceBusHealthCheckBuilderExtensionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

 
        [Fact]
        public void AddAzureEventHub_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }

        [Fact]
        public void AddAzureEventHub_StateUnderTest_ExpectedBehavior1()
        {
            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }

        [Fact]
        public void AddAzureServiceBusQueue_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }

        [Fact]
        public void AddAzureServiceBusTopic_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }

        [Fact]
        public void AddAzureServiceBusSubscription_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher); ;
        }
    }
}
