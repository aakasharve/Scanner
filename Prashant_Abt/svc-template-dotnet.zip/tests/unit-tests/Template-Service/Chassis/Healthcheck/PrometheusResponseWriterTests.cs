﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class PrometheusResponseWriterTests
    {
        private MockRepository mockRepository;



        public PrometheusResponseWriterTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private PrometheusResponseWriter CreatePrometheusResponseWriter()
        {
            return new PrometheusResponseWriter();
        }

        [Fact]
        public async Task WritePrometheusResultText_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var prometheusResponseWriter = this.CreatePrometheusResponseWriter();

            // Act

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
