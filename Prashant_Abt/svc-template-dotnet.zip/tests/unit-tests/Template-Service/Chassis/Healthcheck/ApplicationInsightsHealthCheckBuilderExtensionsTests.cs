﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class ApplicationInsightsHealthCheckBuilderExtensionsTests
    {
        private MockRepository mockRepository;



        public ApplicationInsightsHealthCheckBuilderExtensionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }


        [Fact]
        public void AddApplicationInsightsPublisher_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }
    }
}
