﻿using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class DocumentDbOptionsTests
    {
        private MockRepository mockRepository;



        public DocumentDbOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

        }

        private DocumentDbOptions CreateDocumentDbOptions()
        {
            return new DocumentDbOptions();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var documentDbOptions = this.CreateDocumentDbOptions();

            // Act
            var result = (documentDbOptions.PrimaryKey,
                           documentDbOptions.UriEndpoint);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
    }
}
