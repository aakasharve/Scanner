﻿using Microsoft.ApplicationInsights.Extensibility;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class PrometheusHealthCheckMiddlewareTests
    {
        private MockRepository mockRepository;



        public PrometheusHealthCheckMiddlewareTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        //private PrometheusHealthCheckMiddleware CreatePrometheusHealthCheckMiddleware()
        //{
        //    return new PrometheusHealthCheckMiddleware();
        //}

        [Fact]
        public void UseHealthChecksPrometheusExporter_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }

        [Fact]
        public void UseHealthChecksPrometheusExporter_StateUnderTest_ExpectedBehavior1()
        {
            // Arrange
            var services = new ServiceCollection();
            services.Configure<TelemetryConfiguration>(config => config.InstrumentationKey = "telemetrykey");

            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher();

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }
    }
}
