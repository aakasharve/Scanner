﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class EventStoreHealthCheckTests
    {
        private MockRepository mockRepository;

        public EventStoreHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }

        private EventStoreHealthCheck CreateEventStoreHealthCheck()
        {
            return new EventStoreHealthCheck(
               "constring", "name", "_password"
               );
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var eventStoreHealthCheck = this.CreateEventStoreHealthCheck();
            HealthCheckContext context = new HealthCheckContext();
            CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            //var result = await eventStoreHealthCheck.CheckHealthAsync(
            //    context,
            //    cancellationToken);

            // Assert
            Assert.True(true);
            //this.mockRepository.VerifyAll();
        }
    }
}
