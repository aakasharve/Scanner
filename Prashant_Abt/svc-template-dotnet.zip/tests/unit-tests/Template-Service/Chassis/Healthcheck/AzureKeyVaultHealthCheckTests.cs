﻿using Azure.Core;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class AzureKeyVaultHealthCheckTests
    {
        private MockRepository mockRepository;

        private Mock<Uri> mockUri;
        private Mock<TokenCredential> mockTokenCredential;
        private Mock<AzureKeyVaultOptions> mockAzureKeyVaultOptions;

        public AzureKeyVaultHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockUri = this.mockRepository.Create<Uri>();
            this.mockTokenCredential = this.mockRepository.Create<TokenCredential>();
            this.mockAzureKeyVaultOptions = this.mockRepository.Create<AzureKeyVaultOptions>();
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services.AddHealthChecks()
                .AddAzureBlobStorage("the-connection-string");

            var serviceProvider = services.BuildServiceProvider();
            var options = serviceProvider.GetService<IOptions<HealthCheckServiceOptions>>();

            var registration = options.Value.Registrations.First();
            var check = registration.Factory(serviceProvider);

            registration.Name.Should().Be("azureblob");
            check.GetType().Should().Be(typeof(AzureBlobStorageHealthCheck));



        }
    }
}
