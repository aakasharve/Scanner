﻿using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class AzureKeyVaultOptionsTests
    {
        private MockRepository mockRepository;



        public AzureKeyVaultOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private AzureKeyVaultOptions CreateAzureKeyVaultOptions()
        {
            return new AzureKeyVaultOptions();
        }

        [Fact]
        public void AddSecret_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var azureKeyVaultOptions = this.CreateAzureKeyVaultOptions();
            string secretName = "AAA";

            // Act
            var result = azureKeyVaultOptions.AddSecret(
                secretName);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void AddKey_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var azureKeyVaultOptions = this.CreateAzureKeyVaultOptions();
            string keyName = "abc";

            // Act
            var result = azureKeyVaultOptions.AddKey(
                keyName);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void AddCertificate_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var azureKeyVaultOptions = this.CreateAzureKeyVaultOptions();
            string certificateName = "BBB";
            bool checkExpired = false;

            // Act
            var result = azureKeyVaultOptions.AddCertificate(
                certificateName,
                checkExpired);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
    }
}
