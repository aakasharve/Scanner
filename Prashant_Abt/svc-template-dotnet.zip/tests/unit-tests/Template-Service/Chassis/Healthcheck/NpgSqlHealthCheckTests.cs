﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using Npgsql;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class NpgSqlHealthCheckTests
    {
        private MockRepository mockRepository;

        private Mock<Action<NpgsqlConnection>> mockAction;

        public NpgSqlHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockAction = this.mockRepository.Create<Action<NpgsqlConnection>>();
        }

        private NpgSqlHealthCheck CreateNpgSqlHealthCheck()
        {
            return new NpgSqlHealthCheck(
                "_connectionString",
                "_sql",
                this.mockAction.Object);
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var npgSqlHealthCheck = this.CreateNpgSqlHealthCheck();
            //HealthCheckContext context = null;
            //CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            //// Act
            //var result = await npgSqlHealthCheck.CheckHealthAsync(
            //    context,
            //    cancellationToken);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
