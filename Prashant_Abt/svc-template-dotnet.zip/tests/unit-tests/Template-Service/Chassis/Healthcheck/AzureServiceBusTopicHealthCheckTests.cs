﻿using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class AzureServiceBusTopicHealthCheckTests
    {
        private MockRepository mockRepository;



        public AzureServiceBusTopicHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private AzureServiceBusTopicHealthCheck CreateAzureServiceBusTopicHealthCheck()
        {
            return new AzureServiceBusTopicHealthCheck(
                "_connectionString",
                "_topicName");
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var azureServiceBusTopicHealthCheck = this.CreateAzureServiceBusTopicHealthCheck();
            //HealthCheckContext context = null;
            //CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            //// Act
            //var result = await azureServiceBusTopicHealthCheck.CheckHealthAsync(
            //    context,
            //    cancellationToken);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
