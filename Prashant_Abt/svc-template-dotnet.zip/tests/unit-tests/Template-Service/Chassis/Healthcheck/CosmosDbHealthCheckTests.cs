﻿using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class CosmosDbHealthCheckTests
    {
        private MockRepository mockRepository;



        public CosmosDbHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private CosmosDbHealthCheck CreateCosmosDbHealthCheck()
        {
            return new CosmosDbHealthCheck(
                "database");
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var cosmosDbHealthCheck = this.CreateCosmosDbHealthCheck();
            //HealthCheckContext context = null;
            //CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            //// Act
            //var result = await cosmosDbHealthCheck.CheckHealthAsync(
            //    context,
            //    cancellationToken);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
