﻿using Azure.Storage.Blobs;
using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class AzureBlobStorageHealthCheckTests
    {
        private MockRepository mockRepository;

        private Mock<BlobClientOptions> mockBlobClientOptions;

        public AzureBlobStorageHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockBlobClientOptions = this.mockRepository.Create<BlobClientOptions>();
        }

        private AzureBlobStorageHealthCheck CreateAzureBlobStorageHealthCheck()
        {
            return new AzureBlobStorageHealthCheck(
                "containerName ",
                "clientOptions ",
                this.mockBlobClientOptions.Object);
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
          
            var services = new ServiceCollection();
            services.AddHealthChecks()
                .AddAzureBlobStorage("the-connection-string");

            var serviceProvider = services.BuildServiceProvider();
            var options = serviceProvider.GetService<IOptions<HealthCheckServiceOptions>>();

            var registration = options.Value.Registrations.First();
            var check = registration.Factory(serviceProvider);

            registration.Name.Should().Be("azureblob");
            check.GetType().Should().Be(typeof(AzureBlobStorageHealthCheck));
        }
    }
}
