﻿using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class TableServiceHealthCheckTests
    {
        private MockRepository mockRepository;



        public TableServiceHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private TableServiceHealthCheck CreateTableServiceHealthCheck()
        {
            return new TableServiceHealthCheck(
                "_connectionString",
                "_tableName");
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var tableServiceHealthCheck = this.CreateTableServiceHealthCheck();
   
            //// Act
        
            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
