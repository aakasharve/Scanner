﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Linq;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class AzureKeyVaultHealthChecksBuilderExtensionsTests
    {
        private MockRepository mockRepository;



        public AzureKeyVaultHealthChecksBuilderExtensionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

      
        [Fact]
        public void AddAzureKeyVault_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }
    }
}
