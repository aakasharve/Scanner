﻿using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class AzureServiceBusQueueHealthCheckTests
    {
        private MockRepository mockRepository;



        public AzureServiceBusQueueHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private AzureServiceBusQueueHealthCheck CreateAzureServiceBusQueueHealthCheck()
        {
            return new AzureServiceBusQueueHealthCheck(
                "context",
                "cancellationToken");
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var azureServiceBusQueueHealthCheck = this.CreateAzureServiceBusQueueHealthCheck();
           // HealthCheckContext context = null;
           // CancellationToken cancellationToken = default(global::System.Threading.CancellationToken);

            // Act
            //var result = await azureServiceBusQueueHealthCheck.CheckHealthAsync(
               // context,
              //  cancellationToken);

            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
