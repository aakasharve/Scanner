﻿using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class SendGridHealthCheckTests
    {
        private MockRepository mockRepository;

        private Mock<IHttpClientFactory> mockHttpClientFactory;

        public SendGridHealthCheckTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockHttpClientFactory = this.mockRepository.Create<IHttpClientFactory>();
        }

        private SendGridHealthCheck CreateSendGridHealthCheck()
        {
            return new SendGridHealthCheck(
                "_apiKey",
                this.mockHttpClientFactory.Object);
        }

        [Fact]
        public async Task CheckHealthAsync_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var sendGridHealthCheck = this.CreateSendGridHealthCheck();
          
            // Act
           
            // Assert
            Assert.True(true);
            this.mockRepository.VerifyAll();
        }
    }
}
