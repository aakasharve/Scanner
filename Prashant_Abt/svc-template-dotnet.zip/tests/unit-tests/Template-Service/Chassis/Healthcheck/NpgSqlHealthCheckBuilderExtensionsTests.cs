﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Moq;
using Neighborly.Chassis.Healthcheck;
using System;
using System.Linq;
using Xunit;

namespace Neighborly.Chassis.Healthcheck
{
    public class NpgSqlHealthCheckBuilderExtensionsTests
    {
        private MockRepository mockRepository;



        public NpgSqlHealthCheckBuilderExtensionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        [Fact]
        public void AddNpgSql_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services.AddHealthChecks()
                .AddAzureBlobStorage("the-connection-string", containerName: "container");

            var serviceProvider = services.BuildServiceProvider();
            var options = serviceProvider.GetService<IOptions<HealthCheckServiceOptions>>();

            var registration = options.Value.Registrations.First();
            var check = registration.Factory(serviceProvider);

            registration.Name.Should().Be("azureblob");
            check.GetType().Should().Be(typeof(AzureBlobStorageHealthCheck));
        }
    }
}
