﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Neighborly.Chassis.External.Client;
using RichardSzalay.MockHttp;

using Xunit;

namespace Neighborly
{
    public interface IHaveDims
    {
        [Get("")]
        internal Task<string> GetInternal();

        // DIMs require C# 8.0 which requires .NET Core 3.x or .NET Standard 2.1
#if NETCOREAPP3_1_OR_GREATER
        private Task<string> GetPrivate()
        {
            return GetInternal();
        }

        Task<string> GetDim()
        {
            return GetPrivate();
        }

        static string GetStatic()
        {
            return nameof(IHaveDims);
        }
#endif
    }

    // DIMs require C# 8.0 which requires .NET Core 3.x or .NET Standard 2.1
#if NETCOREAPP3_1_OR_GREATER
    public class DefaultInterfaceMethodTests
    {
        [Fact]
        public void StaticInterfaceMethodTest()
        {
            var plainText = IHaveDims.GetStatic();

            Assert.True(!string.IsNullOrWhiteSpace(plainText));
        }
    }
#endif
}
