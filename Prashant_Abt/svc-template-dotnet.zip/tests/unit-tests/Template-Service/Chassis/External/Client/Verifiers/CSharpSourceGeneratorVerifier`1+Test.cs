﻿
using Microsoft.CodeAnalysis;

namespace Neighborly.External.Client.Verifiers
{
    public static partial class CSharpSourceGeneratorVerifier<TSourceGenerator>
        where TSourceGenerator : ISourceGenerator, new()
    {
        //public class Test : CSharpSourceGeneratorTest<TSourceGenerator, XUnitVerifier>
        //{
        //    public Test()
        //    {
        //        SolutionTransforms.Add((solution, projectId) =>
        //        {
        //            var compilationOptions = solution.GetProject(projectId).CompilationOptions;
        //            compilationOptions = compilationOptions.WithSpecificDiagnosticOptions(
        //                compilationOptions.SpecificDiagnosticOptions.SetItems(CSharpVerifierHelper.NullableWarnings));
        //            solution = solution.WithProjectCompilationOptions(projectId, compilationOptions);

        //            return solution;
        //        });
        //    }
        //}
    }
}
