﻿using Microsoft.CodeAnalysis;

namespace Neighborly.External.Client.Verifiers
{
    public static partial class CSharpSourceGeneratorVerifier<TSourceGenerator>
        where TSourceGenerator : ISourceGenerator, new()
    {
    }
}
