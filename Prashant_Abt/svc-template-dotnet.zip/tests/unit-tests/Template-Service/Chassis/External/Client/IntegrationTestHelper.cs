﻿using System.IO;
using System.Linq;
using System.Runtime.CompilerServices;

namespace Neighborly
{
    public static class IntegrationTestHelper
    {
        public static string GetPath(params string[] paths)
        {
            var ret = GetIntegrationTestRootDirectory();
            return (new FileInfo(paths.Aggregate(ret, Path.Combine))).FullName;
        }

        public static string GetIntegrationTestRootDirectory([CallerFilePath] string filePath = default)
        {
            // XXX: This is an evil hack, but it's okay for a unit test
            // We can't use Assembly.Location because unit test runners love
            // to move stuff to temp directories
            var di = new DirectoryInfo(Path.Combine(Path.GetDirectoryName(filePath)));

            return di.FullName;
        }
    }
}
