﻿using Neighborly.Chassis.External.Client;
using System.ComponentModel;
using System.Threading.Tasks;

interface IFooWithOtherAttribute
{
    [Get("/")]
    Task GetRoot();

    [DisplayName("/")]
    Task PostRoot();
}
