﻿using Neighborly.Chassis.External.Client;
using System.Threading.Tasks;

interface IServiceWithoutNamespace
{
    [Get("/")]
    Task GetRoot();

    [Post("/")]
    Task PostRoot();
}
