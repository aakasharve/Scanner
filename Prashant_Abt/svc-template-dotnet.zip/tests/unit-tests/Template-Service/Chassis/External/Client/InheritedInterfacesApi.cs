﻿using Neighborly.Chassis.External.Client;
using Neighborly.SeparateNamespaceWithModel;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Neighborly
{
    [Headers("User-Agent: Neighborly Integration Tests")]
    public interface IAmInterface : IAmInterfaceB, IAmInterfaceA
    {
        [Get("/get?result=Pang")]
        Task<string> Pang();
    }

    [Headers("User-Agent: Neighborly Integration Tests")]
    public interface IAmInterfaceA
    {
        [Get("/get?result=Ping")]
        Task<string> Ping();
    }

    [Headers("User-Agent: Neighborly Integration Tests")]
    public interface IAmInterfaceB : IAmInterfaceD
    {
        [Get("/get?result=Pong")]
        Task<string> Pong();
    }

    [Headers("User-Agent: Neighborly Integration Tests")]
    public interface IAmInterfaceC : IAmInterfaceB, IAmInterfaceA
    {
        [Get("/get?result=Pang")]
        Task<string> Pang();
    }

    public interface IAmInterfaceD
    {
        [Get("/get?result=Test")]
        Task<string> Test();
    }

    public interface IAmInterfaceF_RequireUsing
    {
        [Get("/get-requiring-using")]
        Task<ResponseModel> Get(List<Guid> guids);
    }

    public interface IContainAandB : IAmInterfaceB, IAmInterfaceA
    {

    }

    public interface IAmInterfaceEWithNoNeighborly<T>
    {
        public Task DoSomething(T parameter);

        public Task DoSomethingElse();
    }

    public interface IImplementTheInterfaceAndUseNeighborly : IAmInterfaceEWithNoNeighborly<int>
    {
#pragma warning disable CS0108 // Member hides inherited member; missing new keyword
        [Get("/doSomething")]
        public Task DoSomething(int parameter);
#pragma warning restore CS0108 // Member hides inherited member; missing new keyword

        [Get("/DoSomethingElse")]
        public new Task DoSomethingElse();
    }
}

namespace Neighborly.SeparateNamespaceWithModel
{
    public class ResponseModel { }
}
