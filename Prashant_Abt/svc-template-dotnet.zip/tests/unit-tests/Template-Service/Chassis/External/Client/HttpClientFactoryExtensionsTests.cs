﻿
using Microsoft.Extensions.Options;


namespace Neighborly
{
    using Microsoft.Extensions.DependencyInjection;
    using Neighborly.Chassis.External.Client;
    using System.Collections.Generic;
    using System.Text.Json;
    using System.Threading.Tasks;
    using Xunit;

    public class HttpClientFactoryExtensionsTests
    {
        class User
        {
        }

        class Role
        {
        }
        public interface IBoringCrudApi<T, in TKey> where T : class
        {
            [Post("")]
            Task<T> Create([Body] T paylod);

            [Get("")]
            Task<List<T>> ReadAll();

            [Get("/{key}")]
            Task<T> ReadOne(TKey key);

            [Put("/{key}")]
            Task Update(TKey key, [Body] T payload);

            [Delete("/{key}")]
            Task Delete(TKey key);
        }

        [Fact]
        public void GenericHttpClientsAreAssignedUniqueNames()
        {
            var services = new ServiceCollection();

            var userClientName = services.AddExternalServiceClient<IBoringCrudApi<User, string>>().Name;
            var roleClientName = services.AddExternalServiceClient<IBoringCrudApi<Role, string>>().Name;

            Assert.NotEqual(userClientName, roleClientName);
        }

        [Fact]
        public void HttpClientServicesAreAddedCorrectlyGivenGenericArgument()
        {
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddExternalServiceClient<IFooWithOtherAttribute>();
            //Assert.Contains(serviceCollection, z => z.ServiceType == typeof(SettingsFor<IFooWithOtherAttribute>));
            Assert.Contains(serviceCollection, z => z.ServiceType == typeof(IRequestBuilder<IFooWithOtherAttribute>));
        }

        [Fact]
        public void HttpClientServicesAreAddedCorrectlyGivenTypeArgument()
        {
            var serviceCollection = new ServiceCollection();
            
            serviceCollection.AddExternalServiceClient(typeof(IFooWithOtherAttribute));
            Assert.Contains(serviceCollection, z => z.ServiceType == typeof(SettingsFor<IFooWithOtherAttribute>));
            Assert.Contains(serviceCollection, z => z.ServiceType == typeof(IRequestBuilder<IFooWithOtherAttribute>));
        }

        //[Fact]
        //public void HttpClientReturnsClientGivenGenericArgument()
        //{
        //    var serviceCollection = new ServiceCollection();
        //    serviceCollection.AddExternalServiceClient<IFooWithOtherAttribute>();
        //    var serviceProvider = serviceCollection.BuildServiceProvider();
        //    Assert.NotNull(serviceProvider.GetService<IFooWithOtherAttribute>());
        //}

        //[Fact]
        //public void HttpClientReturnsClientGivenTypeArgument()
        //{
        //    var serviceCollection = new ServiceCollection();
        //    serviceCollection.AddExternalServiceClient(typeof(IFooWithOtherAttribute));
        //    var serviceProvider = serviceCollection.BuildServiceProvider();
        //    Assert.NotNull(serviceProvider.GetService<IFooWithOtherAttribute>());
        //}

        [Fact]
        public void HttpClientSettingsAreInjectableGivenGenericArgument()
        {
            var serviceCollection = new ServiceCollection()
                .Configure<ClientOptions>(o => o.Serializer = new SystemTextJsonContentSerializer(new JsonSerializerOptions()));
            serviceCollection.AddExternalServiceClient<IFooWithOtherAttribute>(_ => new ServiceClientSettings() {ContentSerializer = _.GetRequiredService<IOptions<ClientOptions>>().Value.Serializer});
            var serviceProvider = serviceCollection.BuildServiceProvider();
            Assert.Same(
                serviceProvider.GetRequiredService<IOptions<ClientOptions>>().Value.Serializer,
                serviceProvider.GetRequiredService<SettingsFor<IFooWithOtherAttribute>>().Settings!.ContentSerializer
            );
        }

        [Fact]
        public void HttpClientSettingsAreInjectableGivenTypeArgument()
        {
            var serviceCollection = new ServiceCollection()
                .Configure<ClientOptions>(o => o.Serializer = new SystemTextJsonContentSerializer(new JsonSerializerOptions()));
            serviceCollection.AddExternalServiceClient(typeof(IFooWithOtherAttribute), _ => new ServiceClientSettings() {ContentSerializer = _.GetRequiredService<IOptions<ClientOptions>>().Value.Serializer});
            var serviceProvider = serviceCollection.BuildServiceProvider();
            Assert.Same(
                serviceProvider.GetRequiredService<IOptions<ClientOptions>>().Value.Serializer,
                serviceProvider.GetRequiredService<SettingsFor<IFooWithOtherAttribute>>().Settings!.ContentSerializer
            );
        }

        [Fact]
        public void HttpClientSettingsCanBeProvidedStaticallyGivenGenericArgument()
        {
            var contentSerializer = new SystemTextJsonContentSerializer(new JsonSerializerOptions());
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddExternalServiceClient<IFooWithOtherAttribute>(new ServiceClientSettings() {ContentSerializer = contentSerializer });
            var serviceProvider = serviceCollection.BuildServiceProvider();
            Assert.Same(
                contentSerializer,
                serviceProvider.GetRequiredService<SettingsFor<IFooWithOtherAttribute>>().Settings!.ContentSerializer
            );
        }

        [Fact]
        public void HttpClientSettingsCanBeProvidedStaticallyGivenTypeArgument()
        {
            var contentSerializer = new SystemTextJsonContentSerializer(new JsonSerializerOptions());
            var serviceCollection = new ServiceCollection();
            serviceCollection.AddExternalServiceClient<IFooWithOtherAttribute>(new ServiceClientSettings() {ContentSerializer = contentSerializer });
            var serviceProvider = serviceCollection.BuildServiceProvider();
            Assert.Same(
                contentSerializer,
                serviceProvider.GetRequiredService<SettingsFor<IFooWithOtherAttribute>>().Settings!.ContentSerializer
            );
        }

        class ClientOptions
        {
            public SystemTextJsonContentSerializer Serializer { get; set; }
        }
    }
}
