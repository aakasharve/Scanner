﻿using Neighborly.Chassis.External.Client;
using System.Threading.Tasks;

namespace Neighborly
{
    public partial interface PartialInterfacesApi
    {
        [Get("/get?result=Second")]
        Task<string> Second();
    }
}
