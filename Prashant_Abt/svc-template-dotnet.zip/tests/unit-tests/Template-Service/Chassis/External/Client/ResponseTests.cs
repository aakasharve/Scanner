﻿using Neighborly.Chassis.External.Client;
using Newtonsoft.Json;
using RichardSzalay.MockHttp;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
// for the code gen
using Xunit;

namespace Neighborly
{
    public class TestAliasObject
    {
        [AliasAs("FIELD_WE_SHOULD_SHORTEN_WITH_ALIAS_AS")]
        public string ShortNameForAlias { get; set; }

        [JsonProperty(PropertyName = "FIELD_WE_SHOULD_SHORTEN_WITH_JSON_PROPERTY")]
        [JsonPropertyName("FIELD_WE_SHOULD_SHORTEN_WITH_JSON_PROPERTY")]
        public string ShortNameForJsonProperty { get; set; }
    }

    //public class ResponseTests
    //{
    //    readonly MockHttpMessageHandler mockHandler;
    //    readonly IMyAliasService fixture;
    //    public ResponseTests()
    //    {
    //        mockHandler = new MockHttpMessageHandler();

    //        var settings = new ServiceClientSettings
    //        {
    //            HttpMessageHandlerFactory = () => mockHandler
    //        };

    //        fixture = ExternalService.For<IMyAliasService>("http://api", settings);
    //    }

    //    public interface IMyAliasService
    //    {
    //        [Get("/aliasTest")]
    //        Task<TestAliasObject> GetTestObject();
    //    }

    //    [Fact]
    //    public async Task JsonPropertyCanBeUsedToAliasFieldNamesInResponses()
    //    {
    //        mockHandler.Expect(HttpMethod.Get, "http://api/aliasTest")
    //            .Respond("application/json", "{\"FIELD_WE_SHOULD_SHORTEN_WITH_ALIAS_AS\": \"Hello\", \"FIELD_WE_SHOULD_SHORTEN_WITH_JSON_PROPERTY\": \"World\"}");

    //        var result = await fixture.GetTestObject();

    //        Assert.Equal("World", result.ShortNameForJsonProperty);
    //    }

    //    /// <summary>
    //    /// Even though it may seem like AliasAs and JsonProperty are used interchangeably in some places,
    //    /// when serializing responses, AliasAs will not work -- only JsonProperty will.
    //    /// </summary>
    //    [Fact]
    //    public async Task AliasAsCannotBeUsedToAliasFieldNamesInResponses()
    //    {

    //        mockHandler.Expect(HttpMethod.Get, "http://api/aliasTest")
    //            .Respond("application/json", "{\"FIELD_WE_SHOULD_SHORTEN_WITH_ALIAS_AS\": \"Hello\", \"FIELD_WE_SHOULD_SHORTEN_WITH_JSON_PROPERTY\": \"World\"}");

    //        var result = await fixture.GetTestObject();

    //        Assert.Null(result.ShortNameForAlias);
    //    }

    //    /// <summary>
    //    /// Test to verify if a ValidationException is thrown for a Bad Request in terms of RFC 7807
    //    /// </summary>
    //    [Fact]
    //    public async Task ThrowsValidationException()
    //    {
    //        var expectedContent = new ProblemDetails
    //        {
    //            Detail = "detail",
    //            Errors = { { "Field1", new string[] { "Problem1" } }, { "Field2", new string[] { "Problem2" } } },
    //            Instance = "instance",
    //            Status = 1,
    //            Title = "title",
    //            Type = "type"
    //        };
    //        var expectedResponse = new HttpResponseMessage(HttpStatusCode.BadRequest)
    //        {
    //            Content = new StringContent(JsonConvert.SerializeObject(expectedContent))
    //        };
    //        expectedResponse.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/problem+json");
    //        mockHandler.Expect(HttpMethod.Get, "http://api/aliasTest")
    //            .Respond(req => expectedResponse);

    //        var actualException = await Assert.ThrowsAsync<ValidationApiException>(() => fixture.GetTestObject());
    //        Assert.NotNull(actualException.Content);
    //        Assert.Equal("detail", actualException.Content.Detail);
    //        Assert.Equal("Problem1", actualException.Content.Errors["Field1"][0]);
    //        Assert.Equal("Problem2", actualException.Content.Errors["Field2"][0]);
    //        Assert.Equal("instance", actualException.Content.Instance);
    //        Assert.Equal(1, actualException.Content.Status);
    //        Assert.Equal("title", actualException.Content.Title);
    //        Assert.Equal("type", actualException.Content.Type);
    //    }

    //    [Fact]
    //    public async Task WhenProblemDetailsResponseContainsExtensions_ShouldHydrateExtensions()
    //    {
    //        var expectedContent = new
    //        {
    //            Detail = "detail",
    //            Instance = "instance",
    //            Status = 1,
    //            Title = "title",
    //            Type = "type",
    //            Foo = "bar",
    //            Baz = 123d,
    //        };

    //        var expectedResponse = new HttpResponseMessage(HttpStatusCode.BadRequest)
    //        {
    //            Content = new StringContent(JsonConvert.SerializeObject(expectedContent))
    //        };

    //        expectedResponse.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/problem+json");
    //        mockHandler.Expect(HttpMethod.Get, "http://api/aliasTest")
    //            .Respond(req => expectedResponse);

    //        var actualException = await Assert.ThrowsAsync<ValidationApiException>(() => fixture.GetTestObject());
    //        Assert.NotNull(actualException.Content);
    //        Assert.Equal("detail", actualException.Content.Detail);
    //        Assert.Equal("instance", actualException.Content.Instance);
    //        Assert.Equal(1, actualException.Content.Status);
    //        Assert.Equal("title", actualException.Content.Title);
    //        Assert.Equal("type", actualException.Content.Type);

    //        Assert.Collection(actualException.Content.Extensions,
    //            kvp => Assert.Equal(new KeyValuePair<string, object>(nameof(expectedContent.Foo), expectedContent.Foo), kvp),
    //            kvp => Assert.Equal(new KeyValuePair<string, object>(nameof(expectedContent.Baz), expectedContent.Baz), kvp));
    //    }

    //    [Fact]
    //    public async Task BadRequestWithEmptyContent_ShouldReturnApiException()
    //    {
    //        var expectedResponse = new HttpResponseMessage(HttpStatusCode.BadRequest)
    //        {
    //            Content = new StringContent("Hello world")
    //        };
    //        expectedResponse.Content.Headers.Clear();

    //        mockHandler.Expect(HttpMethod.Get, "http://api/aliasTest")
    //            .Respond(req => expectedResponse);

    //        var actualException = await Assert.ThrowsAsync<ApiException>(() => fixture.GetTestObject());

    //        Assert.NotNull(actualException.Content);
    //        Assert.Equal("Hello world", actualException.Content);
    //    }

    //    [Fact]
    //    public async Task ValidationApiException_HydratesBaseContent()
    //    {
    //        var expectedProblemDetails = new ProblemDetails
    //        {
    //            Detail = "detail",
    //            Instance = "instance",
    //            Status = 1,
    //            Title = "title",
    //            Type = "type"
    //        };
    //        var expectedContent = JsonConvert.SerializeObject(expectedProblemDetails);
    //        var expectedResponse = new HttpResponseMessage(HttpStatusCode.BadRequest)
    //        {
    //            Content = new StringContent(expectedContent)
    //        };
    //        expectedResponse.Content.Headers.ContentType = new MediaTypeHeaderValue("application/problem+json");
    //        mockHandler.Expect(HttpMethod.Get, "http://api/aliasTest")
    //            .Respond(req => expectedResponse);

    //        var actualException = await Assert.ThrowsAsync<ValidationApiException>(() => fixture.GetTestObject());
    //        var actualBaseException = actualException as ApiException;
    //        Assert.Equal(expectedContent, actualBaseException.Content);
    //    }


    //    [Fact]
    //    public async Task WithHtmlResponse_ShouldReturnApiException()
    //    {
    //        const string htmlResponse = "<html><body>Hello world</body></html>";
    //        var expectedResponse = new HttpResponseMessage(HttpStatusCode.OK)
    //        {
    //            Content = new StringContent(htmlResponse)
    //        };
    //        expectedResponse.Content.Headers.Clear();

    //        mockHandler.Expect(HttpMethod.Get, "http://api/aliasTest")
    //                   .Respond(req => expectedResponse);

    //        var actualException = await Assert.ThrowsAsync<ApiException>(() => fixture.GetTestObject());

    //        Assert.IsType<System.Text.Json.JsonException>(actualException.InnerException);
    //        Assert.NotNull(actualException.Content);
    //        Assert.Equal(htmlResponse, actualException.Content);
    //    }

    //    [Fact]
    //    public async Task WithNonJsonResponseUsingNewtonsoftJsonContentSerializer_ShouldReturnApiException()
    //    {
    //        var settings = new ServiceClientSettings
    //        {
    //            HttpMessageHandlerFactory = () => mockHandler,
    //            ContentSerializer = new NewtonsoftJsonContentSerializer()
    //        };

    //        var newtonSoftFixture = ExternalService.For<IMyAliasService>("http://api", settings);

    //        const string nonJsonResponse = "bad response";
    //        var expectedResponse = new HttpResponseMessage(HttpStatusCode.OK)
    //        {
    //            Content = new StringContent(nonJsonResponse)
    //        };
    //        expectedResponse.Content.Headers.Clear();

    //        mockHandler.Expect(HttpMethod.Get, "http://api/aliasTest")
    //                   .Respond(req => expectedResponse);

    //        var actualException = await Assert.ThrowsAsync<ApiException>(() => newtonSoftFixture.GetTestObject());

    //        Assert.IsType<JsonReaderException>(actualException.InnerException);
    //        Assert.NotNull(actualException.Content);
    //        Assert.Equal(nonJsonResponse, actualException.Content);
    //    }


    //}

    public sealed class ThrowOnGetLengthMemoryStream : MemoryStream
    {
        public bool CanGetLength { get; set; }

        public override long Length => CanGetLength ? base.Length : throw new NotSupportedException();
    }
}
