﻿using CollisionB;
using Neighborly.Chassis.External.Client;
using System.Threading.Tasks;

namespace Neighborly
{
    public interface ITypeCollisionApiB
    {
        [Get("")]
        Task<SomeType> SomeBRequest();
    }

    public static class TypeCollisionApiB
    {
        public static ITypeCollisionApiB Create()
        {
            return ExternalService.For<ITypeCollisionApiB>("http://somewhere.com");
        }
    }
}
