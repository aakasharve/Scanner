﻿using Common.Helper;
using Neighborly.Chassis.External.Client;
using Neighborly.Tests.Common;
using System;
using System.Threading.Tasks;
// InterfaceStubGenerator looks for this

namespace Neighborly
{
    [SomeHelper]
    public interface INamespaceOverlapApi
    {
        [Get("/")]
        Task<SomeOtherType> SomeRequest();
    }

    public static class NamespaceOverlapApi
    {
        public static INamespaceOverlapApi Create()
        {
            return ExternalService.For<INamespaceOverlapApi>("http://somewhere.com");
        }
    }
}

namespace Common.Helper
{
    public class SomeHelperAttribute : Attribute { }
}

namespace Neighborly.Tests.Common
{
    public class SomeOtherType { }
}
