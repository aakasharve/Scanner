﻿using System.Threading.Tasks;

namespace Neighborly
{
    using Neighborly.Chassis.External.Client;
    using Neighborly.Tests.ModelNamespace;

    public interface IReducedUsingInsideNamespaceApi
    {
        [Get("/")]
        Task<SomeType> SomeRequest();
    }
}

namespace Neighborly.Tests.ModelNamespace
{
    public class SomeType { }
}
