﻿using Neighborly.Chassis.External.Client;
using RichardSzalay.MockHttp;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly
{
    public class AuthenticatedClientHandlerTests
    {
        public interface IMyAuthenticatedService
        {
            [Get("/unauth")]
            Task<string> GetUnauthenticated();

            [Get("/auth")]
            [Headers("Authorization: Bearer")]
            Task<string> GetAuthenticated();

            [Get("/auth")]
            Task<string> GetAuthenticatedWithTokenInMethod([Authorize("Bearer")] string token);
        }

        public interface IInheritedAuthenticatedServiceWithHeaders : IAuthenticatedServiceWithHeaders
        {
            [Get("/get-inherited-thing")]
            Task<string> GetInheritedThing();
        }

        [Headers("Authorization: Bearer")]
        public interface IAuthenticatedServiceWithHeaders
        {
            [Get("/get-base-thing")]
            Task<string> GetThingFromBase();
        }

        [Fact]
        public void DefaultHandlerIsHttpClientHandler()
        {
            var handler = new AuthenticatedHttpClientHandler((() => Task.FromResult(string.Empty)));

            Assert.IsType<HttpClientHandler>(handler.InnerHandler);
        }

        [Fact]
        public void DefaultHandlerIsHttpClientHandlerWithParam()
        {
            var handler = new AuthenticatedParameterizedHttpClientHandler(((request) => Task.FromResult(string.Empty)));

            Assert.IsType<HttpClientHandler>(handler.InnerHandler);
        }

        [Fact]
        public void NullTokenGetterThrows()
        {
            Assert.Throws<ArgumentNullException>(() => new AuthenticatedHttpClientHandler(null));
        }

        [Fact]
        public void NullTokenGetterThrowsWithParam()
        {
            Assert.Throws<ArgumentNullException>(() => new AuthenticatedParameterizedHttpClientHandler(null));
        }
    }
}
