﻿using CollisionA;
using Neighborly.Chassis.External.Client;
using System.Threading.Tasks;

namespace Neighborly
{
    public interface ITypeCollisionApiA
    {
        [Get("")]
        Task<SomeType> SomeARequest();
    }

    public static class TypeCollisionApiA
    {
        public static ITypeCollisionApiA Create()
        {
            return ExternalService.For<ITypeCollisionApiA>("http://somewhere.com");
        }
    }
}
