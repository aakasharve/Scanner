﻿using global::System.Threading.Tasks;

namespace Neighborly
{
    using global::Neighborly.SomeNamespace;
    using Neighborly.Chassis.External.Client;

    public interface NamespaceWithGlobalAliasApi
    {
        [Get("/")]
        Task<SomeType> SomeRequest();
    }
}

namespace Neighborly.SomeNamespace
{
    public class SomeType { }
}
