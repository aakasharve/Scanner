﻿using Neighborly.Chassis.External.Client;
using System.Threading.Tasks;

namespace Neighborly
{
    public interface InheritedInterfacesInSeparateFileApi: IAmInterfaceF_RequireUsing
    {
        [Get("/get")]
        Task Get(int i);
    }
}
