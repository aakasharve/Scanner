﻿using Moq;
using Neighborly.Chassis.Helper;
using System;
using Xunit;

namespace Neighborly.Chassis.Helper
{
    public class DateTimeUtilitiesTests
    {
        private MockRepository mockRepository;



        public DateTimeUtilitiesTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }


        [Fact]
        public void ConvertDateTimeToEpoch_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            DateTime utcNow = DateTime.UtcNow;

            // Act
            var result = DateTimeUtilities.ConvertDateTimeToEpoch(
                utcNow);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ConvertEpochToDateTime_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            long timestamp = 1646739051;

            // Act
            var result = DateTimeUtilities.ConvertEpochToDateTime(
                timestamp);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ConvertEpochToSpecificTimeZone_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            long timestamp = 1646739051;
            string? timeZone = Neighborly.Service.Constants.DEFAULT_TIMEZONE;

            // Act
            var result = DateTimeUtilities.ConvertEpochToSpecificTimeZone(
                timestamp,
                timeZone);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void ConvertEpochToSpecificTimeZone_StateUnderTest_ExpectedBehavior_TimeZoneNotFound()
        {
            try
            {
                // Arrange
                long timestamp = 1646739051;
                string? timeZone = "Test";

                // Act
                var result = DateTimeUtilities.ConvertEpochToSpecificTimeZone(
                    timestamp,
                    timeZone);

                // Assert
                Assert.NotNull(result);
                this.mockRepository.VerifyAll();
            }
            catch (Exception ex)
            {
                Assert.False(false);
            }
        }
        [Fact]
        public void ConvertEpochToSpecificTimeZone_StateUnderTest_ExpectedBehavior_InvalideTimeZone()
        {
            try
            {
                // Arrange
                long timestamp = 7777777777777777;
                string? timeZone = "";

                // Act
                var result = DateTimeUtilities.ConvertEpochToSpecificTimeZone(
                    timestamp,
                    timeZone);

                // Assert
                Assert.NotNull(result);
                this.mockRepository.VerifyAll();
            }
            catch (Exception ex)
            {
                Assert.False(false);
            }
        }
        [Fact]
        public void GetDaylightSavingTime_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            DateTime timestamp = DateTime.UtcNow;
            string? timeZone = Neighborly.Service.Constants.DEFAULT_TIMEZONE; ;

            // Act
            var result = DateTimeUtilities.GetDaylightSavingTime(
                timestamp,
                timeZone);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
        [Fact]
        public void GetDaylightSavingTime_StateUnderTest_ExpectedBehavior_TimeZoneNotFounr()
        {
            try
            {
                // Arrange
                DateTime timestamp = DateTime.UtcNow;
                string? timeZone = "Test";

                // Act
                var result = DateTimeUtilities.GetDaylightSavingTime(
                    timestamp,
                    timeZone);

                // Assert
                Assert.NotNull(result);
                this.mockRepository.VerifyAll();
            }
            catch (Exception ex)
            {
                Assert.False(false);
            }
        }

        [Fact]
        public void ConvertDateToSpecificUTC_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            DateTime timestamp = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);
            string? timeZone = Neighborly.Service.Constants.DEFAULT_TIMEZONE;

            // Act
            var result = DateTimeUtilities.ConvertDateToSpecificUTC(
                timestamp,
                timeZone);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
        [Fact]
        public void ConvertDateToSpecificUTC_StateUnderTest_ExpectedBehavior_InvalidTimeZone()
        {
            try
            {
                // Arrange
                DateTime timestamp = DateTime.SpecifyKind(DateTime.Now, DateTimeKind.Unspecified);
            string? timeZone = "Test";

            // Act
            var result = DateTimeUtilities.ConvertDateToSpecificUTC(
                timestamp,
                timeZone);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
            }
            catch (Exception ex)
            {
                Assert.False(false);
            }
        }

        [Fact]
        public void ConvertDateToSpecificUTC_StateUnderTest_ExpectedBehavior_Exception()
        {
            try
            {
                // Arrange
                DateTime timestamp = DateTime.Now;
                string? timeZone = Neighborly.Service.Constants.DEFAULT_TIMEZONE;

                // Act
                var result = DateTimeUtilities.ConvertDateToSpecificUTC(
                    timestamp,
                    timeZone);

                // Assert
                Assert.NotNull(result);
                this.mockRepository.VerifyAll();
            }
            catch (Exception ex)
            {
                Assert.False(false);
            }
        }
    }
}
