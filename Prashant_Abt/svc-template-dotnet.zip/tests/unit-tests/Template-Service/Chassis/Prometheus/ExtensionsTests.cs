﻿using FluentAssertions;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Moq;
using Neighborly.Chassis.Healthcheck;
using Neighborly.Chassis.Prometheus;
using System;
using System.Linq;
using Xunit;

namespace Neighborly.Chassis.Prometheus
{
    public class ExtensionsTests
    {
        private MockRepository mockRepository;



        public ExtensionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }


        [Fact]
        public void AddPrometheus_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services.AddHealthChecks()
                .AddRedis("connectionstring", name: "my-redis");

            var serviceProvider = services.BuildServiceProvider();
            var options = serviceProvider.GetService<IOptions<HealthCheckServiceOptions>>();

            var registration = options.Value.Registrations.First();
            var check = registration.Factory(serviceProvider);

            registration.Name.Should().Be("my-redis");
            check.GetType().Should().Be(typeof(RedisHealthCheck));
        }

        [Fact]
        public void UsePrometheus_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services.AddHealthChecks()
                .AddRedis("connectionstring", name: "my-redis");

            var serviceProvider = services.BuildServiceProvider();
            var options = serviceProvider.GetService<IOptions<HealthCheckServiceOptions>>();

            var registration = options.Value.Registrations.First();
            var check = registration.Factory(serviceProvider);

            registration.Name.Should().Be("my-redis");
            check.GetType().Should().Be(typeof(RedisHealthCheck));
        }
    }
}
