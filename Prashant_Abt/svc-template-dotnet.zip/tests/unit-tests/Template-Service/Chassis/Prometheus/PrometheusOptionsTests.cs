﻿using Moq;
using Neighborly.Chassis.Prometheus;
using System;
using Xunit;

namespace Neighborly.Chassis.Prometheus
{
    public class PrometheusOptionsTests
    {
        private MockRepository mockRepository;



        public PrometheusOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private PrometheusOptions CreatePrometheusOptions()
        {
            return new PrometheusOptions();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var prometheusOptions = this.CreatePrometheusOptions();

            // Act
            var result = (prometheusOptions.Enabled,
                           prometheusOptions.Enabled,
                           prometheusOptions.ApiKey,
                           prometheusOptions.AllowedHosts);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
    }
}
