﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Moq;
using Neighborly.Chassis.Prometheus;
using System;
using System.Threading.Tasks;
using Xunit;

namespace Neighborly.Chassis.Prometheus
{
    public class PrometheusMiddlewareTests
    {
        private MockRepository mockRepository;

        private Mock<PrometheusOptions> mockPrometheusOptions;

        public PrometheusMiddlewareTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);

            this.mockPrometheusOptions = this.mockRepository.Create<PrometheusOptions>();
        }

        private PrometheusMiddleware CreatePrometheusMiddleware()
        {
            return new PrometheusMiddleware(
                this.mockPrometheusOptions.Object);
        }

        [Fact]
        public async Task InvokeAsync_StateUnderTest_ExpectedBehavior()
        {
            var services = new ServiceCollection();
            services
                .AddHealthChecks()
                .AddApplicationInsightsPublisher("telemetrykey");

            var serviceProvider = services.BuildServiceProvider();
            var publisher = serviceProvider.GetService<IHealthCheckPublisher>();

            Assert.NotNull(publisher);
        }
    }
}
