﻿using FluentAssertions;

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Moq;
using System.Linq;
using Xunit;

namespace Neighborly.Chassis
{
    public class NeighborlyServiceCollectionExtensionTests
    {
        private MockRepository mockRepository;

        public NeighborlyServiceCollectionExtensionTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);
        }       
    }
}
