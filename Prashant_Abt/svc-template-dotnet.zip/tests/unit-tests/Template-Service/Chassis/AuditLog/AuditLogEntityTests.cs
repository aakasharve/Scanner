﻿using Moq;
using Neighborly.Service;
using System;
using Xunit;

namespace Neighborly.Chassis.AuditLog
{
    public class AuditLogEntityTests
    {
        private MockRepository mockRepository;



        public AuditLogEntityTests()
        {
            mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private AuditLogEntity CreateAuditLogEntity()
        {
            return new AuditLogEntity();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var auditLogEntity = CreateAuditLogEntity();

            // Act
            auditLogEntity.BuId = Guid.NewGuid();
            auditLogEntity.CoId = 123;
            auditLogEntity.EntityId = "EntityId";
            auditLogEntity.EntityType = new Enums.AuditEntityType();
            auditLogEntity.ErrorMessage = "ErrorMessage";
            auditLogEntity.LoggedDateTime = 124;
            auditLogEntity.RequestPayload = "RequestPayload";
            auditLogEntity.RequestStatus = new Enums.RequestStatusCode();
            auditLogEntity.RequestType = new Enums.AuditRequestType();
            auditLogEntity.RequestUri = "RequestUri";
            auditLogEntity.UserId = "UserId";
            auditLogEntity.Description = "";
            auditLogEntity.EntityNumber = "test1234";
            auditLogEntity.Description = "Description";
            auditLogEntity.Username = "userName";
            auditLogEntity.EntityNumber = "EntityNumber";
            auditLogEntity.OldValues = "OldValues";
            auditLogEntity.NewValues = "NewValues";
            auditLogEntity.LoBId = Guid.NewGuid();


            // Assert
            Assert.NotNull(auditLogEntity);
            mockRepository.VerifyAll();
        }
    }
}
