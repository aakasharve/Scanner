﻿using Moq;
using Neighborly.Chassis.Redis;
using System;
using Xunit;

namespace Neighborly.Chassis.Redis
{
    public class RedisOptionsTests
    {
        private MockRepository mockRepository;



        public RedisOptionsTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private RedisOptions CreateRedisOptions()
        {
            return new RedisOptions();
        }

        [Fact]
        public void TestMethod1()
        {
            // Arrange
            var redisOptions = this.CreateRedisOptions();

            // Act
            var result = (redisOptions.ConnectionString,
                          redisOptions.Instance,
                          redisOptions.Database);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
    }
}
