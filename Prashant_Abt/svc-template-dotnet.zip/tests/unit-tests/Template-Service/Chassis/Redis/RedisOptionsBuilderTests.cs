﻿using Moq;
using Neighborly.Chassis.Redis;
using System;
using Xunit;

namespace Neighborly.Chassis.Redis
{
    public class RedisOptionsBuilderTests
    {
        private MockRepository mockRepository;



        public RedisOptionsBuilderTests()
        {
            this.mockRepository = new MockRepository(MockBehavior.Strict);


        }

        private RedisOptionsBuilder CreateRedisOptionsBuilder()
        {
            return new RedisOptionsBuilder();
        }

        [Fact]
        public void WithConnectionString_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var redisOptionsBuilder = this.CreateRedisOptionsBuilder();
            string connectionString = "ABC";

            // Act
            var result = redisOptionsBuilder.WithConnectionString(
                connectionString);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void WithInstance_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var redisOptionsBuilder = this.CreateRedisOptionsBuilder();
            string instance = "AAA";

            // Act
            var result = redisOptionsBuilder.WithInstance(
                instance);

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }

        [Fact]
        public void Build_StateUnderTest_ExpectedBehavior()
        {
            // Arrange
            var redisOptionsBuilder = this.CreateRedisOptionsBuilder();

            // Act
            var result = redisOptionsBuilder.Build();

            // Assert
            Assert.NotNull(result);
            this.mockRepository.VerifyAll();
        }
    }
}
