package api;
import com.intuit.karate.Results;
import com.intuit.karate.Runner;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import org.apache.commons.io.FileUtils;
import org.json.simple.*;
//@KarateOptions(tags = {"@testRun2","@testRun3"})
import org.json.simple.parser.JSONParser;



public class FunctionalTestRunner{

    @Test
    void testParallelnew() {
        try {
            JSONParser parser = new JSONParser();
            JSONObject data = (JSONObject) parser.parse(
                  new FileReader("src/test/java/config.json"));//path to the JSON file.
            String branch = data.get("BRANCH").toString();
            System.out.println(data.get("BRANCH"));

            Results results = Runner.path("classpath:api").tags("@Regression").parallel(4);
            assertEquals(0, results.getFailCount(), results.getErrorMessages());
            generateReport(results.getReportDir());
            assertEquals(0, results.getFailCount(), results.getErrorMessages());
      
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        catch (org.json.simple.parser.ParseException e) {
            e.printStackTrace();
        }

}
         public static void generateReport(String karateOutputPath) {        
         Collection<File> jsonFiles = FileUtils.listFiles(new File(karateOutputPath), new String[] {"json"}, true);
         List<String> jsonPaths = new ArrayList<String>(jsonFiles.size());
         jsonFiles.forEach(file -> jsonPaths.add(file.getAbsolutePath()));
         Configuration config = new Configuration(new File("target"), "nbly");
         ReportBuilder reportBuilder = new ReportBuilder(jsonPaths, config);
         reportBuilder.generateReports();        
     }
}