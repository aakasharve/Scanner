function fn() {
  var configData = karate.read("config.json");

  //data required for generating authorization token

  if (configData.BRANCH == 'develop' ) {
      b2cUsername = configData.B2C_USERNAME_DEV,
      b2cPassword = configData.B2C_PASSWORD_DEV,
      b2cGrantType = configData.B2C_GRANT_TYPE,
      b2cTokenUrl = configData.B2C_TOKEN_URL_DEV,
      b2cClientID = configData.B2C_CLIENT_ID_DEV,
      b2cScope = configData.B2C_SCOPE_DEV
  }
  else if (configData.BRANCH == 'aws-migration') {
      b2cUsername = configData.B2C_USERNAME_DEV,
      b2cPassword = configData.B2C_PASSWORD_DEV,
      b2cGrantType = configData.B2C_GRANT_TYPE,
      b2cTokenUrl = configData.B2C_TOKEN_URL_DEV,
      b2cClientID = configData.B2C_CLIENT_ID_DEV,
      b2cScope = configData.B2C_SCOPE_DEV
  }
  else if (configData.BRANCH == 'release') {
    b2cUsername = configData.B2C_USERNAME_RELEASE,
      b2cPassword = configData.B2C_PASSWORD_RELEASE,
      b2cGrantType = configData.B2C_GRANT_TYPE,
      b2cTokenUrl = configData.B2C_TOKEN_URL_RELEASE,
      b2cClientID = configData.B2C_CLIENT_ID_RELEASE,
      b2cScope = configData.B2C_SCOPE_RELEASE
  }

  else {
    b2cUsername = configData.B2C_USERNAME_PROD,
      b2cPassword = configData.B2C_PASSWORD_PROD,
      b2cGrantType = configData.B2C_GRANT_TYPE,
      b2cTokenUrl = configData.B2C_TOKEN_URL_PROD,
      b2cClientID = configData.B2C_CLIENT_ID_PROD,
      b2cScope = configData.B2C_SCOPE_PROD
  }


  var authorizeData = {
    //	cesUsername: configData.B2C_USERNAME,
    //	cesPassword: configData.B2C_PASSWORD,
    //grantType: configData.B2C_GRANT_TYPE,
    // 	tokenUrl: configData.B2C_TOKEN_URL,

    b2cUsername: b2cUsername,
    b2cPassword: b2cPassword,
    b2cGrantType: b2cGrantType,
    b2cTokenUrl: b2cTokenUrl,
    b2cClientID: b2cClientID,
    b2cScope: b2cScope,
  };

  var result = karate.callSingle(
    "classpath:resources/generateToken.feature",
    authorizeData
  );
  var token = "Bearer " + result.token;

  if (configData.BASE_URL == 'https://app.onverity.com/api/') {
    serviceAppointmentUrl = configData.BASE_URL + "Dispatch/v1/api/"
    userUrl = configData.BASE_URL + "productcatalog/v1/api/",
    PutDeclineService = configData.BASE_URL + "workorder/v1/api/WorkOrder/",
    GetMUAssessmentDetails = configData.BASE_URL + "workorder/v1/api/WorkOrder/",
    todoUrl = configData.BASE_URL + "template-service/v1/api/",
    workOrderUrl = configData.BASE_URL + "workorder/v1/api/",
    customerUrl = configData.BASE_URL + "customer/v1/api/Customer",
    productCatalogUrl = configData.BASE_URL + "productcatalog/v1/api/",
    blobServiceIntegration = configData.BASE_URL + "template-service/v1/api/File/"
    auditlogurl = configData.BASE_URL + "audit-logs/v1/api/"
    getuploadedimagesurl = configData.BASE_URL + "filestorage/v1/api/FileStorage/",
    blobServiceIntegration = configData.BASE_URL + "template-service/v1/api/File/"
  }
  else {
    serviceAppointmentUrl = configData.BASE_URL + "Dispatch/" + configData.BRANCH + "/v1/api/"
    userUrl = configData.BASE_URL + "productcatalog/" + configData.BRANCH + "/v1/api/",
    PutDeclineService = configData.BASE_URL + "workorder/" + configData.BRANCH + "/v1/api/WorkOrder/",
    GetMUAssessmentDetails = configData.BASE_URL + "workorder/" + configData.BRANCH + "/v1/api/WorkOrder/",
    todoUrl = configData.BASE_URL + "template-service/" + configData.BRANCH + "/v1/api/",
    workOrderUrl = configData.BASE_URL + "workorder/" + configData.BRANCH + "/v1/api/",
    customerUrl = configData.BASE_URL + "customer/" + configData.BRANCH + "/v1/api/Customer",
    productCatalogUrl = configData.BASE_URL + "productcatalog/" + configData.BRANCH + "/v1/api/",
    blobServiceIntegration = configData.BASE_URL + "template-service/" + configData.BRANCH + "/v1/api/File/",
    auditlogurl = configData.BASE_URL + "audit-logs/" + configData.BRANCH + "/v1/api/"
    getuploadedimagesurl = configData.BASE_URL + "filestorage/" + configData.BRANCH + "/v1/api/FileStorage/",
    blobServiceIntegration = configData.BASE_URL + "template-service/" + configData.BRANCH + "/v1/api/File/"
  }

  if (configData.BRANCH == '') {
    context = '{"CmId":"33828f96-9115-419f-8dee-30bdd4eb5c3e","BuId":"2cd51ec2-35b1-416e-bf78-97585aa6459f","BgId":"977bc361-4dff-4b3e-80e2-4c8b4e339872","LoBId":"","CoId":"24","EnId":"6b47ba2b-a553-4328-9c87-bbbd62a7037d"}'
  }
  else if (configData.BRANCH == 'develop') {
    context = '{"CmId":"a267e2c9-a2ca-409e-aacc-da0038335e12","BuId":"603567f8-6427-41c8-b6f9-bde28fbb650f","BgId":"970170ef-d9d0-44bb-834c-33fdefa18a62","LoBId":"","CoId":"24","EnId":"6b47ba2b-a553-4328-9c87-bbbd62a7037d","cleanCache":false}'
  }
  else if (configData.BRANCH == 'release') {
    context = '{"CmId":"35132c9e-ed75-4d9b-8809-21b29be6b680","BuId":"5b142a13-d30f-45b3-8c08-abe0c2cb1c5a","BgId":"c1871318-7623-48d1-8259-f082f15521c9","LoBId":"","CoId":"24","EnId":"6b47ba2b-a553-4328-9c87-bbbd62a7037d","cleanCache":true}'
  }
  else {
    context = '{"CmId":"8b1de6a5-4a8b-4563-9cb7-d49b5f7ce51c","BuId":"7cf8f95c-710e-4b8b-b8c8-baaf0e18ff62","BgId":"39f8ed20-7ea1-492a-ae0b-836f9c532b1e","LoBId":"","CoId":"24","EnId":"6b47ba2b-a553-4328-9c87-bbbd62a7037d","cleanCache":true}'
  }


  var config = {
    swaggerUrl: configData.SWAGGER_URL,
    b2cTokenUrl: configData.B2C_TOKEN_URL,
    tokenUrl: configData.B2C_TOKEN_URL,

    userUrl: userUrl,
    PutDeclineService: PutDeclineService,
    GetMUAssessmentDetails: GetMUAssessmentDetails,
    todoUrl: todoUrl,
    workOrderUrl: workOrderUrl,
    customerUrl: customerUrl,
    serviceAppointmentUrl: serviceAppointmentUrl,
    productCatalogUrl: productCatalogUrl,
    blobServiceIntegration: blobServiceIntegration,
    auditlogurl: auditlogurl,
    getuploadedimagesurl: getuploadedimagesurl,
    blobServiceIntegration: blobServiceIntegration,

    validAuthorizationHeader: {
      Authorization: token,
      "Content-Type": "application/json",
      "x-usertimezone": "America/Winnipeg",
      "x-offset": "6",
      "user-culture-code": "en-US",
      "x-fsm-context": context

    },
    invalidAuthorizationHeader: {
      Authorization: "123456",
      "Content-Type": "application/json",
      "x-usertimezone": "America/Winnipeg",
      "x-offset": "6",
      "x-fsm-context": context,
      "user-culture-code": "en-US",
    },
    fileuploadAuthorizationHeader: {
      Authorization: token,
    },
    invalidfileuploadAuthorizationHeader: {
      Authorization: 23000,
      "Content-Type": "multipart/form-data",
      "x-usertimezone": "America/Winnipeg",
      "x-offset": "6",
      "x-fsm-context": context,
      "user-culture-code": "en-US",
    },
    validAuthorizationHeaderNew: {
      Authorization: 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6IkUtWnl6eC11VzNXdkJwejlfb2ZuWE40bzVqZkRyd1VnSExzcVdYdjljd0EifQ.eyJpc3MiOiJodHRwczovL2ZzbWRldi5iMmNsb2dpbi5jb20vZDIzOTJjNDAtMzZkOC00ODIxLTkxNmYtOTI1ZWZlMDdkMjY2L3YyLjAvIiwiZXhwIjoxNjI4MDU4NDcxLCJuYmYiOjE2MjgwNTQ4NzEsImF1ZCI6ImRmNzMyNDQ1LTE0MWItNDFiMy04MDA0LTdmMjQyNTNlYmVhYSIsInN1YiI6IjVkYjc3MDIwLTQxMGYtNGI3YS05ZGMyLTRlNTMwNDAwNzU4YyIsIm9pZCI6IjVkYjc3MDIwLTQxMGYtNGI3YS05ZGMyLTRlNTMwNDAwNzU4YyIsInVzZXJJZCI6InByYWNoaS5uZXJrYXJAaW5mb2dhaW4uY29tIiwibmFtZSI6IlByYWNoaSBOZXJrYXIiLCJjb21wYW55IjoiTkJMWSIsInJvbGVzIjpbIk5BRE4iLCJTUlBSIl0sImNvaWRzIjpbIjI0Il0sImZyaWRzIjpbIjQ3MjU2Il0sImJ1aWRzIjpbIjExMTQwIl0sImN0aWRzIjpbIjc0NzQiXSwidGlkIjoiZDIzOTJjNDAtMzZkOC00ODIxLTkxNmYtOTI1ZWZlMDdkMjY2IiwiaXNGb3Jnb3RQYXNzd29yZCI6ZmFsc2UsIm5vbmNlIjoiN2U2OWQyNDUtN2VmZC00YWJjLWEyNmEtMTQ2MjA5ZGNjZDQ1Iiwic2NwIjoiRmlsZXMuUmVhZCIsImF6cCI6ImRmNzMyNDQ1LTE0MWItNDFiMy04MDA0LTdmMjQyNTNlYmVhYSIsInZlciI6IjEuMCIsImlhdCI6MTYyODA1NDg3MX0.UIRvHdTwUzTMGyc4gsL0xGvDcPwTvLvG94XZS2298keHiO_cGYwjjqefYUu_dl8MXO8MMFRjM3Z8ezqefzpMr6-bkOZqUPK5TugCLD3h1dv7e0yAnNViA1VZmvtXsOgHoJtwLFKjA-xqed_PrfyWzBbeA06xO8-aM0tFLBCESVzRhLSjYNZeI560IH-lMcoRgYYPnpnm0plV47ZfPOzqyuEyOm0urVdYiMUicwWxPSsPJUDMBDuSaDtN4ANdGTIefswZOjbgZL4t9PaEK4QEpy2xpNCzdrJBStOBI4vhGpbgUdPaKzo864w_gTutd0CQo1ph5Hhm13UX4p1maTOeTQ',
    },
    validAuthorizationHeaderWithAPIKey: { Authorization: 'api-key fbd81ae5-57f6-4796-bc9f-e9a64257dcad', 'Content-Type': 'application/json' },
  };

  karate.configure("connectTimeout", 50000);
  karate.configure("readTimeout", 50000);

  //returns all the config values, this values can be directly accessed by all the scenarios in the feature files
  return config;
}
