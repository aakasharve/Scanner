package utilities;

import net.minidev.json.JSONObject;
import com.github.javafaker.Faker;

import java.util.UUID;

public class DataUtils {

    public static String getRandomEmail() {
        Faker faker = new Faker();
        String email = faker.name().firstName().toLowerCase() + faker.random().nextInt(0, 100) + "@test.com";
        return email;
    }

    public static String getRandomUsername() {
        Faker faker = new Faker();
        String username = faker.name().username();
        return username;
    }

    public static String getCountry() {
        Faker faker = new Faker();
        String country = faker.country().name();
        return country;
    }

    public static JSONObject getRandomArticleValues() {
        Faker faker = new Faker();
        String title = faker.gameOfThrones().character();
        String description = faker.gameOfThrones().city();
        String body = faker.gameOfThrones().quote();
        JSONObject json = new JSONObject();
        json.put("title", title);
        json.put("description", description);
        json.put("body", body);
        return json;
    }

    public static String getAlphaNumericString(int n) {

        // chose a Character random from this String
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        // create StringBuffer size of AlphaNumericString
        StringBuilder sb = new StringBuilder(n);

        for (int i = 0; i < n; i++) {

            // generate a random number between
            // 0 to AlphaNumericString variable length
            int index = (int) (AlphaNumericString.length() * Math.random());

            // add Character one by one in end of sb
            sb.append(AlphaNumericString.charAt(index));
        }

        return sb.toString();
    }

    public static String getRandomBuildingNumber() {
        Faker faker = new Faker();
        String buildingNumber = faker.address().buildingNumber();
        return buildingNumber;
    }

    public static String getRandomMobileNumber() {
        long number = (long) Math.floor(Math.random() * 9_000_000_000L) + 1_000_000_000L;
        String phoneNumber = String.valueOf(number);
        return phoneNumber;
    }

    public static String getFirstName() {
        Faker faker = new Faker();
        String FirstName = faker.name().firstName();
        return FirstName;
    }

    public static String getLastName() {
        Faker faker = new Faker();
        String LastName = faker.name().lastName();
        return LastName;
    }

    public static String getFullName() {
        Faker faker = new Faker();
        String FullName = faker.name().fullName();
        return FullName;
    }

    public static String randomGUID() {
        return UUID.randomUUID().toString();
    }
}
