package performance

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class GetServiceAppointmentScheduleSimulation extends Simulation {
  val protocol = karateProtocol(
    "/public/ping" -> Nil
  )

  protocol.nameResolver = (req, ctx) => req.getHeader("karate-name");

  val GetServiceAppointmentSchedule = scenario("Get Service Appointment Schedule").exec(karateFeature("classpath:api/dispatch/feature/GetServiceAppointmentSchedule.feature"));


  setUp(
    GetServiceAppointmentSchedule.inject(constantUsersPerSec(1) during (1 seconds)).protocols(protocol)
    // GetServiceAppointmentSchedule.inject(constantUsersPerSec(1) during(1 minutes)).protocols(protocol)
  )
}
