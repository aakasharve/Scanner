package performance

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class GetAppointmentDataByTechnIdSimulation extends Simulation {
  val protocol = karateProtocol(
    "/public/ping" -> Nil
  )

  protocol.nameResolver = (req, ctx) => req.getHeader("karate-name");

  val GetAppointmentDataByTechnId = scenario("GetAppointmentDataByTechnId").exec(karateFeature("classpath:api/dispatch/feature/GetAppointmentDataByTechnId.feature"));


  setUp(
    GetAppointmentDataByTechnId.inject(constantUsersPerSec(1) during (1 seconds)).protocols(protocol)
    // GetAppointmentDataByTechnId.inject(constantUsersPerSec(1) during(1 minutes)).protocols(protocol)
  )
}
