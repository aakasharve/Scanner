package performance

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class GetAppointmentTypesSimulation extends Simulation {
  val protocol = karateProtocol(
    "/public/ping" -> Nil
  )

  protocol.nameResolver = (req, ctx) => req.getHeader("karate-name");

  val GetAppointmentTypes = scenario("AppointmentTypes").exec(karateFeature("classpath:api/dispatch/feature/GetAppointmentTypes.feature"));


  setUp(
    GetAppointmentTypes.inject(constantUsersPerSec(1) during (1 seconds)).protocols(protocol)
    // GetAppointmentTypes.inject(constantUsersPerSec(1) during(1 minutes)).protocols(protocol)
  )
}
