package performance

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class GetUserServiceAppointmentsSimulation extends Simulation {
  val protocol = karateProtocol(
    "/public/ping" -> Nil
  )

  protocol.nameResolver = (req, ctx) => req.getHeader("karate-name");

  val GetUserServiceAppointments = scenario("GetUserServiceAppointments").exec(karateFeature("classpath:api/dispatch/feature/GetUserServiceAppointments.feature"));


  setUp(
    GetUserServiceAppointments.inject(constantUsersPerSec(1) during (1 seconds)).protocols(protocol)
    // GetUserServiceAppointments.inject(constantUsersPerSec(1) during(1 minutes)).protocols(protocol)
  )
}
