package performance

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class PostGetAvailableSlotSimulation extends Simulation {
  val protocol = karateProtocol(
    "/public/ping" -> Nil
  )

  protocol.nameResolver = (req, ctx) => req.getHeader("karate-name");

  val PostGetAvailableSlot = scenario("PostGetAvailableSlot").exec(karateFeature("classpath:api/dispatch/feature/PostGetAvailableSlot.feature"));


  setUp(
    PostGetAvailableSlot.inject(constantUsersPerSec(1) during (1 seconds)).protocols(protocol)
    // PostGetAvailableSlot.inject(constantUsersPerSec(1) during(1 minutes)).protocols(protocol)
  )
}
