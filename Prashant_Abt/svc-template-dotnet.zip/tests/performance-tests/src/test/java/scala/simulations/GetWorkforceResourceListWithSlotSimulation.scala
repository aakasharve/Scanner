package performance

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class GetWorkforceResourceListWithSlotSimulation extends Simulation {
  val protocol = karateProtocol(
    "/public/ping" -> Nil
  )

  protocol.nameResolver = (req, ctx) => req.getHeader("karate-name");

  val GetWorkforceResourceListWithSlot = scenario("Get Workforce Resource ist With Slot").exec(karateFeature("classpath:api/dispatch/feature/GetWorkforceResourceListWithSlot.feature"));


  setUp(
    GetWorkforceResourceListWithSlot.inject(constantUsersPerSec(1) during (1 seconds)).protocols(protocol)
    // GetWorkforceResourceListWithSlot.inject(constantUsersPerSec(1) during(1 minutes)).protocols(protocol)
  )
}
