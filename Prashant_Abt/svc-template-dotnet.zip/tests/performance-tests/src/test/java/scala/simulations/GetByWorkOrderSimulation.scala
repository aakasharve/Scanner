package performance

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class GetByWorkOrderSimulation extends Simulation {
  val protocol = karateProtocol(
    "/public/ping" -> Nil
  )

  protocol.nameResolver = (req, ctx) => req.getHeader("karate-name");

  val GetByWorkOrder = scenario("GetByWorkOrder").exec(karateFeature("classpath:api/dispatch/feature/GetByWorkOrder.feature"));


  setUp(
    GetByWorkOrder.inject(constantUsersPerSec(1) during (1 seconds)).protocols(protocol)
    // GetByWorkOrder.inject(constantUsersPerSec(1) during(1 minutes)).protocols(protocol)
  )
}
