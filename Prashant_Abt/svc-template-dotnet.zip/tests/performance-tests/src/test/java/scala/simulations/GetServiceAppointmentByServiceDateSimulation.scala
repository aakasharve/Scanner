package performance

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class GetServiceAppointmentByServiceDateSimulation extends Simulation {
  val protocol = karateProtocol(
    "/public/ping" -> Nil
  )

  protocol.nameResolver = (req, ctx) => req.getHeader("karate-name");

  val GetServiceAppointmentByServiceDate = scenario("Get Service Appointment By ServiceDate").exec(karateFeature("classpath:api/dispatch/feature/GetServiceAppointmentByServiceDate.feature"));


  setUp(
    GetServiceAppointmentByServiceDate.inject(constantUsersPerSec(1) during (1 seconds)).protocols(protocol)
    // GetServiceAppointmentByServiceDate.inject(constantUsersPerSec(1) during(1 minutes)).protocols(protocol)
  )
}
