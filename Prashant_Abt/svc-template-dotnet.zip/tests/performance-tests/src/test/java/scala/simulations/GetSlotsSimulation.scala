package performance

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class GetSlotsSimulation extends Simulation {
  val protocol = karateProtocol(
    "/public/ping" -> Nil
  )

  protocol.nameResolver = (req, ctx) => req.getHeader("karate-name");

  val GetSlots = scenario("Get Slots").exec(karateFeature("classpath:api/dispatch/feature/GetSlots.feature"));


  setUp(
    GetSlots.inject(constantUsersPerSec(1) during (1 seconds)).protocols(protocol)
    // GetSlots.inject(constantUsersPerSec(1) during(1 minutes)).protocols(protocol)
  )
}
