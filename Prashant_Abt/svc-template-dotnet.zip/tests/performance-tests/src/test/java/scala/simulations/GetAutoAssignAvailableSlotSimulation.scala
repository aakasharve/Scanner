package performance

import com.intuit.karate.gatling.PreDef._
import io.gatling.core.Predef._
import scala.concurrent.duration._

class GetAutoAssignAvailableSlotSimulation extends Simulation {
  val protocol = karateProtocol(
    "/public/ping" -> Nil
  )

  protocol.nameResolver = (req, ctx) => req.getHeader("karate-name");

  val GetAutoAssignAvailableSlot = scenario("GetAutoAssignAvailableSlot").exec(karateFeature("classpath:api/dispatch/feature/GetAutoAssignAvailableSlot.feature"));


  setUp(
    GetAutoAssignAvailableSlot.inject(constantUsersPerSec(1) during (1 seconds)).protocols(protocol)
    // GetAutoAssignAvailableSlot.inject(constantUsersPerSec(1) during(1 minutes)).protocols(protocol)
  )
}
