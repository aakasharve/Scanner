function fn() {
  var configData = karate.read("config.json");

  //data required for generating authorization token
  var authorizeData = {
    //	cesUsername: configData.B2C_USERNAME,
    //	cesPassword: configData.B2C_PASSWORD,
    //grantType: configData.B2C_GRANT_TYPE,
    // 	tokenUrl: configData.B2C_TOKEN_URL,

    b2cUsername: configData.B2C_USERNAME,
    b2cPassword: configData.B2C_PASSWORD,
    b2cGrantType: configData.B2C_GRANT_TYPE,
    b2cTokenUrl: configData.B2C_TOKEN_URL,
    b2cClientID: configData.B2C_CLIENT_ID,
    b2cClientSecret: configData.B2C_CLIENT_SECRET,
    b2cScope: configData.B2C_SCOPE,
  };

  var result = karate.callSingle(
    "classpath:resources/generateToken.feature",
    authorizeData
  );
  var token = "Bearer " + result.token;

  var config = {
    swaggerUrl: configData.SWAGGER_URL,
    b2cTokenUrl: configData.B2C_TOKEN_URL,
    tokenUrl: configData.B2C_TOKEN_URL,
    
    todoUrl: configData.BASE_URL + "template-service/" + configData.BRANCH + "/v1/api/",
    workOrderUrl: configData.BASE_URL + "workorder/" + configData.BRANCH + "/v1/api/WorkOrder/",
    customerurl: configData.BASE_URL + "workorder/" + configData.BRANCH + "/v1/api/Customer/",
    serviceAppointmentUrl: configData.BASE_URL + "Dispatch/" + configData.BRANCH + "/v1/api/ServiceAppointment/",
    productCatalogUrl: configData.BASE_URL + "productcatalog/" + configData.BRANCH + "/v1/api/",
    blobServiceIntegration: configData.BASE_URL + "template-service/" + configData.BRANCH + "/v1/api/File/",
    userUrl: configData.BASE_URL + "productcatalog/" + configData.BRANCH + "/v1/api/",
    PutDeclineService: configData.BASE_URL + "workorder/" + configData.BRANCH + "/v1/api/WorkOrder/",
    GetMUAssessmentDetails: configData.BASE_URL + "workorder/" + configData.BRANCH + "/v1/api/WorkOrder/",

    validAuthorizationHeader: {
      Authorization: token,
      "Content-Type": "application/json",
    },
    invalidAuthorizationHeader: {
      Authorization: "123456",
      "Content-Type": "application/json",
    },
    fileuploadAuthorizationHeader: {
      Authorization: token,
      "Content-Type": "multipart/form-data",
    },
    invalidfileuploadAuthorizationHeader: {
      Authorization: 23000,
      "Content-Type": "multipart/form-data",
    },
  };

  karate.configure("connectTimeout", 50000);
  karate.configure("readTimeout", 50000);

  //returns all the config values, this values can be directly accessed by all the scenarios in the feature files
  return config;
}
