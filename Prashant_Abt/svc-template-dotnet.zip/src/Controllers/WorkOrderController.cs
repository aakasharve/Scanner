﻿using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Neighborly.Chassis.Auth;
using Neighborly.Chassis.Formatter;
using Neighborly.Chassis.Mediator;
using Neighborly.Model.WorkOrder.Models.Request;
using Neighborly.Service.WorkOrder.Commands;
using Neighborly.Service.WorkOrder.Queries;
using Serilog;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Neighborly.Controllers
{
    /// <summary>
    /// WorkOrder Controller
    /// </summary>
    [ExcludeFromCodeCoverage]
    [Route("api/[controller]")]
    [ApiController]
    public class WorkOrderController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        protected readonly ILogger logger;
        private readonly IMapper mapper;
        /// <summary>
        /// The mediator
        /// </summary>
        protected readonly IMediator mediator;
        /// <summary>
        /// Creates the specified model.
        /// </summary>
        /// <param name="model">The model.</param>
        /// <param name="ct">The ct.</param>
        /// <returns>IActionResult.</returns>
        /// 
        #region Constructor
        /// <summary>
        /// Initializes a new instance of the <see cref="WorkOrderController"/> class.
        /// </summary>
        /// <param name="mediator">The mediator.</param>
        /// <param name="logger">The logger.</param>
        public WorkOrderController(IMediator mediator
            , ILogger logger
            , IMapper mapper     
            , IUserClaimsProvider userClaimsProvider      
            )

        {
            this.logger = logger;
            this.mapper = mapper;
            this.mediator = mediator;

        }
        #endregion

        /// <summary>
        /// Create work order
        /// </summary>
        /// <param name="model"></param>
        /// <param name="ct"></param>
        /// <returns></returns>
        [HttpPost]
        public async Task<CustomApiResponse> Create([FromBody] WorkOrderCreateRequest model, CancellationToken ct)
        {       
            var result = await mediator.SendAsync(new CreateWorkOrderCommand("name")
            {
                CustomerId = model.CustomerId,
                CustomerName = model.CustomerName,
                CustomerIsTaxable = model.CustomerIsTaxable,
                Email = model.Email,
                Phone = model.Phone,
                WorkOrderNumber = model.WorkOrderNumber

            }, ct);

            return new CustomApiResponse(false, 201, "Post Request Successful", result);
        }

        /// <summary>
        /// Get all work orders
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="pageSize"></param>
        /// <param name="pageNumber"></param>
        /// <returns></returns>
        [HttpGet]
        [ApiConventionMethod(typeof(DefaultApiConventions), nameof(DefaultApiConventions.Get))]
        public async Task<CustomApiResponse> GetAll(CancellationToken ct, int pageSize = 20, int pageNumber = 1)
        {
            var result = await mediator.FetchAsync(new GetAllQuery("User")
            {
                pageSize = pageSize,
                pageNo = pageNumber
                
            }, ct);

            return new CustomApiResponse(false, 200, "Get Request Successful", result);
        }

        /// <summary>
        /// Get work order by id
        /// </summary>
        /// <param name="ct"></param>
        /// <param name="pageSize"></param>
        /// <param name="pageNumber"></param>
        /// <returns></returns>
        [HttpGet]
        [Route("{id:guid}")]
        [ApiConventionMethod(typeof(DefaultApiConventions), nameof(DefaultApiConventions.Get))]
        public async Task<CustomApiResponse> Get(CancellationToken ct, [FromRoute] Guid id)
        {
            var result = await mediator.FetchAsync(new GetByIdQuery("User")
            {
                Id = id
            }, ct);

            return new CustomApiResponse(false, 200, "Get Request Successful", result);
        }
    }
}
