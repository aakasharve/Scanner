﻿using Amazon.S3;
using Amazon.S3.Model;

using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.Cosmos.Core;
using Microsoft.Extensions.Hosting;
using Neighborly.Chassis.AWSHelper;
using Polly;
using System;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Net.Http;
using System.Threading.Tasks;
using System.Drawing;
using static System.Net.Mime.MediaTypeNames;
using System.Security.Policy;
using System.Web;
using System.Net;

namespace Neighborly.Controllers
{
    /// <summary>
    /// 
    /// </summary>
    [Route("api/[controller]")]
    [ApiVersion("1")]
    [ApiVersion("2")]
    [ApiController]
    [ExcludeFromCodeCoverage]
    public class VersioningController : ControllerBase
    {
        private readonly IAWSS3BucketHelper iAWSS3BucketHelper;
        private readonly IHttpContextAccessor contextAccessor;
        private IHostingEnvironment _env;
        /// <summary>
        /// 
        /// </summary>
        /// <param name="iAWSS3BucketHelper"></param>
        public VersioningController(IAWSS3BucketHelper iAWSS3BucketHelper, IHttpContextAccessor contextAccessor, IHostingEnvironment env)
        {
            this.iAWSS3BucketHelper = iAWSS3BucketHelper;
            this.contextAccessor = contextAccessor;
            this._env = env;
    }

        #region Web Method
        /// <summary>
        /// Version 1 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetVersion")]
        [MapToApiVersion("1")]
        public string GetV1()
        {
            return "V1";
        }

        /// <summary>
        /// Version 2 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("GetVersion")]
        [MapToApiVersion("2")]
        public string GetV2()
        {
            return "V2";
        }

        /// <summary>
        /// Version 2 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("public/longrun/{s}")]
        [MapToApiVersion("1")]
        [MapToApiVersion("2")]
        public string LongRun(int s)
        {
            System.Threading.Thread.Sleep(s);
            return "V2";
        }

        [HttpGet]
        [Route("public/GetFile")]
        public IActionResult GetFile()
        {
            var filepath = System.IO.Path.Combine(_env.ContentRootPath, "Contents/corgi-small.jpg");

            var image = System.IO.File.OpenRead(filepath);
            return File(image, "image/jpeg");
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        [Route("public/GetImageStream/{objectKey}")]
        [ApiVersion("1")]
        [ApiVersion("2")]
        [ResponseCache(CacheProfileName = "CacheProfile")]
        public async Task<IActionResult> GetImageStreamAsync(string objectKey)
        {
            try
            {
                var decodedOjectKey = HttpUtility.UrlDecode(objectKey);
                var obj1 = await iAWSS3BucketHelper.GetFile(decodedOjectKey);
              
                return File(obj1.ResponseStream, "image/png");               

            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);               
            }
                  
        }

        #endregion
    }



    
}
