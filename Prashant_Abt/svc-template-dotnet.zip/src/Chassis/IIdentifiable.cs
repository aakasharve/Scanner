﻿namespace Neighborly.Chassis
{
    /// <summary>
    /// Interface IIdentifiable
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public interface IIdentifiable<out T>
    {
        /// <summary>
        /// Gets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        T Id { get; }
    }
}