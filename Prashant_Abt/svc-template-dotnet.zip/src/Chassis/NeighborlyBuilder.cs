﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;

namespace Neighborly.Chassis
{
    /// <summary>
    /// Class NeighborlyBuilder. This class cannot be inherited.
    /// Implements the <see cref="INeighborlyBuilder" />
    /// </summary>
    /// <seealso cref="INeighborlyBuilder" />
    public sealed class NeighborlyBuilder : INeighborlyBuilder
    {
        /// <summary>
        /// The registry
        /// </summary>
        private readonly ConcurrentDictionary<string, bool> registry = new ConcurrentDictionary<string, bool>();
        /// <summary>
        /// The build actions
        /// </summary>
        private readonly List<Action<IServiceProvider>> buildActions;
        /// <summary>
        /// The services
        /// </summary>
        private readonly IServiceCollection services;
        /// <summary>
        /// Gets the services.
        /// </summary>
        /// <value>The services.</value>
        IServiceCollection INeighborlyBuilder.Services => services;

        /// <summary>
        /// Initializes a new instance of the <see cref="NeighborlyBuilder" /> class.
        /// </summary>
        /// <param name="services">The services.</param>
        private NeighborlyBuilder(IServiceCollection services)
        {
            buildActions = new List<Action<IServiceProvider>>();
            this.services = services;
            this.services.AddSingleton<IStartupInitializer>(new StartupInitializer());
        }

        /// <summary>
        /// Creates the specified services.
        /// </summary>
        /// <param name="services">The services.</param>
        /// <returns>INeighborlyBuilder.</returns>
        public static INeighborlyBuilder Create(IServiceCollection services)
            => new NeighborlyBuilder(services);

        /// <summary>
        /// Tries the register.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public bool TryRegister(string name) => registry.TryAdd(name, true);

        /// <summary>
        /// Adds the build action.
        /// </summary>
        /// <param name="execute">The execute.</param>
        public void AddBuildAction(Action<IServiceProvider> execute)
            => buildActions.Add(execute);

        /// <summary>
        /// Adds the initializer.
        /// </summary>
        /// <param name="initializer">The initializer.</param>
        public void AddInitializer(IInitializer initializer)
            => AddBuildAction(sp =>
            {
                var startupInitializer = sp.GetService<IStartupInitializer>();
                startupInitializer?.AddInitializer(initializer);
            });

        /// <summary>
        /// Adds the initializer.
        /// </summary>
        /// <typeparam name="TInitializer">The type of the t initializer.</typeparam>
        public void AddInitializer<TInitializer>() where TInitializer : IInitializer
            => AddBuildAction(sp =>
            {
                var initializer = sp.GetService<TInitializer>();
                var startupInitializer = sp.GetService<IStartupInitializer>();
                startupInitializer?.AddInitializer(initializer);
            });

        /// <summary>
        /// Builds this instance.
        /// </summary>
        /// <returns>IServiceProvider.</returns>
        public IServiceProvider Build()
        {
            var serviceProvider = services.BuildServiceProvider();
            buildActions.ForEach(a => a(serviceProvider));
            return serviceProvider;
        }
    }
}