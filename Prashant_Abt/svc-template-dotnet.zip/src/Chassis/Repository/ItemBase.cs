﻿using Newtonsoft.Json;
using System;

namespace Neighborly.Chassis.Repository
{
    /// <summary>
    /// Class ItemBase.
    /// </summary>
    public abstract class ItemBase
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ItemBase" /> class.
        /// </summary>
        protected ItemBase()
        {           
        }
        
        /// <summary>
        /// Gets or sets the Id 
        /// </summary>
        /// <value>The Id associated with the resource.</value>
        [JsonProperty(PropertyName = "id")]
        public Guid Id { get; set; }

    }
}