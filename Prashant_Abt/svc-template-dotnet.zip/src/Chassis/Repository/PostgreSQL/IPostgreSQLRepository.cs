﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Repository.PostgreSQL
{
    /// <summary>
    /// PostgreSQL Repository Interface
    /// </summary>
    /// <typeparam name="TItem"></typeparam>
    public interface IPostgreSqlRepository<TItem> where TItem : ItemBase
    {
        /// <summary>
        /// GetByIdAsync
        /// </summary>
        /// <param name="id"></param>
        /// <param name="includes"></param>
        /// <returns></returns>
        Task<TItem> GetByIdAsync(Guid id, string[]? includes = null);
        /// <summary>
        /// GetAllAsync
        /// </summary>
        /// <param name="pageSize"></param>
        /// <param name="pageNo"></param>
        /// <param name="filterOptions"></param>
        /// <param name="orderBy"></param>
        /// <param name="includes"></param>
        /// <returns></returns>
        Task<IEnumerable<TItem>> GetAllAsync(int pageSize,
            int pageNo,
            Expression<Func<TItem, bool>>? filterOptions,
            Func<IQueryable<TItem>, IOrderedQueryable<TItem>>? orderBy,
            string[]? includes = null);
        /// <summary>
        /// Add Async
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        Task<TItem> AddAsync(TItem item);
        /// <summary>
        /// Delete Async
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        Task DeleteAsync(string id);
        /// <summary>
        /// Update Async
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        Task<TItem> UpdateAsync(TItem item);
        /// <summary>
        /// add or update as an asynchronous operation.
        /// </summary>
        /// <param name="entity">The entity.</param>
        /// <returns>Task&lt;TDocument&gt;.</returns>
        Task<TItem> AddOrUpdateAsync(TItem entity);

    }
}
