﻿using System.ComponentModel.DataAnnotations.Schema;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Chassis.Repository.PostgreSQL
{
    /// <summary>
    /// PostgreSQLJsonbEntity
    /// </summary>
    /// <typeparam name="TItem"></typeparam>
    [ExcludeFromCodeCoverage]
    public class PostgreSqlJsonbEntity<TItem> where TItem : ItemBase
    {
        /// <summary>
        /// Id
        /// </summary>
        public string Id { get; set; } = null!;
        /// <summary>
        /// Entity
        /// </summary>
        [Column(TypeName = "jsonb")]
        public TItem? Entity { get; set; }
    }
}
