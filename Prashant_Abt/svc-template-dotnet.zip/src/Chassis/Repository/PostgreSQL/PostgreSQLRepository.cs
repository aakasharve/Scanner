﻿using Microsoft.EntityFrameworkCore;
using Neighborly.Chassis.Formatter;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Repository.PostgreSQL
{
    /// <summary>
    /// PostgreSQL Repository
    /// </summary>
    /// <typeparam name="TItem"></typeparam>
    [ExcludeFromCodeCoverage]
    public abstract class PostgreSqlRepository<TItem> : IPostgreSqlRepository<TItem> where TItem : ItemBase
    {
        #region Private Member 

        private readonly PostgreSqlDataContext _dataContext;
        private readonly DbSet<TItem> _entities;

        #endregion

        #region Constructor

        /// <summary>
        /// PostgreSQLRepository Constructor
        /// </summary>
        /// <param name="dataContext"></param>
        protected PostgreSqlRepository(PostgreSqlDataContext dataContext)
        {
            this._dataContext = dataContext;
            _entities = _dataContext.Set<TItem>();
        }

        #endregion



        /// <summary>
        /// Add Async
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public async Task<TItem> AddAsync(TItem item)
        {
            try
            {
                await _entities.AddAsync(item);
                await _dataContext.SaveChangesAsync();
                return item;
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        /// <summary>
        /// Delete Async
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        public async Task DeleteAsync(string id)
        {
            var itemToRemove = await _entities.FindAsync(id);
            if (itemToRemove == null)
                throw new NullReferenceException();

            _entities.Remove(itemToRemove);
            await _dataContext.SaveChangesAsync();
        }
        /// <summary>
        /// GetAllAsync
        /// </summary>
        /// <param name="pageSize"></param>
        /// <param name="pageNo"></param>
        /// <param name="filterOptions"></param>
        /// <param name="orderBy"></param>
        /// <param name="includes"></param>
        /// <returns></returns>
        public async Task<IEnumerable<TItem>> GetAllAsync(int pageSize,
            int pageNo,
            Expression<Func<TItem, bool>> filterOptions,
            Func<IQueryable<TItem>,
            IOrderedQueryable<TItem>> orderBy,
            string[]? includes = null)
        {

            var itemsQuery = _entities.AsQueryable();
            if (includes != null)
            {
                foreach (var include in includes)
                {
                    itemsQuery = itemsQuery.Include(include);
                }
            }
            if (filterOptions != null)
            {
                itemsQuery = itemsQuery.Where(filterOptions);
            }

            if (orderBy != null)
                itemsQuery = orderBy(itemsQuery);

            itemsQuery = itemsQuery.Skip((pageNo - 1) * pageSize).Take(pageSize);

            return await itemsQuery.ToListAsync();
        }

        /// <summary>
        /// Get Total filtered Count Async
        /// </summary>
        /// <param name="filterOptions"></param>
        /// <returns></returns>
        public async Task<int> GetTotalCountAsync(Expression<Func<TItem, bool>> filterOptions)
        {

            var query = _entities.AsQueryable();
            if (filterOptions != null)
            {
                query = query.Where(filterOptions);
            }

            int total = await query.CountAsync();

            return total;
        }


        /// <summary>
        /// Get By Id Async
        /// </summary>
        /// <param name="id"></param>
        /// <param name="includes"></param>
        /// <returns></returns>
        public async Task<TItem> GetByIdAsync(Guid id, string[]? includes = null)
        {
            var query = _entities.AsQueryable();
            if (includes != null)
            {
                foreach (var include in includes)
                {
                    query = query.Include(include);
                }
            }
            return await query.FirstOrDefaultAsync(s => s.Id == id);
        }

        /// <summary>
        /// Update Async
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public async Task<TItem> UpdateAsync(TItem item)
        {
            try
            {
                _entities.Update(item);
                await _dataContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new ApiException("Template AddOrUpdteAsync error", 404, ex);
            }
            return item;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="entity"></param>
        /// <returns></returns>
        public async Task<TItem> AddOrUpdateAsync(TItem entity)
        {
            var itemToUpdate = await _entities.FindAsync(entity.Id);
            try
            {
                if (itemToUpdate == null)
                    await _entities.AddAsync(entity);
                itemToUpdate = entity;
                await _dataContext.SaveChangesAsync();
            }
            catch (Exception ex)
            {
                throw new ApiException("Template AddOrUpdteAsync error", 404, ex);
            }
            return itemToUpdate;
        }

    }
}
