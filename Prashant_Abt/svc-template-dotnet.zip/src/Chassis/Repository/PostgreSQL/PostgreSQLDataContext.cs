﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Neighborly.Chassis.AuditLog;
using Neighborly.Chassis.Auth;
using Neighborly.Chassis.Helper;
using Neighborly.Chassis.Mediator;
using Neighborly.Service.BaseEntity;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using static Neighborly.Service.Enums;

namespace Neighborly.Chassis.Repository.PostgreSQL
{
    /// <summary>
    /// PostgreSqlDataContext
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class PostgreSqlDataContext : DbContext
    {/// <summary>
     /// userClaimsProvider
     /// </summary>
        private readonly IUserClaimsProvider userClaimsProvider;
        private readonly IMediator mediator;
        /// <summary>
        /// PostgreSqlDataContext
        /// </summary>
        /// <param name="options"></param>
        /// <param name="userClaimsProvider"></param>
        public PostgreSqlDataContext(DbContextOptions options, IUserClaimsProvider userClaimsProvider, IMediator mediator) : base(options)
        {
            this.userClaimsProvider = userClaimsProvider;
            this.mediator = mediator;
        }

        /// <summary>
        /// Override save changes async method
        /// </summary>
        /// <param name="cancellationToken"></param>
        /// <returns></returns>
        public override async Task<int> SaveChangesAsync(CancellationToken cancellationToken = new CancellationToken())
        {
            var entries = ChangeTracker.Entries().ToList();
            var userClaims = userClaimsProvider.GetUserClaims();
            foreach (var entry in entries)
            {
                if (entry.State == EntityState.Added || entry.State == EntityState.Modified)
                {
                    var entity = entry.Entity as CompanySpecificBase;
                    if (entity != null)
                    {
                        if (entry.State == EntityState.Added)
                        {
                            entity.CreatedBy = userClaims.Name;
                            entity.CreatedOn = DateTimeUtilities.ConvertDateTimeToEpoch(DateTime.UtcNow);
                            entity.BuId = userClaims.FsmContext.BuId;
                            entity.CmId = userClaims.FsmContext.CmId;
                            entity.BgId = userClaims.FsmContext.BgId;
                            entity.LoBId = userClaims.FsmContext.LoBId;
                            entity.CoId = userClaims.FsmContext.CoId;
                        }
                        else
                        {
                            base.Entry(entity).Property(x => x.CreatedBy).IsModified = false;
                            base.Entry(entity).Property(x => x.CreatedOn).IsModified = false;
                            entity.UpdatedBy = userClaims.Name;
                            entity.UpdatedOn = DateTimeUtilities.ConvertDateTimeToEpoch(DateTime.UtcNow);
                        }
                    }
                }
            }
            try
            {
                AuditLogEntity entity = null;
                try
                {
                    entity = OnBeforeSaveChanges();
                }
                catch (Exception ex)
                {
                    entity = null;
                }
                var result = await base.SaveChangesAsync(cancellationToken);
                if (entity != null && entity.EntityType != 0)
                    Task.Run(() => mediator.BroadcastAsync(new AuditLogEvent(entity), cancellationToken));
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private AuditLogEntity OnBeforeSaveChanges()
        {


            AuditLogEntity auditLogEntity = new AuditLogEntity();

            try
            {
                ChangeTracker.DetectChanges();
                var auditEntries = new List<AuditEntry>();
                var entries = ChangeTracker.Entries();
                var entityGroups = entries.GroupBy(x => x.Entity.GetType().Name);
                string masterEntityKey = ""; string masterEntityName = "";

                foreach (var grp in entityGroups)
                {
                    DispatchCustom(grp.Key, out bool isMaster, out masterEntityName, out masterEntityKey);
                    if (isMaster)
                    { break; }
                }

                var masterEntity = entityGroups.FirstOrDefault(x => x.Key == masterEntityKey);
                var masterState = masterEntity.Select(x => x.State).FirstOrDefault();

                AuditEntry auditEntry = new AuditEntry(masterEntity.FirstOrDefault(), this.userClaimsProvider);
                switch (masterState)
                {
                    case EntityState.Added:
                        auditEntry.AuditType = AuditRequestType.Create;
                        auditEntry.Description = string.Format("{0} created", masterEntityName);
                        break;
                    case EntityState.Deleted:
                        auditEntry.AuditType = AuditRequestType.Delete;
                        auditEntry.Description = string.Format("{0} deleted", masterEntityName);
                        break;
                    case EntityState.Modified:
                        auditEntry.AuditType = AuditRequestType.Update;
                        StringBuilder updatedFields =
                            new StringBuilder("");
                        foreach (var item in entityGroups)
                        {
                            var subEntity = item.Key != masterEntityKey ? item : null;
                            if (!item.Key.Equals(AuditHelper.EntityConstant.WORKORDER))
                            {
                                continue;
                            }
                            if (item.Key == masterEntityKey)
                            {
                                var description = MasterEntityUpdateHandler(masterEntity.FirstOrDefault(), auditEntry, updatedFields);
                                updatedFields.Append(description);
                            }
                            else if (subEntity != null && subEntity.ToList().Any(x => x.State != EntityState.Unchanged))
                            {
                                updatedFields.Append(string.Format("{0},", item.Key));
                                List<object> list = new List<object>();
                                //foreach (var sub in subEntity.Where(x => x.State != EntityState.Unchanged).ToList())
                                //{

                                //    list.Add(sub.CurrentValues.Properties);
                                //}
                            }
                        }
                        auditEntry.Description = string.Format("{0} updated. Updated fields: {1}", masterEntityName, updatedFields);
                        break;
                }

                auditLogEntity = auditEntry.ToAudit();
            }
            catch (Exception ex)
            {

            }
            return auditLogEntity;
        }


        private void DispatchCustom(string key, out bool isMaster, out string entityName, out string masterEntityKeyName)
        {
            switch (key)
            {
                case AuditHelper.EntityConstant.WORKORDER:
                    isMaster = true;
                    entityName = AuditHelper.EntityConstant.WORKORDER;
                    masterEntityKeyName = AuditHelper.EntityConstant.WORKORDER;
                    break;
                default:
                    isMaster = false;
                    entityName = "";
                    masterEntityKeyName = "";
                    break;
            }
        }
        private StringBuilder AuditEntry(object oldValue, object newValue, AuditEntry auditEntry, string propertyName, StringBuilder updatedFields)
        {
            auditEntry.AuditType = AuditRequestType.Update;
            auditEntry.OldValues[propertyName] = (List<string>)oldValue;
            auditEntry.NewValues[propertyName] = (List<string>)newValue;
            return updatedFields.Append(string.Format("{0}, ", propertyName));
        }

        private StringBuilder GenericListHandler(object oldValue, object newValue, AuditEntry auditEntry, string propertyName, StringBuilder updatedFields)
        {
            var objOld = oldValue as IEnumerable;
            var objNew = newValue as IEnumerable;

            var listOld = objOld?.Cast<object>()?.ToList();
            var listNew = objNew?.Cast<object>()?.ToList();

            if (((listOld == null && listNew != null) ||
                 (listOld != null && listNew == null)) ||
                 !((listOld.Count() == listNew.Count()) && !listOld.Except(listNew).Any())
               )
            {
                return AuditEntry(listOld, listNew, auditEntry, propertyName, updatedFields);
            }
            return updatedFields;
        }

        private StringBuilder MasterEntityUpdateHandler(EntityEntry entity, AuditEntry auditEntry, StringBuilder updatedFields)
        {
            foreach (var property in entity.Properties)
            {
                string propertyName = property.Metadata.Name;
                if (new[] { "UpdatedBy", "UpdatedOn" }.Contains(propertyName))
                {
                    continue;
                }
                object? currentValue = property.CurrentValue;
                object? originalValue = property.OriginalValue;
                if (property.Metadata.IsPrimaryKey())
                {

                    continue;
                }
                bool isEnumerableType = false;
                if (originalValue != null || currentValue != null)
                {
                    isEnumerableType = (originalValue ?? currentValue) is IList && (originalValue ?? currentValue).GetType().IsGenericType;
                }
                if (isEnumerableType)
                {
                    GenericListHandler(originalValue, currentValue, auditEntry, propertyName, updatedFields);
                }
                else if (!Equals(originalValue, currentValue))
                {
                    AuditEntry(property.OriginalValue, property.CurrentValue, auditEntry, propertyName, updatedFields);
                }
            }
            return updatedFields;
        }

    }
}
