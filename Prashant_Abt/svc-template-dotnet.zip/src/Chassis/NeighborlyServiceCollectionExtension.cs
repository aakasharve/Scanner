﻿using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace Neighborly.Chassis
{
    /// <summary>
    /// Class Extensions.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class NeighborlyServiceCollectionExtension
    {
        /// <summary>
        /// The section name
        /// </summary>
        private const string SectionName = "NeighborlyService";

        /// <summary>
        /// Adds the nbly.
        /// </summary>
        /// <param name="services">The services.</param>
        /// <param name="sectionName">Name of the section.</param>
        /// <returns>INeighborlyBuilder.</returns>
        public static INeighborlyBuilder AddNeighborly(this IServiceCollection services, string sectionName = SectionName)
        {
            if (string.IsNullOrWhiteSpace(sectionName)) sectionName = SectionName;

            var builder = NeighborlyBuilder.Create(services);
            var options = builder.GetOptions<NeighborlyServiceOptions>(sectionName);
            builder.Services.AddMemoryCache();

            services.AddSingleton(options);
            services.AddSingleton<INeighborlyService, NeighborlyService>();

            if (!options.DisplayBanner || string.IsNullOrWhiteSpace(options.Name)) return builder;

            var version = options.DisplayVersion ? $" {options.Version}" : string.Empty;
            Console.WriteLine(Figgle.FiggleFonts.Doom.Render($"{options.Name} {version}"));

            return builder;
        }

        /// <summary>
        /// Uses the nbly.
        /// </summary>
        /// <param name="app">The application.</param>
        /// <returns>IApplicationBuilder.</returns>
        public static IApplicationBuilder UseNeighborly(this IApplicationBuilder app)
        {
            using (var scope = app.ApplicationServices.CreateScope())
            {
                var initializer = scope.ServiceProvider.GetRequiredService<IStartupInitializer>();

                Task.Run(() => initializer.InitializeAsync()).GetAwaiter().GetResult();
            }

            return app;
        }

        /// <summary>
        /// Gets the options.
        /// </summary>
        /// <typeparam name="TModel">The type of the t model.</typeparam>
        /// <param name="configuration">The configuration.</param>
        /// <param name="sectionName">Name of the section.</param>
        /// <returns>TModel.</returns>
        public static TModel GetOptions<TModel>(this IConfiguration configuration, string sectionName)
            where TModel : new()
        {
            var model = new TModel();
            configuration.GetSection(sectionName).Bind(model);
            return model;
        }

        /// <summary>
        /// Gets the options.
        /// </summary>
        /// <typeparam name="TModel">The type of the t model.</typeparam>
        /// <param name="builder">The builder.</param>
        /// <param name="settingsSectionName">Name of the settings section.</param>
        /// <returns>TModel.</returns>
        public static TModel GetOptions<TModel>(this INeighborlyBuilder builder, string settingsSectionName)
            where TModel : new()
        {
            using var serviceProvider = builder.Services.BuildServiceProvider();
            var configuration = serviceProvider.GetService<IConfiguration>();
            return configuration.GetOptions<TModel>(settingsSectionName);
        }


        /// <summary>
        /// Underscores the specified value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.String.</returns>
        public static string Underscore(this string value)
        {
            return string.Concat(value.Select((x, i) => i > 0 && char.IsUpper(x) ? "_" + x : x.ToString()))
                .ToLowerInvariant();
        }
    }
}