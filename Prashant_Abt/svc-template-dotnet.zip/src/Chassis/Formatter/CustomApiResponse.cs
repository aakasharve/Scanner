﻿namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// CustomApiResponse
    /// </summary>
    public class CustomApiResponse
    {
        /// <summary>
        /// CustomApiResponse
        /// </summary>
        /// <param name="isError"></param>
        /// <param name="status"></param>
        /// <param name="message"></param>
        /// <param name="result"></param>
        public CustomApiResponse(bool? isError, int? status, string message, object result)
        {
            IsError = isError;
            Status = status;
            Message = message;
            Result = result;
        }
        /// <summary>
        /// IsError
        /// </summary>
        public bool? IsError { get; set; }
        /// <summary>
        /// Status
        /// </summary>
        public int? Status { get; set; }
        /// <summary>
        /// Message
        /// </summary>
        public string Message { get; set; }
        /// <summary>
        /// Result
        /// </summary>
        public object Result { get; set; }
    }
}
