﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using Newtonsoft.Json.Serialization;
using System.Collections.Generic;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class CamelCaseContractResolverJsonSettings.
    /// </summary>
    public class CamelCaseContractResolverJsonSettings
    {
        /// <summary>
        /// Gets the json settings.
        /// </summary>
        /// <param name="ignoreNull">if set to <c>true</c> [ignore null].</param>
        /// <param name="referenceLoopHandling">The reference loop handling.</param>
        /// <param name="useCamelCaseNaming">if set to <c>true</c> [use camel case naming].</param>
        /// <returns>JsonSerializerSettings.</returns>
        public JsonSerializerSettings GetJSONSettings(bool ignoreNull, ReferenceLoopHandling referenceLoopHandling = ReferenceLoopHandling.Ignore, bool useCamelCaseNaming = true)
        {
            return new JsonSerializerSettings
            {
                Formatting = Formatting.Indented,
                ContractResolver = useCamelCaseNaming ? new CamelCasePropertyNamesContractResolver() : new DefaultContractResolver(),
                Converters = new List<JsonConverter> { new StringEnumConverter() },
                NullValueHandling = ignoreNull ? NullValueHandling.Ignore : NullValueHandling.Include,
                ReferenceLoopHandling = referenceLoopHandling
            };
        }
    }

    /// <summary>
    /// Class CustomContractResolverJsonSettings.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class CustomContractResolverJsonSettings<T>
    {
        /// <summary>
        /// Gets the json settings.
        /// </summary>
        /// <param name="ignoreNull">if set to <c>true</c> [ignore null].</param>
        /// <param name="referenceLoopHandling">The reference loop handling.</param>
        /// <param name="useCamelCaseNaming">if set to <c>true</c> [use camel case naming].</param>
        /// <returns>System.ValueTuple&lt;JsonSerializerSettings, Dictionary&lt;System.String, System.String&gt;&gt;.</returns>
        public (JsonSerializerSettings Settings, Dictionary<string, string> Mappings) GetJSONSettings(bool ignoreNull, ReferenceLoopHandling referenceLoopHandling = ReferenceLoopHandling.Ignore, bool useCamelCaseNaming = true)
        {
            var resolver = new CustomContractResolver<T>(useCamelCaseNaming);
            var propMappings = resolver._propertyMappings;

            var settings = new JsonSerializerSettings
            {
                Formatting = Formatting.Indented,
                ContractResolver = resolver,
                NullValueHandling = ignoreNull ? NullValueHandling.Ignore : NullValueHandling.Include,
                ReferenceLoopHandling = referenceLoopHandling
            };

            return (settings, propMappings);

        }
    }
}
