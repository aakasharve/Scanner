﻿using Newtonsoft.Json.Linq;
using System;
using System.Text.RegularExpressions;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class StringExtension.
    /// </summary>
    internal static class StringExtension
    {
        /// <summary>
        /// Determines whether [is valid json] [the specified text].
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns><c>true</c> if [is valid json] [the specified text]; otherwise, <c>false</c>.</returns>
        public static bool IsValidJson(this string text)
        {
            text = text.Trim();
            if ((text.StartsWith("{") && text.EndsWith("}")) || //For object
                (text.StartsWith("[") && text.EndsWith("]"))) //For array
            {
                try
                {
                    JToken.Parse(text);
                    return true;
                }
                catch (Exception)
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Verifies the content of the body.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns>System.ValueTuple&lt;System.Boolean, System.String&gt;.</returns>
        public static (bool IsEncoded, string ParsedText) VerifyBodyContent(this string text)
        {
            try
            {
                var obj = JToken.Parse(text);
                return (true, obj.ToString());
            }
            catch (Exception)
            {
                return (false, text);
            }
        }

        /// <summary>
        /// Determines whether the specified text is HTML.
        /// </summary>
        /// <param name="text">The text.</param>
        /// <returns><c>true</c> if the specified text is HTML; otherwise, <c>false</c>.</returns>
        public static bool IsHtml(this string text)
        {
            Regex tagRegex = new Regex(@"<\s*([^ >]+)[^>]*>.*?<\s*/\s*\1\s*>");

            return tagRegex.IsMatch(text);
        }


        /// <summary>
        /// Converts to camelcase.
        /// </summary>
        /// <param name="str">The string.</param>
        /// <returns>System.String.</returns>
        public static string ToCamelCase(this string str)
        {
            if (!string.IsNullOrEmpty(str) && str.Length > 1)
            {
                return Char.ToLowerInvariant(str[0]) + str.Substring(1);
            }
            return str;
        }

    }
}
