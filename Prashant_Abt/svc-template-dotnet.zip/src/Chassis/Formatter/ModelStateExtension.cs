﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Collections.Generic;
using System.Linq;


namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class ModelStateExtension.
    /// </summary>
    public static class ModelStateExtension
    {
        /// <summary>
        /// Alls the errors.
        /// </summary>
        /// <param name="modelState">State of the model.</param>
        /// <returns>IEnumerable&lt;ValidationError&gt;.</returns>
        public static IEnumerable<ValidationError> AllErrors(this ModelStateDictionary modelState)
        {
            return modelState.Keys.SelectMany(key => modelState[key].Errors.Select(x => new ValidationError(key, x.ErrorMessage))).ToList();
        }
    }
}
