﻿using Microsoft.AspNetCore.Mvc;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class ApiProblemDetailsResponse.
    /// Implements the <see cref="Microsoft.AspNetCore.Mvc.ProblemDetails" />
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ProblemDetails" />
    public class ApiProblemDetailsResponse : ProblemDetails
    {
        /// <summary>
        /// Gets or sets a value indicating whether this instance is error.
        /// </summary>
        /// <value><c>true</c> if this instance is error; otherwise, <c>false</c>.</value>
        public bool IsError { get; set; }
    }
}
