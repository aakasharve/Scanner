﻿
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class JSONHelper.
    /// </summary>
    public static class JSONHelper
    {
        /// <summary>
        /// Gets the json settings.
        /// </summary>
        /// <param name="ignoreNull">if set to <c>true</c> [ignore null].</param>
        /// <param name="referenceLoopHandling">The reference loop handling.</param>
        /// <param name="useCamelCaseNaming">if set to <c>true</c> [use camel case naming].</param>
        /// <returns>JsonSerializerSettings.</returns>
        public static JsonSerializerSettings GetJSONSettings(bool ignoreNull = true, ReferenceLoopHandling referenceLoopHandling = ReferenceLoopHandling.Ignore, bool useCamelCaseNaming = true)
        {
            return new CamelCaseContractResolverJsonSettings().GetJSONSettings(ignoreNull, referenceLoopHandling, useCamelCaseNaming);
        }

        /// <summary>
        /// Gets the json settings.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="ignoreNull">if set to <c>true</c> [ignore null].</param>
        /// <param name="referenceLoopHandling">The reference loop handling.</param>
        /// <param name="useCamelCaseNaming">if set to <c>true</c> [use camel case naming].</param>
        /// <returns>System.ValueTuple&lt;JsonSerializerSettings, Dictionary&lt;System.String, System.String&gt;&gt;.</returns>
        public static (JsonSerializerSettings Settings, Dictionary<string, string> Mappings) GetJSONSettings<T>(bool ignoreNull = true, ReferenceLoopHandling referenceLoopHandling = ReferenceLoopHandling.Ignore, bool useCamelCaseNaming = true)
        {
            return new CustomContractResolverJsonSettings<T>().GetJSONSettings(ignoreNull, referenceLoopHandling, useCamelCaseNaming);
        }

        /// <summary>
        /// Determines whether the specified object has property.
        /// </summary>
        /// <param name="obj">The object.</param>
        /// <param name="name">The name.</param>
        /// <returns><c>true</c> if the specified object has property; otherwise, <c>false</c>.</returns>
        public static bool HasProperty(dynamic obj, string name)
        {
            if (obj is JObject) return ((JObject)obj).ContainsKey(name);
            return obj.GetType().GetProperty(name) != null;
        }
        /// <summary>
        /// Removes the empty children.
        /// </summary>
        /// <param name="token">The token.</param>
        /// <returns>JToken.</returns>
        public static JToken RemoveEmptyChildren(JToken token)
        {
            if (token.Type == JTokenType.Object)
            {
                JObject copy = new JObject();
                foreach (JProperty prop in token.Children<JProperty>())
                {
                    JToken child = prop.Value;
                    if (child.HasValues)
                    {
                        child = RemoveEmptyChildren(child);
                    }

                    if (!child.IsNullOrEmpty())
                    {
                        copy.Add(prop.Name, child);
                    }
                }
                return copy;
            }
            else if (token.Type == JTokenType.Array)
            {
                JArray copy = new JArray();
                foreach (JToken item in token.Children())
                {
                    JToken child = item;
                    if (child.HasValues)
                    {
                        child = RemoveEmptyChildren(child);
                    }

                    if (!child.IsNullOrEmpty())
                    {
                        copy.Add(child);
                    }
                }
                return copy;
            }
            return token;
        }

        /// <summary>
        /// Determines whether the specified token is empty.
        /// </summary>
        /// <param name="token">The token.</param>
        /// <returns><c>true</c> if the specified token is empty; otherwise, <c>false</c>.</returns>
        public static bool IsEmpty(JToken token)
        {
            return (token.Type == JTokenType.Null);
        }
    }
}
