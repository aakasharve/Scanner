﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.AspNetCore.Routing;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;
using static Microsoft.AspNetCore.Http.StatusCodes;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class ApiProblemDetailsMember.
    /// </summary>
    internal class ApiProblemDetailsMember
    {
        /// <summary>
        /// The empty route data
        /// </summary>
        private static readonly RouteData _emptyRouteData = new RouteData();
        /// <summary>
        /// The empty action descriptor
        /// </summary>
        private static readonly ActionDescriptor _emptyActionDescriptor = new ActionDescriptor();
        /// <summary>
        /// Writes the problem details asynchronous.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="executor">The executor.</param>
        /// <param name="body">The body.</param>
        /// <param name="exception">The exception.</param>
        /// <param name="isDebug">if set to <c>true</c> [is debug].</param>
        /// <returns>Task.</returns>
        public Task WriteProblemDetailsAsync(HttpContext context, IActionResultExecutor<ObjectResult> executor, object body, Exception exception, bool isDebug = false)
        {
            var statusCode = context.Response.StatusCode;
            object details = exception == null ? DelegateResponse(body, statusCode) : GetProblemDetails(exception, isDebug);

            if (details is ProblemDetails) { (details as ProblemDetails)!.Instance = context.Request.Path; }

            var routeData = context.GetRouteData() ?? _emptyRouteData;

            var actionContext = new ActionContext(context, routeData, _emptyActionDescriptor);

            var result = new ObjectResult(details)
            {
                StatusCode = (details is ProblemDetails problem) ? problem.Status : statusCode,
                DeclaredType = details.GetType()
            };

            result.ContentTypes.Add(TypeIdentifier.ProblemJSONHttpContentMediaType);
            result.ContentTypes.Add(TypeIdentifier.ProblemXMLHttpContentMediaType);

            return executor.ExecuteAsync(actionContext, result);
        }

        /// <summary>
        /// Delegates the response.
        /// </summary>
        /// <param name="body">The body.</param>
        /// <param name="statusCode">The status code.</param>
        /// <returns>System.Object.</returns>
        private object DelegateResponse(object body, int statusCode)
        {
            var content = body ?? string.Empty;
            var (IsEncoded, ParsedText) = content.ToString()!.VerifyBodyContent();
            var result = IsEncoded ? JsonConvert.DeserializeObject<dynamic>(ParsedText) : new ApiProblemDetails(statusCode) { Detail = content.ToString() };

            return result;
        }
        /// <summary>
        /// Gets the problem details.
        /// </summary>
        /// <param name="exception">The exception.</param>
        /// <param name="isDebug">if set to <c>true</c> [is debug].</param>
        /// <returns>ProblemDetails.</returns>
        private ProblemDetails GetProblemDetails(Exception exception, bool isDebug)
        {
            if (exception is ApiProblemDetailsException problem) { return problem.Problem.Details; }

            var defaultException = new ExceptionFallback(exception);

            if (isDebug) { return new DebugExceptionetails(defaultException); }

            return new ApiProblemDetails((int)defaultException.Status!) { Detail = defaultException.Exception.Message };
        }

        /// <summary>
        /// Class ErrorDetails.
        /// </summary>
        internal class ErrorDetails
        {
            /// <summary>
            /// Gets or sets the message.
            /// </summary>
            /// <value>The message.</value>
            public string Message { get; set; }
            /// <summary>
            /// Gets or sets the type.
            /// </summary>
            /// <value>The type.</value>
            public string Type { get; set; }
            /// <summary>
            /// Gets or sets the source.
            /// </summary>
            /// <value>The source.</value>
            public string? Source { get; set; }
            /// <summary>
            /// Gets or sets the raw.
            /// </summary>
            /// <value>The raw.</value>
            public string? Raw { get; set; }

            /// <summary>
            /// Initializes a new instance of the <see cref="ErrorDetails"/> class.
            /// </summary>
            /// <param name="detail">The detail.</param>
            public ErrorDetails(ExceptionFallback detail)
            {
                Source = detail.Exception.Source;
                Raw = detail.Exception.StackTrace;
                Message = detail.Exception.Message;
                Type = detail.Exception.GetType().Name;
            }
        }

        /// <summary>
        /// Class ExceptionFallback.
        /// Implements the <see cref="Neighborly.Chassis.Formatter.ApiProblemDetails" />
        /// </summary>
        /// <seealso cref="Neighborly.Chassis.Formatter.ApiProblemDetails" />
        internal class ExceptionFallback : ApiProblemDetails
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="ExceptionFallback"/> class.
            /// </summary>
            /// <param name="exception">The exception.</param>
            public ExceptionFallback(Exception exception) : this(exception, Status500InternalServerError)
            {
                Detail = exception.Message;
            }

            /// <summary>
            /// Initializes a new instance of the <see cref="ExceptionFallback"/> class.
            /// </summary>
            /// <param name="exception">The exception.</param>
            /// <param name="statusCode">The status code.</param>
            /// <exception cref="ArgumentNullException">exception</exception>
            public ExceptionFallback(Exception exception, int statusCode) : base(statusCode)
            {
                Exception = exception ?? throw new ArgumentNullException(nameof(exception));
            }

            /// <summary>
            /// Gets the exception.
            /// </summary>
            /// <value>The exception.</value>
            public Exception Exception { get; }
        }

        /// <summary>
        /// Class DebugExceptionetails.
        /// Implements the <see cref="Neighborly.Chassis.Formatter.ApiProblemDetails" />
        /// </summary>
        /// <seealso cref="Neighborly.Chassis.Formatter.ApiProblemDetails" />
        internal class DebugExceptionetails : ApiProblemDetails
        {
            /// <summary>
            /// Initializes a new instance of the <see cref="DebugExceptionetails"/> class.
            /// </summary>
            /// <param name="problem">The problem.</param>
            public DebugExceptionetails(ExceptionFallback problem)
                : base(problem.Status ?? Status500InternalServerError)
            {
                Detail = problem.Detail ?? problem.Exception.Message;
                Title = problem.Title ?? problem.Exception.GetType().Name;
                Instance = problem.Instance ?? GetHelpLink(problem.Exception);

                if (!string.IsNullOrEmpty(problem.Type))
                {
                    Type = problem.Type;
                }

                Errors = new ErrorDetails(problem);
            }

            /// <summary>
            /// Gets the help link.
            /// </summary>
            /// <param name="exception">The exception.</param>
            /// <returns>System.String.</returns>
            private static string GetHelpLink(Exception exception)
            {
                var link = exception.HelpLink;

                if (string.IsNullOrEmpty(link))
                {
                    return default!;
                }

                if (Uri.TryCreate(link, UriKind.Absolute, out var result))
                {
                    return result.ToString();
                }

                return default!;
            }

        }
    }
}
