﻿using Newtonsoft.Json.Linq;
using System;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class JsonExtensions.
    /// </summary>
    public static class JsonExtensions
    {
        /// <summary>
        /// Determines whether [is null or empty] [the specified token].
        /// </summary>
        /// <param name="token">The token.</param>
        /// <returns><c>true</c> if [is null or empty] [the specified token]; otherwise, <c>false</c>.</returns>
        public static bool IsNullOrEmpty(this JToken token)
        {
            return (token == null) ||
                   (token.Type == JTokenType.Array && !token.HasValues) ||
                   (token.Type == JTokenType.Object && !token.HasValues) ||
                   (token.Type == JTokenType.String && token.ToString() == String.Empty) ||
                   (token.Type == JTokenType.Null);
        }
    }
}
