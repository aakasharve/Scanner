﻿namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class ApiResultResponse.
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class ApiResultResponse<T> where T : class
    {
        /// <summary>
        /// Gets or sets the message.
        /// </summary>
        /// <value>The message.</value>
        public string? Message { get; set; }
        /// <summary>
        /// Gets or sets the result.
        /// </summary>
        /// <value>The result.</value>
        public T Result { get; set; } = default!;
    }
}
