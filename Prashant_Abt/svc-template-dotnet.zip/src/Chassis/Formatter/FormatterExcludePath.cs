﻿namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Enum ExcludeMode
    /// </summary>
    public enum ExcludeMode
    {
        /// <summary>
        /// The strict
        /// </summary>
        Strict = 1,
        /// <summary>
        /// The start with
        /// </summary>
        StartWith = 2,
        /// <summary>
        /// The regex
        /// </summary>
        Regex = 3
    }

    /// <summary>
    /// Class FormatterExcludePath.
    /// </summary>
    public class FormatterExcludePath
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="FormatterExcludePath"/> class.
        /// </summary>
        /// <param name="path">The path.</param>
        /// <param name="excludeMode">The exclude mode.</param>
        public FormatterExcludePath(string path, ExcludeMode excludeMode = ExcludeMode.Strict)
        {
            Path = path;
            ExcludeMode = excludeMode;
        }

        /// <summary>
        /// Gets or sets the path.
        /// </summary>
        /// <value>The path.</value>
        public string Path { get; set; }

        /// <summary>
        /// Gets or sets the exclude mode.
        /// </summary>
        /// <value>The exclude mode.</value>
        public ExcludeMode ExcludeMode { get; set; }
    }
}
