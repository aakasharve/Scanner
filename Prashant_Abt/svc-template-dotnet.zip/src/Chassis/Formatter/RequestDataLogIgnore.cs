﻿using System;


namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class RequestDataLogIgnoreAttribute.
    /// Implements the <see cref="System.Attribute" />
    /// </summary>
    /// <seealso cref="System.Attribute" />
    public class RequestDataLogIgnoreAttribute : Attribute
    {
    }
}
