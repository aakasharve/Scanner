﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class FormatterOptions.
    /// Implements the <see cref="Neighborly.Chassis.Formatter.OptionBase" />
    /// </summary>
    /// <seealso cref="Neighborly.Chassis.Formatter.OptionBase" />
    public class FormatterOptions : OptionBase
    {
        /// <summary>
        /// Gets or sets a value indicating whether [use custom schema].
        /// </summary>
        /// <value><c>true</c> if [use custom schema]; otherwise, <c>false</c>.</value>
        public bool UseCustomSchema { get; set; } = false;
        /// <summary>
        /// Gets or sets the reference loop handling.
        /// </summary>
        /// <value>The reference loop handling.</value>
        public ReferenceLoopHandling ReferenceLoopHandling { get; set; } = ReferenceLoopHandling.Ignore;
        /// <summary>
        /// Gets or sets a value indicating whether [use custom exception format].
        /// </summary>
        /// <value><c>true</c> if [use custom exception format]; otherwise, <c>false</c>.</value>
        public bool UseCustomExceptionFormat { get; set; } = false;
        /// <summary>
        /// Gets or sets a value indicating whether [use API problem details exception].
        /// </summary>
        /// <value><c>true</c> if [use API problem details exception]; otherwise, <c>false</c>.</value>
        public bool UseApiProblemDetailsException { get; set; } = false;
        /// <summary>
        /// Gets or sets a value indicating whether [log request data on exception].
        /// </summary>
        /// <value><c>true</c> if [log request data on exception]; otherwise, <c>false</c>.</value>
        public bool LogRequestDataOnException { get; set; } = true;

        /// <summary>
        /// Gets or sets a value indicating whether [should log request data].
        /// </summary>
        /// <value><c>true</c> if [should log request data]; otherwise, <c>false</c>.</value>
        public bool ShouldLogRequestData { get; set; } = true;

        /// <summary>
        /// Gets or sets the swagger path.
        /// </summary>
        /// <value>The swagger path.</value>
        public string SwaggerPath { get; set; } = "/swagger";

        /// <summary>
        /// Gets or sets the exclude paths.
        /// </summary>
        /// <value>The exclude paths.</value>
        public IEnumerable<FormatterExcludePath>? ExcludePaths { get; set; } = null;
    }
}
