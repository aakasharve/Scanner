﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Text;
using static Microsoft.AspNetCore.Http.StatusCodes;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class ApiProblemDetailsException.
    /// Implements the <see cref="System.Exception" />
    /// </summary>
    /// <seealso cref="System.Exception" />
    public class ApiProblemDetailsException : Exception
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ApiProblemDetailsException"/> class.
        /// </summary>
        /// <param name="statusCode">The status code.</param>
        public ApiProblemDetailsException(int statusCode)
            : this(new ApiProblemDetails(statusCode))
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiProblemDetailsException"/> class.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <param name="statusCode">The status code.</param>
        public ApiProblemDetailsException(string title, int statusCode)
            : this(new ApiProblemDetails(statusCode) { Title = title })
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiProblemDetailsException"/> class.
        /// </summary>
        /// <param name="details">The details.</param>
        public ApiProblemDetailsException(ProblemDetails details)
            : base($"{details.Type} : {details.Title}")
        {
            Problem = new ApiProblemDetails(details);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiProblemDetailsException"/> class.
        /// </summary>
        /// <param name="modelState">State of the model.</param>
        /// <param name="statusCode">The status code.</param>
        public ApiProblemDetailsException(ModelStateDictionary modelState, int statusCode = Status422UnprocessableEntity)
             : this(new ApiProblemDetails(statusCode) { Detail = "Your request parameters didn't validate.", ValidationErrors = modelState.AllErrors() })
        {
        }

        /// <summary>
        /// Gets the status code.
        /// </summary>
        /// <value>The status code.</value>
        public int StatusCode => Problem.Details.Status ?? 0;
        /// <summary>
        /// Gets the problem.
        /// </summary>
        /// <value>The problem.</value>
        internal ApiProblemDetails Problem { get; }

        /// <summary>
        /// Returns a <see cref="System.String" /> that represents this instance.
        /// </summary>
        /// <returns>A <see cref="System.String" /> that represents this instance.</returns>
        public override string ToString()
        {
            var stringBuilder = new StringBuilder();

            stringBuilder.AppendLine($"Type    : {Problem.Details.Type}");
            stringBuilder.AppendLine($"Title   : {Problem.Details.Title}");
            stringBuilder.AppendLine($"Status  : {Problem.Details.Status}");
            stringBuilder.AppendLine($"Detail  : {Problem.Details.Detail}");
            stringBuilder.AppendLine($"Instance: {Problem.Details.Instance}");

            return stringBuilder.ToString();
        }
    }
}
