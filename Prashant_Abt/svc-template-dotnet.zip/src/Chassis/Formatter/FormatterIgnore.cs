﻿using System;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class AutoWrapIgnoreAttribute.
    /// Implements the <see cref="System.Attribute" />
    /// </summary>
    /// <seealso cref="System.Attribute" />
    public class AutoWrapIgnoreAttribute : Attribute
    {
        /// <summary>
        /// Gets or sets a value indicating whether [should log request data].
        /// </summary>
        /// <value><c>true</c> if [should log request data]; otherwise, <c>false</c>.</value>
        public bool ShouldLogRequestData { get; set; } = true;

        /// <summary>
        /// Initializes a new instance of the <see cref="AutoWrapIgnoreAttribute"/> class.
        /// </summary>
        public AutoWrapIgnoreAttribute() { }
    }
}
