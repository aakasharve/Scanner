﻿using Microsoft.AspNetCore.Builder;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class FormatterExtension.
    /// </summary>
    public static class FormatterExtension
    {
        /// <summary>
        /// Uses the API response and exception wrapper.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <param name="options">The options.</param>
        /// <returns>IApplicationBuilder.</returns>
        public static IApplicationBuilder UseApiResponseAndExceptionWrapper(this IApplicationBuilder builder, FormatterOptions options = default)
        {
            options ??= new FormatterOptions();
            return builder.UseMiddleware<FormatterMiddleware>(options);
        }

        /// <summary>
        /// Uses the API response and exception wrapper.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="builder">The builder.</param>
        /// <param name="options">The options.</param>
        /// <returns>IApplicationBuilder.</returns>
        public static IApplicationBuilder UseApiResponseAndExceptionWrapper<T>(this IApplicationBuilder builder, FormatterOptions options = default)
        {
            options ??= new FormatterOptions();
            return builder.UseMiddleware<FormatterMiddleware<T>>(options);
        }
    }
}
