﻿using System;
using System.Text.RegularExpressions;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class TypeConverterExtension.
    /// </summary>
    public static class TypeConverterExtension
    {
        /// <summary>
        /// Converts to datetime.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>DateTime.</returns>
        public static DateTime ToDateTime(this string value)
            => DateTime.TryParse(value, out var result) ? result : default;

        /// <summary>
        /// Converts to int16.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.Int16.</returns>
        public static short ToInt16(this string value)
            => short.TryParse(value, out var result) ? result : default;

        /// <summary>
        /// Converts to int32.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.Int32.</returns>
        public static int ToInt32(this string value)
            => int.TryParse(value, out var result) ? result : default;

        /// <summary>
        /// Converts to int64.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.Int64.</returns>
        public static long ToInt64(this string value)
            => long.TryParse(value, out var result) ? result : default;

        /// <summary>
        /// Converts to boolean.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        public static bool ToBoolean(this string value)
            => bool.TryParse(value, out var result) ? result : default;

        /// <summary>
        /// Converts to float.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.Single.</returns>
        public static float ToFloat(this string value)
            => float.TryParse(value, out var result) ? result : default;

        /// <summary>
        /// Converts to decimal.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.Decimal.</returns>
        public static decimal ToDecimal(this string value)
            => decimal.TryParse(value, out var result) ? result : default;

        /// <summary>
        /// Converts to double.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>System.Double.</returns>
        public static double ToDouble(this string value)
           => double.TryParse(value, out var result) ? result : default;

        /// <summary>
        /// Determines whether the specified value is number.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns><c>true</c> if the specified value is number; otherwise, <c>false</c>.</returns>
        public static bool IsNumber(this string value)
            => Regex.IsMatch(value, @"^\d+$");

        /// <summary>
        /// Determines whether [is whole number] [the specified value].
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns><c>true</c> if [is whole number] [the specified value]; otherwise, <c>false</c>.</returns>
        public static bool IsWholeNumber(this string value)
            => long.TryParse(value, out _);

        /// <summary>
        /// Determines whether [is decimal number] [the specified value].
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns><c>true</c> if [is decimal number] [the specified value]; otherwise, <c>false</c>.</returns>
        public static bool IsDecimalNumber(this string value)
         => decimal.TryParse(value, out _);

        /// <summary>
        /// Determines whether the specified value is boolean.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns><c>true</c> if the specified value is boolean; otherwise, <c>false</c>.</returns>
        public static bool IsBoolean(this string value)
           => bool.TryParse(value, out var _);

    }
}
