﻿using System;

namespace Neighborly.Chassis.Formatter
{

    /// <summary>
    /// Class FormatterPropertyMapAttribute. This class cannot be inherited.
    /// Implements the <see cref="System.Attribute" />
    /// </summary>
    /// <seealso cref="System.Attribute" />
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property | AttributeTargets.Parameter, AllowMultiple = false)]
    public sealed class FormatterPropertyMapAttribute : Attribute
    {
        /// <summary>
        /// Gets or sets the name of the property.
        /// </summary>
        /// <value>The name of the property.</value>
        public string PropertyName { get; set; } = string.Empty;
        /// <summary>
        /// Initializes a new instance of the <see cref="FormatterPropertyMapAttribute"/> class.
        /// </summary>
        public FormatterPropertyMapAttribute() { }
        /// <summary>
        /// Gets or sets the name of the property.
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        /// <value>The name of the property.</value>

        public FormatterPropertyMapAttribute(string propertyName)
        {
            PropertyName = propertyName;
        }
    }

    /// <summary>
    /// Class Prop.
    /// </summary>
    public class Prop
    {
        /// <summary>
        /// The version
        /// </summary>
        public const string Version = "Version";
        /// <summary>
        /// The status code
        /// </summary>
        public const string StatusCode = "StatusCode";
        /// <summary>
        /// The message
        /// </summary>
        public const string Message = "Message";
        /// <summary>
        /// The is error
        /// </summary>
        public const string IsError = "IsError";
        /// <summary>
        /// The result
        /// </summary>
        public const string Result = "Result";
        /// <summary>
        /// The response exception
        /// </summary>
        public const string ResponseException = "ResponseException";
        /// <summary>
        /// The response exception exception message
        /// </summary>
        public const string ResponseException_ExceptionMessage = "ExceptionMessage";
        /// <summary>
        /// The response exception details
        /// </summary>
        public const string ResponseException_Details = "Details";
        /// <summary>
        /// The response exception reference error code
        /// </summary>
        public const string ResponseException_ReferenceErrorCode = "ReferenceErrorCode";
        /// <summary>
        /// The response exception reference document link
        /// </summary>
        public const string ResponseException_ReferenceDocumentLink = "ReferenceDocumentLink";
        /// <summary>
        /// The response exception validation errors
        /// </summary>
        public const string ResponseException_ValidationErrors = "ValidationErrors";
        /// <summary>
        /// The response exception validation errors field
        /// </summary>
        public const string ResponseException_ValidationErrors_Field = "Field";
        /// <summary>
        /// The response exception validation errors message
        /// </summary>
        public const string ResponseException_ValidationErrors_Message = "Message";
    }
}
