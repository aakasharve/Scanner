﻿using Datadog.Trace;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static Microsoft.AspNetCore.Http.StatusCodes;

namespace Neighborly.Chassis.Formatter
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class FormatterMembers.
    /// </summary>
    internal class FormatterMembers
    {

        /// <summary>
        /// The options
        /// </summary>
        private readonly FormatterOptions _options;
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<FormatterMiddleware> _logger;
        /// <summary>
        /// The json settings
        /// </summary>
        private readonly JsonSerializerSettings _jsonSettings;
        /// <summary>
        /// The property mappings
        /// </summary>
        public readonly Dictionary<string, string> _propertyMappings;
        /// <summary>
        /// The has schema for mappping
        /// </summary>
        readonly bool _hasSchemaForMappping;
        /// <summary>
        /// Initializes a new instance of the <see cref="FormatterMembers"/> class.
        /// </summary>
        /// <param name="options">The options.</param>
        /// <param name="logger">The logger.</param>
        /// <param name="jsonSettings">The json settings.</param>
        /// <param name="propertyMappings">The property mappings.</param>
        /// <param name="hasSchemaForMappping">if set to <c>true</c> [has schema for mappping].</param>
        public FormatterMembers(FormatterOptions options,
                                    ILogger<FormatterMiddleware> logger,
                                    JsonSerializerSettings jsonSettings,
                                    Dictionary<string, string> propertyMappings = null,
                                    bool hasSchemaForMappping = false)
        {
            _options = options;
            _logger = logger;
            _jsonSettings = jsonSettings;
            _propertyMappings = propertyMappings;
            _hasSchemaForMappping = hasSchemaForMappping;
        }

        /// <summary>
        /// get request body as an asynchronous operation.
        /// </summary>
        /// <param name="request">The request.</param>
        /// <returns>System.String.</returns>
        public async Task<string> GetRequestBodyAsync(HttpRequest request)
        {
            var httpMethodsWithRequestBody = new[] { "POST", "PUT", "PATCH" };
            var hasRequestBody = httpMethodsWithRequestBody.Any(x => x.Equals(request.Method.ToUpper()));
            string requestBody = string.Empty;

            if (hasRequestBody)
            {
                request.EnableBuffering();

                using var memoryStream = new MemoryStream();
                await request.Body.CopyToAsync(memoryStream);
                requestBody = Encoding.UTF8.GetString(memoryStream.ToArray());
                request.Body.Seek(0, SeekOrigin.Begin);
            }
            return requestBody;
        }

        /// <summary>
        /// read response body stream as an asynchronous operation.
        /// </summary>
        /// <param name="bodyStream">The body stream.</param>
        /// <returns>System.String.</returns>
        public async Task<string> ReadResponseBodyStreamAsync(Stream bodyStream)
        {
            bodyStream.Seek(0, SeekOrigin.Begin);
            var responseBody = await new StreamReader(bodyStream).ReadToEndAsync();
            bodyStream.Seek(0, SeekOrigin.Begin);

            var (IsEncoded, ParsedText) = responseBody.VerifyBodyContent();

            return IsEncoded ? ParsedText : responseBody;
        }

        /// <summary>
        /// revert response body stream as an asynchronous operation.
        /// </summary>
        /// <param name="bodyStream">The body stream.</param>
        /// <param name="orginalBodyStream">The orginal body stream.</param>
        public async Task RevertResponseBodyStreamAsync(Stream bodyStream, Stream orginalBodyStream)
        {
            bodyStream.Seek(0, SeekOrigin.Begin);
            await bodyStream.CopyToAsync(orginalBodyStream);
        }

        /// <summary>
        /// handle exception as an asynchronous operation.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="exception">The exception.</param>
        public async Task<string> HandleExceptionAsync(HttpContext context, Exception exception)
        {
            if (_options.UseCustomExceptionFormat)
            {
                CustomApiResponse customError;
                int statusCode;
                string json = exception.GetBaseException().Message;
                using (var scope = Tracer.Instance.ActiveScope)
                {
                    if (scope != null)
                    {
                        scope.Span.SetException(exception);
                    }
                }
                if (exception.Message.Contains("Validation failed"))
                {
                    var fluentErrors = ((FluentValidation.ValidationException)exception).Errors;
                    List<ValidationError> errorList = new List<ValidationError>();

                    foreach (var item in fluentErrors)
                    {
                        ValidationError error = new ValidationError(item.PropertyName, item.ErrorMessage);
                        errorList.Add(error);
                    }
                    customError = new CustomApiResponse(true, 400, "Fields validation error", errorList);
                    statusCode = 400;
                }
                else if (exception is ApiException)
                {
                    var errorObj = (CustomApiResponse)((ApiException)exception).CustomError;
                    customError = new CustomApiResponse(true, errorObj.Status, errorObj.Message, errorObj.Result);
                    statusCode = errorObj.Status.Value;
                }
                else if (exception.Source.Contains("Cosmos") && ((Microsoft.Azure.Cosmos.CosmosException)exception).StatusCode == System.Net.HttpStatusCode.NotFound)
                {
                    customError = new CustomApiResponse(true, 404, "Server error", new List<string> { "Cosmos error ", "Resource not found" });
                    statusCode = 404;
                }
                else
                {
                    customError = new CustomApiResponse(true, 500, "Server error", new List<string> { "Work Order Unhandled exception occurred on server", exception.Message + " | " + exception.StackTrace });
                    statusCode = 500;
                }

                json = JsonConvert.SerializeObject(customError, new JsonSerializerSettings
                {
                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                });

                await WriteFormattedResponseToHttpContextAsync(context, statusCode, json);
                return json;
            }

            string exceptionMessage = default;
            object apiError;
            int httpStatusCode;

            if (exception is ApiException)
            {
                var ex = exception as ApiException;
                if (ex.IsModelValidatonError)
                {
                    apiError = new ApiError(ResponseMessage.ValidationError, ex.Errors) { ReferenceErrorCode = ex.ReferenceErrorCode, ReferenceDocumentLink = ex.ReferenceDocumentLink };
                }
                else if (ex.IsCustomErrorObject)
                {
                    apiError = ex.CustomError;
                }
                else
                {
                    apiError = new ApiError(ex.Message) { ReferenceErrorCode = ex.ReferenceErrorCode, ReferenceDocumentLink = ex.ReferenceDocumentLink };
                }

                httpStatusCode = ex.StatusCode;
            }
            else if (exception is UnauthorizedAccessException)
            {
                apiError = new ApiError(ResponseMessage.UnAuthorized);
                httpStatusCode = Status401Unauthorized;
            }
            else
            {
                string stackTrace = null;

                if (_options.IsDebug)
                {
                    exceptionMessage = $"{exceptionMessage} {exception.GetBaseException().Message}";
                    stackTrace = exception.StackTrace;
                }
                else
                {
                    exceptionMessage = ResponseMessage.Unhandled;
                }

                apiError = new ApiError(exceptionMessage) { Details = stackTrace };
                httpStatusCode = Status500InternalServerError;
            }


            if (_options.EnableExceptionLogging)
            {
                var errorMessage = apiError is ApiError ? ((ApiError)apiError).ExceptionMessage : ResponseMessage.Exception;
                _logger.Log(LogLevel.Error, exception, $"[{httpStatusCode}]: {errorMessage}");
            }
            var jsonString = ConvertToJSONString(apiError);
            await WriteFormattedResponseToHttpContextAsync(context, httpStatusCode, jsonString);
            return jsonString;
        }

        /// <summary>
        /// handle unsuccessful request as an asynchronous operation.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="body">The body.</param>
        /// <param name="httpStatusCode">The HTTP status code.</param>
        public async Task HandleUnsuccessfulRequestAsync(HttpContext context, object body, int httpStatusCode)
        {
            var (IsEncoded, ParsedText) = body.ToString().VerifyBodyContent();

            if (IsEncoded && _options.UseCustomExceptionFormat)
            {
                await WriteFormattedResponseToHttpContextAsync(context, httpStatusCode, body.ToString());
                return;
            }

            var bodyText = IsEncoded ? JsonConvert.DeserializeObject<dynamic>(ParsedText) : body.ToString();
            ApiError apiError = !string.IsNullOrEmpty(body.ToString()) ? new ApiError(bodyText) : WrapUnsucessfulError(httpStatusCode);
            List<ValidationError> errorList = new List<ValidationError> { new ValidationError("Not Found", apiError.ExceptionMessage.ToString()) };
            CustomApiResponse unSuccessfulRequest = new CustomApiResponse(true, httpStatusCode, "Unsuccessful Request", errorList);
            string jsonString = JsonConvert.SerializeObject(unSuccessfulRequest, new JsonSerializerSettings
            {
                ContractResolver = new CamelCasePropertyNamesContractResolver()
            });
            await WriteFormattedResponseToHttpContextAsync(context, httpStatusCode, jsonString);
        }

        /// <summary>
        /// handle not API request as an asynchronous operation.
        /// </summary>
        /// <param name="context">The context.</param>
        public async Task HandleNotApiRequestAsync(HttpContext context)
        {
            string configErrorText = ResponseMessage.NotApiOnly;
            context.Response.ContentLength = configErrorText != null ? Encoding.UTF8.GetByteCount(configErrorText) : 0;
            await context.Response.WriteAsync(configErrorText);
        }

        /// <summary>
        /// Determines whether the specified context is swagger.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="swaggerPath">The swagger path.</param>
        /// <returns><c>true</c> if the specified context is swagger; otherwise, <c>false</c>.</returns>
        public bool IsSwagger(HttpContext context, string swaggerPath)
        {
            return context.Request.Path.StartsWithSegments(new PathString(swaggerPath));
        }

        /// <summary>
        /// Determines whether the specified context is exclude.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="excludePaths">The exclude paths.</param>
        /// <returns><c>true</c> if the specified context is exclude; otherwise, <c>false</c>.</returns>
        public bool IsExclude(HttpContext context, IEnumerable<FormatterExcludePath> excludePaths)
        {
            if (excludePaths == null || !excludePaths.Any())
            {
                return false;
            }

            return excludePaths.Any(x =>
            {
                switch (x.ExcludeMode)
                {
                    default:
                    case ExcludeMode.Strict:
                        return context.Request.Path.Value == x.Path;
                    case ExcludeMode.StartWith:
                        return context.Request.Path.StartsWithSegments(new PathString(x.Path));
                    case ExcludeMode.Regex:
                        Regex regExclude = new Regex(x.Path);
                        return regExclude.IsMatch(context.Request.Path.Value);
                }
            });
        }

        /// <summary>
        /// Determines whether the specified context is API.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <returns><c>true</c> if the specified context is API; otherwise, <c>false</c>.</returns>
        public bool IsApi(HttpContext context)
        {
            if (_options.IsApiOnly
                && !context.Request.Path.Value.Contains(".js")
                && !context.Request.Path.Value.Contains(".css")
                && !context.Request.Path.Value.Contains(".html"))
                return true;

            return context.Request.Path.StartsWithSegments(new PathString(_options.WrapWhenApiPathStartsWith));
        }

        /// <summary>
        /// wrap ignore as an asynchronous operation.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="body">The body.</param>
        public async Task WrapIgnoreAsync(HttpContext context, object body)
        {
            var bodyText = body.ToString();
            context.Response.ContentLength = bodyText != null ? Encoding.UTF8.GetByteCount(bodyText) : 0;
            await context.Response.WriteAsync(bodyText);
        }

        /// <summary>
        /// handle problem details exception as an asynchronous operation.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="executor">The executor.</param>
        /// <param name="body">The body.</param>
        /// <param name="exception">The exception.</param>
        public async Task HandleProblemDetailsExceptionAsync(HttpContext context, IActionResultExecutor<ObjectResult> executor, object body, Exception exception = null)
        {
            await new ApiProblemDetailsMember().WriteProblemDetailsAsync(context, executor, body, exception, _options.IsDebug);

            if (_options.EnableExceptionLogging && exception != null)
            {
                _logger.Log(LogLevel.Error, exception, $"[{context.Response.StatusCode}]: {exception.GetBaseException().Message}");
            }
        }

        /// <summary>
        /// Determines whether [is request successful] [the specified status code].
        /// </summary>
        /// <param name="statusCode">The status code.</param>
        /// <returns><c>true</c> if [is request successful] [the specified status code]; otherwise, <c>false</c>.</returns>
        public bool IsRequestSuccessful(int statusCode)
        {
            return (statusCode >= 200 && statusCode < 400);
        }

        #region Private Members

        /// <summary>
        /// write formatted response to HTTP context as an asynchronous operation.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="httpStatusCode">The HTTP status code.</param>
        /// <param name="jsonString">The json string.</param>
        private async Task WriteFormattedResponseToHttpContextAsync(HttpContext context, int httpStatusCode, string jsonString)
        {
            context.Response.StatusCode = httpStatusCode;
            context.Response.ContentType = TypeIdentifier.JSONHttpContentMediaType;
            context.Response.ContentLength = jsonString != null ? Encoding.UTF8.GetByteCount(jsonString) : 0;
            await context.Response.WriteAsync(jsonString);


        }

        /// <summary>
        /// Converts to json string.
        /// </summary>
        /// <param name="rawJSON">The raw json.</param>
        /// <returns>System.String.</returns>
        private string ConvertToJSONString(object rawJSON) => JsonConvert.SerializeObject(rawJSON, _jsonSettings);

        /// <summary>
        /// Wraps the unsucessful error.
        /// </summary>
        /// <param name="statusCode">The status code.</param>
        /// <returns>ApiError.</returns>
        private ApiError WrapUnsucessfulError(int statusCode) =>
            statusCode switch
            {
                Status204NoContent => new ApiError(ResponseMessage.NotContent),
                Status400BadRequest => new ApiError(ResponseMessage.BadRequest),
                Status401Unauthorized => new ApiError(ResponseMessage.UnAuthorized),
                Status404NotFound => new ApiError(ResponseMessage.NotFound),
                Status405MethodNotAllowed => new ApiError(ResponseMessage.MethodNotAllowed),
                Status415UnsupportedMediaType => new ApiError(ResponseMessage.MediaTypeNotSupported),
                _ => new ApiError(ResponseMessage.Unknown)

            };
        #endregion
    }
}
