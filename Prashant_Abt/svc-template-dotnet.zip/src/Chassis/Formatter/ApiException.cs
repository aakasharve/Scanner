﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using static Microsoft.AspNetCore.Http.StatusCodes;

namespace Neighborly.Chassis.Formatter
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class ApiException.
    /// Implements the <see cref="System.Exception" />
    /// </summary>
    /// <seealso cref="System.Exception" />
    public class ApiException : System.Exception
    {
        /// <summary>
        /// Gets or sets the status code.
        /// </summary>
        /// <value>The status code.</value>
        public int StatusCode { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is model validaton error.
        /// </summary>
        /// <value><c>true</c> if this instance is model validaton error; otherwise, <c>false</c>.</value>
        public bool IsModelValidatonError { get; set; } = false;
        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>The errors.</value>
        public IEnumerable<ValidationError>? Errors { get; set; }
        /// <summary>
        /// Gets or sets the reference error code.
        /// </summary>
        /// <value>The reference error code.</value>
        public string? ReferenceErrorCode { get; set; }
        /// <summary>
        /// Gets or sets the reference document link.
        /// </summary>
        /// <value>The reference document link.</value>
        public string? ReferenceDocumentLink { get; set; }
        /// <summary>
        /// Gets or sets the custom error.
        /// </summary>
        /// <value>The custom error.</value>
        public object? CustomError { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether this instance is custom error object.
        /// </summary>
        /// <value><c>true</c> if this instance is custom error object; otherwise, <c>false</c>.</value>
        public bool IsCustomErrorObject { get; set; } = false;

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiException"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="statusCode">The status code.</param>
        /// <param name="errorCode">The error code.</param>
        /// <param name="refLink">The reference link.</param>
        public ApiException(string message,
                            int statusCode = Status400BadRequest,
                            string errorCode = default,
                            string refLink = default,
                            Exception ex = null) :
            base(message, ex)
        {
            StatusCode = statusCode;
            ReferenceErrorCode = errorCode;
            ReferenceDocumentLink = refLink;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiException"/> class.
        /// </summary>
        /// <param name="customError">The custom error.</param>
        /// <param name="statusCode">The status code.</param>
        public ApiException(object customError, int statusCode = Status400BadRequest, Exception? ex = null) :
            base(ex != null ? ex.Message : "customError : " + customError != null ? customError.GetType().ToString() : "", ex)
        {
            IsCustomErrorObject = true;
            StatusCode = statusCode;
            CustomError = customError;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiException"/> class.
        /// </summary>
        /// <param name="errors">The errors.</param>
        /// <param name="statusCode">The status code.</param>
        public ApiException(IEnumerable<ValidationError> errors, int statusCode = Status400BadRequest, Exception? ex = null) : base(ex != null ? ex.Message : "Errors", ex)
        {
            IsModelValidatonError = true;
            StatusCode = statusCode;
            Errors = errors;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiException"/> class.
        /// </summary>
        /// <param name="ex">The ex.</param>
        /// <param name="statusCode">The status code.</param>
        public ApiException(System.Exception ex, int statusCode = Status500InternalServerError) : base(ex.Message, ex)
        {
            StatusCode = statusCode;
        }

    }
}
