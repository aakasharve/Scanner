﻿
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Neighborly.Chassis.Logging;
using System;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Threading.Tasks;

using static Microsoft.AspNetCore.Http.StatusCodes;

namespace Neighborly.Chassis.Formatter
{

    /// <summary>
    /// Class FormatterBase.
    /// </summary>
    [ExcludeFromCodeCoverage]
    internal abstract class FormatterBase
    {
        /// <summary>
        /// The next
        /// </summary>
        private readonly RequestDelegate _next;
        /// <summary>
        /// The options
        /// </summary>
        private readonly FormatterOptions _options;
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<FormatterMiddleware> _logger;
        /// <summary>
        /// Serilog  Logger
        /// </summary>
        private readonly Serilog.ILogger _serilogLogger;
#pragma warning disable IDE1006 
        /// <summary>
        /// Gets the executor.
        /// </summary>
        /// <value>The executor.</value>
        private IActionResultExecutor<ObjectResult> _executor { get; }
#pragma warning restore IDE1006 
        /// <summary>
        /// LoggerOptions
        /// </summary>
        private readonly LoggerOptions _loggerOptions;
        /// <summary>
        /// Initializes a new instance of the <see cref="FormatterBase"/> class.
        /// </summary>
        /// <param name="next">The next.</param>
        /// <param name="options">The options.</param>
        /// <param name="logger">The logger.</param>
        /// <param name="executor">The executor.</param>
        /// <param name="serilogLogger">The executor.</param>
        /// <param name="loggerOptions">The executor.</param>
        protected FormatterBase(RequestDelegate next,
                          FormatterOptions options,
                          ILogger<FormatterMiddleware> logger,
                          IActionResultExecutor<ObjectResult> executor,
                          Serilog.ILogger serilogLogger,
                          IOptions<LoggerOptions> loggerOptions
                          )
        {
            _next = next;
            _options = options;
            _logger = logger;
            _executor = executor;
            _serilogLogger = serilogLogger;
            _loggerOptions = loggerOptions.Value;
        }

        /// <summary>
        /// Invokes the asynchronous base.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="awm">The awm.</param>
        public virtual async Task InvokeAsyncBase(HttpContext context, FormatterMembers awm)
        {
            string customError = string.Empty;
            if (awm.IsSwagger(context, _options.SwaggerPath) || !awm.IsApi(context) || awm.IsExclude(context, _options.ExcludePaths))
                await _next(context);
            else
            {
                var stopWatch = Stopwatch.StartNew();
                var requestBody = await awm.GetRequestBodyAsync(context.Request);
                var originalResponseBodyStream = context.Response.Body;
                bool isRequestOk = false;

                using var memoryStream = new MemoryStream();

                try
                {
                    context.Response.Body = memoryStream;
                    await _next.Invoke(context);

                    if (context.Response.HasStarted) { LogResponseHasStartedError(); return; }

                    var endpoint = context.GetEndpoint();
                    if (endpoint?.Metadata?.GetMetadata<AutoWrapIgnoreAttribute>() is object)
                    {
                        await awm.RevertResponseBodyStreamAsync(memoryStream, originalResponseBodyStream);
                        return;
                    }

                    var bodyAsText = await awm.ReadResponseBodyStreamAsync(memoryStream);
                    context.Response.Body = originalResponseBodyStream;

                    if (context.Response.StatusCode != Status304NotModified && context.Response.StatusCode != Status204NoContent)
                    {

                        if (!_options.IsApiOnly
                            && (bodyAsText.IsHtml()
                            && !_options.BypassHTMLValidation)
                            && context.Response.StatusCode == Status200OK)
                        { context.Response.StatusCode = Status404NotFound; }

                        if (!context.Request.Path.StartsWithSegments(new PathString(_options.WrapWhenApiPathStartsWith))
                            && (bodyAsText.IsHtml()
                            && !_options.BypassHTMLValidation)
                            && context.Response.StatusCode == Status200OK)
                        {
                            if (memoryStream.Length > 0) { await awm.HandleNotApiRequestAsync(context); }
                            return;
                        }

                        isRequestOk = awm.IsRequestSuccessful(context.Response.StatusCode);
                        if (isRequestOk)
                        {

                            await awm.WrapIgnoreAsync(context, bodyAsText);

                        }
                        else
                        {
                            if (_options.UseApiProblemDetailsException)
                            {
                                await awm.HandleProblemDetailsExceptionAsync(context, _executor, bodyAsText);
                                return;
                            }

                            await awm.HandleUnsuccessfulRequestAsync(context, bodyAsText, context.Response.StatusCode);
                        }
                    }

                }
                catch (Exception exception)
                {
                    if (context.Response.HasStarted) { LogResponseHasStartedError(); return; }

                    if (_options.UseApiProblemDetailsException)
                    {
                        await awm.HandleProblemDetailsExceptionAsync(context, _executor, null, exception);
                    }
                    else
                    {
                        customError = await awm.HandleExceptionAsync(context, exception);
                    }

                    await awm.RevertResponseBodyStreamAsync(memoryStream, originalResponseBodyStream);
                }
                finally
                {
                    LogHttpRequest(context, requestBody, stopWatch, isRequestOk, customError);
                }
            }
        }

        /// <summary>
        /// Shoulds the log request data.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        private bool ShouldLogRequestData(HttpContext context)
        {
            if (_options.ShouldLogRequestData)
            {
                var endpoint = context.GetEndpoint();
                return !(endpoint?.Metadata?.GetMetadata<RequestDataLogIgnoreAttribute>() is object);
            }

            return false;
        }

        /// <summary>
        /// Logs the HTTP request.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="requestBody">The request body.</param>
        /// <param name="stopWatch">The stop watch.</param>
        /// <param name="isRequestOk">if set to <c>true</c> [is request ok].</param>
        private void LogHttpRequest(HttpContext context, string requestBody, Stopwatch stopWatch, bool isRequestOk, string customError)
        {
            stopWatch.Stop();
            if (_options.EnableResponseLogging)
            {
                bool shouldLogRequestData = ShouldLogRequestData(context);

                var request = shouldLogRequestData
                            ? isRequestOk
                                ? $"{context.Request.Method} {context.Request.Scheme} {context.Request.Host}{context.Request.Path} {context.Request.QueryString} {requestBody}"
                                : (!isRequestOk && _options.LogRequestDataOnException)
                                   ? $"{context.Request.Method} {context.Request.Scheme} {context.Request.Host}{context.Request.Path} {context.Request.QueryString} {requestBody}"
                                   : $"{context.Request.Method} {context.Request.Scheme} {context.Request.Host}{context.Request.Path}"
                            : $"{context.Request.Method} {context.Request.Scheme} {context.Request.Host}{context.Request.Path}";
                GenerateMessage(context, stopWatch, request, customError);
            }
        }

        private void GenerateMessage(HttpContext context, Stopwatch stopWatch, string request, string customError)
        {
            if (context.Response.StatusCode != StatusCodes.Status200OK)
            {
                if (!string.IsNullOrEmpty(customError) && customError.Contains("\"isError\":true"))
                    _serilogLogger.Error(customError);
                string msg = $"Source:[{context.Connection.RemoteIpAddress}] \n" +
                                                  $"Request: \n {request} \n" +
                                                   $"Custom Response : \n {customError} \n" +
                                                  $"Responded with [{context.Response.StatusCode}] in {stopWatch.ElapsedMilliseconds}ms \n";
                switch (_loggerOptions.RequestPayloadLevel)
                {
                    case "Information":
                        _serilogLogger.Information(msg);
                        break;
                    case "Debug":
                        _serilogLogger.Debug(msg);
                        break;
                    default:
                        _serilogLogger.Verbose(msg);
                        break;

                }
            }
        }

        /// <summary>
        /// Logs the response has started error.
        /// </summary>
        private void LogResponseHasStartedError()
        {
            _logger.Log(LogLevel.Warning, "The response has already started, the Formatter middleware will not be executed.");
        }
    }
}
