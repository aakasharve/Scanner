﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Neighborly.Chassis.Logging;
using System.Diagnostics.CodeAnalysis;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Formatter
{

    /// <summary>
    /// Class FormatterMiddleware.
    /// Implements the <see cref="Neighborly.Chassis.Formatter.FormatterBase" />
    /// </summary>
    /// <seealso cref="Neighborly.Chassis.Formatter.FormatterBase" />
    [ExcludeFromCodeCoverage]
    internal class FormatterMiddleware : FormatterBase
    {
        /// <summary>
        /// The awm
        /// </summary>
        private readonly FormatterMembers _awm;
        /// <summary>
        /// Initializes a new instance of the <see cref="FormatterMiddleware"/> class.
        /// </summary>
        /// <param name="next"></param>
        /// <param name="options"></param>
        /// <param name="logger"></param>
        /// <param name="executor"></param>
        /// <param name="_serilogLogger"></param>
        /// <param name="loggerOptions"></param>
        public FormatterMiddleware(RequestDelegate next, FormatterOptions options,
            ILogger<FormatterMiddleware> logger,
            IActionResultExecutor<ObjectResult> executor, Serilog.ILogger _serilogLogger, IOptions<LoggerOptions> loggerOptions
            ) : base(next, options, logger, executor, _serilogLogger, loggerOptions)
        {
            var jsonSettings = JSONHelper.GetJSONSettings(options.IgnoreNullValue, options.ReferenceLoopHandling, options.UseCamelCaseNamingStrategy);
            _awm = new FormatterMembers(options, logger, jsonSettings);
        }

        /// <summary>
        /// invoke as an asynchronous operation.
        /// </summary>
        /// <param name="context">The context.</param>
        public async Task InvokeAsync(HttpContext context)
        {
            await InvokeAsyncBase(context, _awm);
        }
    }

    /// <summary>
    /// Class FormatterMiddleware.
    /// Implements the <see cref="Neighborly.Chassis.Formatter.FormatterBase" />
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <seealso cref="Neighborly.Chassis.Formatter.FormatterBase" />
    [ExcludeFromCodeCoverage]
    internal class FormatterMiddleware<T> : FormatterBase
    {
        /// <summary>
        /// The awm
        /// </summary>
        private readonly FormatterMembers _awm;
        /// <summary>
        /// Initializes a new instance of the <see cref="FormatterMiddleware{T}"/> class.
        /// </summary>
        /// <param name="next"></param>
        /// <param name="options"></param>
        /// <param name="logger"></param>
        /// <param name="executor"></param>
        /// <param name="serilogLogger"></param>
        /// <param name="loggerOptions"></param>
        public FormatterMiddleware(RequestDelegate next, FormatterOptions options, ILogger<FormatterMiddleware> logger, IActionResultExecutor<ObjectResult> executor, Serilog.ILogger serilogLogger, IOptions<LoggerOptions> loggerOptions) : base(next, options, logger, executor, serilogLogger, loggerOptions)
        {
            var (Settings, Mappings) = JSONHelper.GetJSONSettings<T>(options.IgnoreNullValue, options.ReferenceLoopHandling, options.UseCamelCaseNamingStrategy);
            _awm = new FormatterMembers(options, logger, Settings, Mappings);
        }

        /// <summary>
        /// invoke as an asynchronous operation.
        /// </summary>
        /// <param name="context">The context.</param>
        public async Task InvokeAsync(HttpContext context)
        {
            await InvokeAsyncBase(context, _awm);
        }

    }
}
