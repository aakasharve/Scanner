﻿namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class TypeIdentifier.
    /// </summary>
    internal class TypeIdentifier
    {
        /// <summary>
        /// The json HTTP content media type
        /// </summary>
        internal const string JSONHttpContentMediaType = "application/json";
        /// <summary>
        /// The problem json HTTP content media type
        /// </summary>
        internal const string ProblemJSONHttpContentMediaType = "application/problem+json";
        /// <summary>
        /// The problem XML HTTP content media type
        /// </summary>
        internal const string ProblemXMLHttpContentMediaType = "application/problem+xml";
    }
}
