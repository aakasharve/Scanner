﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Reflection;


namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class CustomContractResolver.
    /// Implements the <see cref="Newtonsoft.Json.Serialization.DefaultContractResolver" />
    /// </summary>
    /// <typeparam name="T"></typeparam>
    /// <seealso cref="Newtonsoft.Json.Serialization.DefaultContractResolver" />
    [ExcludeFromCodeCoverage]
    public class CustomContractResolver<T> : DefaultContractResolver
    {
        /// <summary>
        /// Gets or sets the property mappings.
        /// </summary>
        /// <value>The property mappings.</value>
        public Dictionary<string, string> _propertyMappings { get; set; }
        /// <summary>
        /// The use camel case naming
        /// </summary>
        private readonly bool _useCamelCaseNaming;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomContractResolver{T}"/> class.
        /// </summary>
        /// <param name="useCamelCaseNaming">if set to <c>true</c> [use camel case naming].</param>
        public CustomContractResolver(bool useCamelCaseNaming)
        {
            _propertyMappings = new Dictionary<string, string>();
            _useCamelCaseNaming = useCamelCaseNaming;
            SetObjectMappings();
        }

        /// <summary>
        /// Resolves the name of the property.
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        /// <returns>Resolved name of the property.</returns>
        protected override string ResolvePropertyName(string propertyName)
        {
            var resolved = _propertyMappings.TryGetValue(propertyName, out string? resolvedName);

            if (_useCamelCaseNaming)
                return (resolved) ? resolvedName?.ToCamelCase() ?? string.Empty : base.ResolvePropertyName(propertyName.ToCamelCase());

            return (resolved) ? resolvedName ?? string.Empty : base.ResolvePropertyName(propertyName);
        }

        /// <summary>
        /// Creates a <see cref="T:Newtonsoft.Json.Serialization.JsonProperty" /> for the given <see cref="T:System.Reflection.MemberInfo" />.
        /// </summary>
        /// <param name="member">The member to create a <see cref="T:Newtonsoft.Json.Serialization.JsonProperty" /> for.</param>
        /// <param name="memberSerialization">The member's parent <see cref="T:Newtonsoft.Json.MemberSerialization" />.</param>
        /// <returns>A created <see cref="T:Newtonsoft.Json.Serialization.JsonProperty" /> for the given <see cref="T:System.Reflection.MemberInfo" />.</returns>
        protected override JsonProperty CreateProperty(MemberInfo member, MemberSerialization memberSerialization)
        {
            var prop = base.CreateProperty(member, memberSerialization);

            return prop;
        }

        /// <summary>
        /// Sets the object mappings.
        /// </summary>
        private void SetObjectMappings()
        {
            SetObjectMappings(typeof(T));
        }

        /// <summary>
        /// Sets the object mappings.
        /// </summary>
        /// <param name="classType">Type of the class.</param>
        private void SetObjectMappings(Type classType)
        {
            foreach (PropertyInfo propertyInfo in classType.GetProperties(BindingFlags.DeclaredOnly | BindingFlags.Public | BindingFlags.Instance))
            {

                var wrapperProperty = propertyInfo.GetCustomAttribute<FormatterPropertyMapAttribute>();
                if (wrapperProperty != null)
                {
                    _propertyMappings.Add(wrapperProperty.PropertyName, propertyInfo.Name);
                }

                var type = propertyInfo.PropertyType;
                if (type.IsClass)
                    SetObjectMappings(propertyInfo.PropertyType);
            }
        }

    }
}
