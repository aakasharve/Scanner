﻿using Microsoft.AspNetCore.Mvc;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class ApiProblemDetailsExceptionResponse.
    /// Implements the <see cref="Microsoft.AspNetCore.Mvc.ProblemDetails" />
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ProblemDetails" />
    public class ApiProblemDetailsExceptionResponse : ProblemDetails
    {
        /// <summary>
        /// Gets or sets a value indicating whether this instance is error.
        /// </summary>
        /// <value><c>true</c> if this instance is error; otherwise, <c>false</c>.</value>
        public bool IsError { get; set; }
        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>The errors.</value>
        public ErrorDetails Errors { get; set; } = default!;
        /// <summary>
        /// Class ErrorDetails.
        /// </summary>
        public class ErrorDetails
        {
            /// <summary>
            /// Gets or sets the message.
            /// </summary>
            /// <value>The message.</value>
            public string? Message { get; set; }
            /// <summary>
            /// Gets or sets the type.
            /// </summary>
            /// <value>The type.</value>
            public string? Type { get; set; }
            /// <summary>
            /// Gets or sets the source.
            /// </summary>
            /// <value>The source.</value>
            public string? Source { get; set; }
            /// <summary>
            /// Gets or sets the raw.
            /// </summary>
            /// <value>The raw.</value>
            public string? Raw { get; set; }
        }
    }
}
