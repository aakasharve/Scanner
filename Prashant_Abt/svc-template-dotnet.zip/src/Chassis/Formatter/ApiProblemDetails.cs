﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using static Neighborly.Chassis.Formatter.ApiProblemDetailsMember;

[assembly: InternalsVisibleTo("Template-Service-Test")]
namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class ApiProblemDetails.
    /// Implements the <see cref="Microsoft.AspNetCore.Mvc.ProblemDetails" />
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ProblemDetails" />
    internal class ApiProblemDetails : ProblemDetails
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ApiProblemDetails"/> class.
        /// </summary>
        /// <param name="statusCode">The status code.</param>
        public ApiProblemDetails(int statusCode)
        {
            IsError = true;
            Status = statusCode;
            Type = $"https://httpstatuses.com/{statusCode}";
            Title = ReasonPhrases.GetReasonPhrase(statusCode);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiProblemDetails"/> class.
        /// </summary>
        /// <param name="details">The details.</param>
        public ApiProblemDetails(ProblemDetails details)
        {
            IsError = true;
            Details = details;
        }

        /// <summary>
        /// Gets or sets a value indicating whether this instance is error.
        /// </summary>
        /// <value><c>true</c> if this instance is error; otherwise, <c>false</c>.</value>
        [JsonProperty(Order = -2)]
        public bool IsError { get; set; }
        /// <summary>
        /// Gets or sets the errors.
        /// </summary>
        /// <value>The errors.</value>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore, Order = 1)]
        public ErrorDetails Errors { get; set; } = default!;
        /// <summary>
        /// Gets or sets the validation errors.
        /// </summary>
        /// <value>The validation errors.</value>
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore, Order = 1)]
        public IEnumerable<ValidationError> ValidationErrors { get; set; } = default!;
        /// <summary>
        /// Gets or sets the details.
        /// </summary>
        /// <value>The details.</value>
        [JsonIgnore]
        public ProblemDetails Details { get; set; } = null!;
    }
}
