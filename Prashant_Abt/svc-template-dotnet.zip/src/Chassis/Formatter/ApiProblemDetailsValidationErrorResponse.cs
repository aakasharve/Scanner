﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class ApiProblemDetailsValidationErrorResponse.
    /// Implements the <see cref="Microsoft.AspNetCore.Mvc.ProblemDetails" />
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ProblemDetails" />
    public class ApiProblemDetailsValidationErrorResponse : ProblemDetails
    {
        /// <summary>
        /// Gets or sets a value indicating whether this instance is error.
        /// </summary>
        /// <value><c>true</c> if this instance is error; otherwise, <c>false</c>.</value>
        public bool IsError { get; set; }
        /// <summary>
        /// Gets or sets the validation errors.
        /// </summary>
        /// <value>The validation errors.</value>
        public IEnumerable<ValidationError>? ValidationErrors { get; set; }
    }
}
