﻿using System.Collections.Generic;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class ApiError.
    /// </summary>
    public class ApiError
    {
        /// <summary>
        /// Gets or sets the exception message.
        /// </summary>
        /// <value>The exception message.</value>
        public object ExceptionMessage { get; set; }
        /// <summary>
        /// Gets or sets the details.
        /// </summary>
        /// <value>The details.</value>
        public string? Details { get; set; }
        /// <summary>
        /// Gets or sets the reference error code.
        /// </summary>
        /// <value>The reference error code.</value>
        public string? ReferenceErrorCode { get; set; }
        /// <summary>
        /// Gets or sets the reference document link.
        /// </summary>
        /// <value>The reference document link.</value>
        public string? ReferenceDocumentLink { get; set; }
        /// <summary>
        /// Gets or sets the validation errors.
        /// </summary>
        /// <value>The validation errors.</value>
        public IEnumerable<ValidationError> ValidationErrors { get; set; }
        /// <summary>
        /// Initializes a new instance of the <see cref="ApiError"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        public ApiError(object message)
        {
            ExceptionMessage = message;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="ApiError"/> class.
        /// </summary>
        /// <param name="message">The message.</param>
        /// <param name="validationErrors">The validation errors.</param>
        public ApiError(string message, IEnumerable<ValidationError> validationErrors)
        {
            ExceptionMessage = message;
            ValidationErrors = validationErrors;
        }
    }
}
