﻿namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// Class ResponseMessage.
    /// </summary>
    internal class ResponseMessage
    {
        /// <summary>
        /// The success
        /// </summary>
        internal const string Success = "Request successful.";
        /// <summary>
        /// The not found
        /// </summary>
        internal const string NotFound = "Request not found. The specified uri does not exist.";
        /// <summary>
        /// The bad request
        /// </summary>
        internal const string BadRequest = "Request invalid.";
        /// <summary>
        /// The method not allowed
        /// </summary>
        internal const string MethodNotAllowed = "Request responded with 'Method Not Allowed'.";
        /// <summary>
        /// The not content
        /// </summary>
        internal const string NotContent = "Request no content. The specified uri does not contain any content.";
        /// <summary>
        /// The exception
        /// </summary>
        internal const string Exception = "Request responded with exceptions.";
        /// <summary>
        /// The un authorized
        /// </summary>
        internal const string UnAuthorized = "Request denied. Unauthorized access.";
        /// <summary>
        /// The validation error
        /// </summary>
        internal const string ValidationError = "Request responded with one or more validation errors.";
        /// <summary>
        /// The unknown
        /// </summary>
        internal const string Unknown = "Request cannot be processed. Please contact support.";
        /// <summary>
        /// The unhandled
        /// </summary>
        internal const string Unhandled = "Unhandled Exception occurred. Unable to process the request.";
        /// <summary>
        /// The media type not supported
        /// </summary>
        internal const string MediaTypeNotSupported = "Unsupported Media Type.";
        /// <summary>
        /// The not API only
        /// </summary>
        internal const string NotApiOnly = @"HTML detected in the response body.
If you are combining API Controllers within your front-end projects like Angular, MVC, React, Blazor and other SPA frameworks that supports .NET Core, then set the FormatterOptions IsApiOnly property to false. 
If you are using pure API and want to output HTML as part of your JSON object, then set BypassHTMLValidation property to true.";
        /// <summary>
        /// The no mapping found
        /// </summary>
        internal const string NoMappingFound = "You must apply the [FormatterPropertyMap] Attribute to map through the default ApiResponse properties. If you want to to define your own custom response,  set UseCustomSchema = true in the Formatter options.";
    }
}
