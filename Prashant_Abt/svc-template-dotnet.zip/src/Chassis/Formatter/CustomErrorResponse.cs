﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text.Json.Serialization;

namespace Neighborly.Chassis.Formatter
{
    /// <summary>
    /// CustomErrorResponse
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CustomErrorResponse
    {
        /// <summary>
        /// Extensions
        /// </summary>
        [JsonExtensionData]
        public IDictionary<string, object>? Extensions { get; }

        /// <summary>
        /// Instance
        /// </summary>
        [JsonPropertyName("instance")]
        public string? Instance { get; set; }

        /// <summary>
        /// Status
        /// </summary>
        [JsonPropertyName("status")]
        public int? Status { get; set; }

        /// <summary>
        /// Title
        /// </summary>
        [JsonPropertyName("title")]
        public string? Title { get; set; }

        /// <summary>
        /// Type
        /// </summary>
        [JsonPropertyName("type")]
        public string? Type { get; set; }

        /// <summary>
        /// Detail
        /// </summary>
        public IEnumerable<string>? Detail { get; set; }
    }
}
