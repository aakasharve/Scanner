﻿namespace Neighborly.Chassis
{
    /// <summary>
    /// Interface IServiceId
    /// </summary>
    public interface INeighborlyService
    {
        /// <summary>
        /// Gets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        string Id { get; }
    }
}