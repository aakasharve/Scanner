﻿using Neighborly.Chassis.Formatter;
using Neighborly.Service;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.Linq;
using TimeZoneConverter;
namespace Neighborly.Chassis.Helper
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class DateTimeUtilities
    /// </summary>
    public static class DateTimeUtilities
    {
        /// <summary>
        /// ConvertDateTimeToEpoch
        /// </summary>
        /// <param name="utcNow"></param>
        /// <returns></returns>
        public static long ConvertDateTimeToEpoch(DateTime utcNow)
        {
            TimeSpan t = utcNow - new DateTime(1970, 1, 1);
            long secondsSinceEpoch = (long)t.TotalSeconds;
            return secondsSinceEpoch;
        }

        /// <summary>
        /// ConvertEpochToDateTime
        /// </summary>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public static DateTime ConvertEpochToDateTime(long timestamp)
        {
            try
            {
                DateTime start = new DateTime(1970, 1, 1, 0, 0, 0, 0); //from start epoch time
                start = start.AddSeconds(timestamp);
                return start;
            }
            catch (Exception ex)
            {
                CustomApiResponse customError = new CustomApiResponse(true, 404, "Exception occurred", new List<ValidationError> { new ValidationError("Invalid input", "Input epoch timestamp is invalid") });
                throw new Chassis.Formatter.ApiException(customError, 404, ex);
            }

        }

        /// <summary>
        /// ConvertEpochToSpecificTimeZone
        /// </summary>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public static DateTime? ConvertEpochToSpecificTimeZone(long timestamp, string? timeZone = Constants.DEFAULT_TIMEZONE)
        {
            try
            {
                var timeUtc = ConvertEpochToDateTime(timestamp);
                TimeZoneInfo zone = TZConvert.GetTimeZoneInfo(string.IsNullOrEmpty(timeZone) ? Constants.DEFAULT_TIMEZONE : timeZone);
                return TimeZoneInfo.ConvertTimeFromUtc(timeUtc, zone);
            }
            catch (TimeZoneNotFoundException)
            {
                CustomApiResponse customError = new CustomApiResponse(true, 500, "Exception occurred", new List<ValidationError> { new ValidationError("Invoice", "Invalid Time Zone Exception") });
                throw new Chassis.Formatter.ApiException(customError, 500);
            }
            catch (Exception ex)
            {
                CustomApiResponse customError = new CustomApiResponse(true, 500, "Exception occurred", new List<ValidationError> { new ValidationError("Invoice", "Exception converting Epoch To Specific Time Zone") });
                throw new Chassis.Formatter.ApiException(customError, 500, ex);
            }
        }


        /// <summary>
        /// ConvertEpochToSpecificTimeZone
        /// </summary>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public static DateTime GetDaylightSavingTime(DateTime timestamp, string? timeZone = Constants.DEFAULT_TIMEZONE)
        {
            try
            {
                TimeZoneInfo zone = TZConvert.GetTimeZoneInfo(string.IsNullOrEmpty(timeZone) ? Constants.DEFAULT_TIMEZONE : timeZone);
                if (zone.IsDaylightSavingTime(timestamp))
                    return timestamp.AddHours(-1);
                else
                    return timestamp;
            }
            catch (TimeZoneNotFoundException)
            {
                CustomApiResponse customError = new CustomApiResponse(true, 500, "Exception occurred", new List<ValidationError> { new ValidationError("Invoice", "Invalid Time Zone Exception") });
                throw new Chassis.Formatter.ApiException(customError, 500);
            }
            catch (Exception ex)
            {
                CustomApiResponse customError = new CustomApiResponse(true, 500, "Exception occurred", new List<ValidationError> { new ValidationError("Invoice", "Exception converting Epoch To Specific Time Zone") });
                throw new Chassis.Formatter.ApiException(customError, 500, ex);
            }
        }
        /// <summary>
        /// ConvertEpochToSpecificTimeZone
        /// </summary>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public static bool CheckDayLightSaving(DateTime timestamp, string? timeZone = Constants.DEFAULT_TIMEZONE)
        {
            try
            {
                TimeZoneInfo zone = TZConvert.GetTimeZoneInfo(string.IsNullOrEmpty(timeZone) ? Constants.DEFAULT_TIMEZONE : timeZone);
                return zone.IsDaylightSavingTime(timestamp);
            }
            catch (TimeZoneNotFoundException)
            {
                CustomApiResponse customError = new CustomApiResponse(true, 500, "Exception occurred", new List<ValidationError> { new ValidationError("Invoice", "Invalid Time Zone Exception") });
                throw new Chassis.Formatter.ApiException(customError, 500);
            }
            catch (Exception ex)
            {
                CustomApiResponse customError = new CustomApiResponse(true, 500, "Exception occurred", new List<ValidationError> { new ValidationError("Invoice", "Exception converting Epoch To Specific Time Zone") });
                throw new Chassis.Formatter.ApiException(customError, 500, ex);
            }
        }
        /// <summary>
        /// Convert In UTC
        /// </summary>
        /// <param name="timestamp"></param>
        /// <returns></returns>
        public static DateTime ConvertDateToSpecificUTC(DateTime timestamp, string? timeZone = Constants.DEFAULT_TIMEZONE)
        {
            try
            {
                TimeZoneInfo zone = TZConvert.GetTimeZoneInfo(string.IsNullOrEmpty(timeZone) ? Constants.DEFAULT_TIMEZONE : timeZone);
                return TimeZoneInfo.ConvertTimeToUtc(timestamp, zone);
            }
            catch (TimeZoneNotFoundException)
            {
                CustomApiResponse customError = new CustomApiResponse(true, 500, "Exception occurred", new List<ValidationError> { new ValidationError("Invoice", "Invalid Time Zone Exception") });
                throw new Chassis.Formatter.ApiException(customError, 500);
            }
            catch (Exception ex)
            {
                CustomApiResponse customError = new CustomApiResponse(true, 500, "Exception occurred", new List<ValidationError> { new ValidationError("Invoice", "Exception converting Epoch To Specific Time Zone") });
                throw new Chassis.Formatter.ApiException(customError, 500, ex);
            }
        }

        public static DayLightSavingTime GetTransitonTime(string? timeZone)
        {
            DayLightSavingTime ret = new DayLightSavingTime();

            var adjustmentRules = TZConvert.GetTimeZoneInfo(string.IsNullOrEmpty(timeZone) ? Constants.DEFAULT_TIMEZONE : timeZone).GetAdjustmentRules();

            if (adjustmentRules.Length > 0) // True in local and Server
            {
                //Valid in Local and Server, will get two different result
                var nearestRule = adjustmentRules.Where(r => r.DateStart.Year <= DateTime.Today.Year &&
                                                             r.DateEnd.Year >= DateTime.Today.Year)
                                                 .OrderBy(r => r.DateStart)
                                                 .FirstOrDefault();
                // local - 2007 to 9999
                //server - 2021-11-07T00:00:00 - 2022-03-13T00:00:00                    
                if (nearestRule != null)
                {
                    ret.DayLightDelta = nearestRule.DaylightDelta.Hours;
                    var lastRule = adjustmentRules.Where(r => r.DateStart >= nearestRule.DateEnd).OrderBy(r => r.DateStart).FirstOrDefault();
                    //lastRule - only in server 2022-03-13T00:00:00 - 2022-11-06T00:00:00

                    if (nearestRule.DaylightTransitionStart.IsFixedDateRule)//true server
                    {
                        if (lastRule != null) // server - true
                        {
                            ret.DayLightSavingStartDay = DisplayTransitionInfo(lastRule.DaylightTransitionStart, DateTime.Today.Year);
                            ret.DayLightDelta = lastRule.DaylightDelta.Hours;
                        }
                        else
                        {
                            ret.DayLightSavingStartDay = DisplayTransitionInfo(nearestRule.DaylightTransitionStart, DateTime.Today.Year);  // local  
                        }
                    }
                    else // local
                    {

                        ret.DayLightSavingStartDay = DisplayTransitionInfo(nearestRule.DaylightTransitionStart, DateTime.Today.Year);
                    }

                    if (nearestRule.DaylightTransitionEnd.IsFixedDateRule) // true server
                    {

                        DateTime dtsDT;
                        ret.DayLightSavingEndDay = DisplayTransitionInfo(nearestRule.DaylightTransitionEnd, DateTime.Today.Year); // 2022-03-13T01:59:59

                        if (ret.DayLightSavingStartDay > ret.DayLightSavingEndDay) // true
                        {
                            if (lastRule != null)
                            {

                                dtsDT = DisplayTransitionInfo(lastRule.DaylightTransitionEnd, lastRule.DateStart.Year);
                            }
                            else
                            {

                                dtsDT = DisplayTransitionInfo(nearestRule.DaylightTransitionEnd, DateTime.Today.Year + 1);
                            }
                            ret.DayLightSavingEndDay = dtsDT;
                        }
                    }
                    else // local
                    {
                        DateTime dtsDT;
                        ret.DayLightSavingEndDay = DisplayTransitionInfo(nearestRule.DaylightTransitionEnd, DateTime.Today.Year);
                        if (ret.DayLightSavingEndDay < ret.DayLightSavingStartDay)
                        {
                            if (lastRule != null)
                            {
                                dtsDT = DisplayTransitionInfo(lastRule.DaylightTransitionEnd, lastRule.DateStart.Year);
                            }
                            else
                            {
                                dtsDT = DisplayTransitionInfo(nearestRule.DaylightTransitionEnd, DateTime.Today.Year + 1);
                            }
                            ret.DayLightSavingEndDay = dtsDT;
                        }
                    }

                }
                else
                    ret.DayLightDelta = 0;
            }
            return ret;
        }

        public static DateTime DisplayTransitionInfo(TimeZoneInfo.TransitionTime transitionTime, int year)
        {
            if (transitionTime.IsFixedDateRule)
            {
                return new DateTime(year,
                          transitionTime.Month,
                          transitionTime.Day,
                          transitionTime.TimeOfDay.Hour,
                          transitionTime.TimeOfDay.Minute,
                          transitionTime.TimeOfDay.Second);
            }
            else
            {
                Calendar cal = CultureInfo.CurrentCulture.Calendar;

                int startOfWeek = transitionTime.Week * 7 - 6;
                int firstDayOfWeek = (int)cal.GetDayOfWeek(new DateTime(year, transitionTime.Month, 1));

                int transitionDay;
                int changeDayOfWeek = (int)transitionTime.DayOfWeek;

                if (firstDayOfWeek <= changeDayOfWeek)
                    transitionDay = startOfWeek + (changeDayOfWeek - firstDayOfWeek);
                else
                    transitionDay = startOfWeek + (7 - firstDayOfWeek + changeDayOfWeek);

                if (transitionDay > cal.GetDaysInMonth(year, transitionTime.Month))
                    transitionDay -= 7;
                return new DateTime(year, transitionTime.Month,
                                           transitionDay,
                                           transitionTime.TimeOfDay.Hour,
                                           transitionTime.TimeOfDay.Minute,
                                           transitionTime.TimeOfDay.Second);
            }

        }

    }
    public class DayLightSavingTime
    {
        public DateTime DayLightSavingStartDay { get; set; }
        public DateTime DayLightSavingEndDay { get; set; }
        public int DayLightDelta { get; set; }
    }
}
