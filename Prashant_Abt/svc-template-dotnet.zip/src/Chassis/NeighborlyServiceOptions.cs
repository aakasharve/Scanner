﻿namespace Neighborly.Chassis
{
    /// <summary>
    /// Class NeighborlyServiceOptions.
    /// </summary>
    public sealed class NeighborlyServiceOptions
    {
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; }
        /// <summary>
        /// Gets or sets the service.
        /// </summary>
        /// <value>The service.</value>
        public string Description { get; set; }
        /// <summary>
        /// Gets or sets the instance.
        /// </summary>
        /// <value>The instance.</value>
        public string Instance { get; set; }
        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>The version.</value>
        public string Version { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [display banner].
        /// </summary>
        /// <value><c>true</c> if [display banner]; otherwise, <c>false</c>.</value>
        public bool DisplayBanner { get; set; } = true;
        /// <summary>
        /// Gets or sets a value indicating whether [display version].
        /// </summary>
        /// <value><c>true</c> if [display version]; otherwise, <c>false</c>.</value>
        public bool DisplayVersion { get; set; } = true;
    }
}