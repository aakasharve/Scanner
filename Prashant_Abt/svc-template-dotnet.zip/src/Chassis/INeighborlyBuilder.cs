﻿using Microsoft.Extensions.DependencyInjection;
using System;

namespace Neighborly.Chassis
{
    /// <summary>
    /// Interface INeighborlyBuilder
    /// </summary>
    public interface INeighborlyBuilder
    {
        /// <summary>
        /// Gets the services.
        /// </summary>
        /// <value>The services.</value>
        IServiceCollection Services { get; }
        /// <summary>
        /// Tries the register.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns><c>true</c> if XXXX, <c>false</c> otherwise.</returns>
        bool TryRegister(string name);
        /// <summary>
        /// Adds the build action.
        /// </summary>
        /// <param name="execute">The execute.</param>
        void AddBuildAction(Action<IServiceProvider> execute);
        /// <summary>
        /// Adds the initializer.
        /// </summary>
        /// <param name="initializer">The initializer.</param>
        void AddInitializer(IInitializer initializer);
        /// <summary>
        /// Adds the initializer.
        /// </summary>
        /// <typeparam name="TInitializer">The type of the t initializer.</typeparam>
        void AddInitializer<TInitializer>() where TInitializer : IInitializer;
        /// <summary>
        /// Builds this instance.
        /// </summary>
        /// <returns>IServiceProvider.</returns>
        IServiceProvider Build();
    }
}