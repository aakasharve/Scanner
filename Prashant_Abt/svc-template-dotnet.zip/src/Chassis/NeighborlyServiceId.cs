﻿using System;

namespace Neighborly.Chassis
{
    /// <summary>
    /// Class NeighborlyServiceId.
    /// </summary>
    public class NeighborlyService : INeighborlyService
    {
        /// <summary>
        /// Gets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public string Id { get; } = $"{Guid.NewGuid():N}";
    }
}