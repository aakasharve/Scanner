﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace Neighborly.Chassis.AWSHelper
{
    [ExcludeFromCodeCoverage]
    public static class AWSHelperServiceCollectionExtensions
    {
        public static IServiceCollection AddAWSS3Bucket(this IServiceCollection services)
        {
            services.AddScoped<IAWSS3BucketHelper, AWSS3BucketHelper>();

            return services;
        }
    }
}
