﻿using Amazon;
using Amazon.S3;
using Amazon.S3.Model;
using Microsoft.Extensions.Options;
using Neighborly.Settings;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Neighborly.Chassis.AWSHelper
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// AWSS3BucketHelper
    /// </summary>
    public class AWSS3BucketHelper : IAWSS3BucketHelper
    {
        /// <summary>
        /// IAmazonS3
        /// </summary>
        private readonly IAmazonS3 _amazonS3;
        /// <summary>
        /// AWSConfig
        /// </summary>
        private readonly AWSConfig _settings;
        /// <summary>
        /// AWSS3BucketHelper
        /// </summary>
        /// <param name="s3Client"></param>
        /// <param name="settings"></param>
        public AWSS3BucketHelper(IAmazonS3 s3Client, IOptions<AWSConfig> settings)
        {
            this._amazonS3 = s3Client;
            this._settings = settings.Value;
        }
        /// <summary>
        /// Upload file on S3
        /// </summary>
        /// <param name="inputStream"></param>
        /// <param name="fileName"></param>
        /// <returns></returns>
        public async Task<bool> UploadFile(Stream inputStream, string fileName, string? metaData = null)
        {
            try
            {
                PutObjectRequest request = new PutObjectRequest()
                {
                    InputStream = inputStream,
                    BucketName = _settings.S3Bucket,
                    Key = fileName,
                };
                if (!string.IsNullOrEmpty(metaData))
                    request.Metadata.Add("fileMetaData", metaData);
                PutObjectResponse response = await _amazonS3.PutObjectAsync(request);
                if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        /// <summary>
        /// Get file list from S3
        /// </summary>
        /// <returns></returns>
        public async Task<ListVersionsResponse> FilesList()
        {
            return await _amazonS3.ListVersionsAsync(_settings.S3Bucket);
        }
        /// <summary>
        /// Get file from S3
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public async Task<GetObjectResponse> GetFile(string key)
        {
            try
            {
                GetObjectResponse response = await _amazonS3.GetObjectAsync(_settings.S3Bucket, key);
                if (response.HttpStatusCode == System.Net.HttpStatusCode.OK)
                    return response;
                else
                    return null;
            }
            catch (Amazon.S3.AmazonS3Exception ex)
            {
                if (ex.StatusCode == System.Net.HttpStatusCode.NotFound)
                    return null;
            }
            return null;
        }
        /// <summary>
        /// Delete file from S3
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public async Task<bool> DeleteFile(string key)
        {
            try
            {
                DeleteObjectResponse response = await _amazonS3.DeleteObjectAsync(_settings.S3Bucket, key);
                if (response.HttpStatusCode == System.Net.HttpStatusCode.NoContent)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                throw ex;
            }


        }
        /// <summary>
        /// GetPreSignedURL
        /// </summary>
        /// <param name="fileNameWithPath"></param>
        /// <returns></returns>
        public async Task<string> GetPreSignedURL(string fileNameWithPath)
        {
            var request = new GetPreSignedUrlRequest
            {
                BucketName = _settings.S3Bucket,
                Key = fileNameWithPath,
                Verb = HttpVerb.GET,
                Expires = DateTime.UtcNow.AddMinutes(Convert.ToInt32(_settings.S3PreSignedUrlExpirationInMin)),
            };
            return _amazonS3.GetPreSignedURL(request);
        }
    }
}
