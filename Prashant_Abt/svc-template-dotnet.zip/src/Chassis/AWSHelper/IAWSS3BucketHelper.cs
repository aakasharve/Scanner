﻿using Amazon.S3.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace Neighborly.Chassis.AWSHelper
{
    /// <summary>
    /// IAWSS3BucketHelper
    /// </summary>
    public interface IAWSS3BucketHelper
    {
        /// <summary>
        /// Upload file on S3
        /// </summary>
        /// <param name="inputStream"></param>
        /// <param name="fileName"></param>
        /// <param name="metaData"></param>
        /// <returns></returns>
        Task<bool> UploadFile(Stream inputStream, string fileName, string? metaData = null);
        /// <summary>
        /// Get file list from S3
        /// </summary>
        /// <returns></returns>
        Task<ListVersionsResponse> FilesList();
        /// <summary>
        ///  Get file from S3
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        Task<GetObjectResponse> GetFile(string key);
        /// <summary>
        /// Delete file from S3
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        Task<bool> DeleteFile(string key);
        /// <summary>
        /// 
        /// </summGetPreSignedURLary>
        /// <param name="fileNameWithPath"></param>
        Task<string> GetPreSignedURL(string fileNameWithPath);
    }
}
