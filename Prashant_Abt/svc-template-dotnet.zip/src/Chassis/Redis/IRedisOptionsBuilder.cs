namespace Neighborly.Chassis.Redis
{
    /// <summary>
    /// Interface IRedisOptionsBuilder
    /// </summary>
    public interface IRedisOptionsBuilder
    {
        /// <summary>
        /// Withes the connection string.
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        /// <returns>IRedisOptionsBuilder.</returns>
        IRedisOptionsBuilder WithConnectionString(string connectionString);
        /// <summary>
        /// Withes the instance.
        /// </summary>
        /// <param name="instance">The instance.</param>
        /// <returns>IRedisOptionsBuilder.</returns>
        IRedisOptionsBuilder WithInstance(string instance);
        /// <summary>
        /// Builds this instance.
        /// </summary>
        /// <returns>RedisOptions.</returns>
        RedisOptions Build();
    }
}