namespace Neighborly.Chassis.Redis
{
    /// <summary>
    /// Class RedisOptionsBuilder. This class cannot be inherited.
    /// Implements the <see cref="IRedisOptionsBuilder" />
    /// </summary>
    /// <seealso cref="IRedisOptionsBuilder" />
    internal sealed class RedisOptionsBuilder : IRedisOptionsBuilder
    {
        /// <summary>
        /// The options
        /// </summary>
        private readonly RedisOptions options = new RedisOptions();

        /// <summary>
        /// Withes the connection string.
        /// </summary>
        /// <param name="connectionString">The connection string.</param>
        /// <returns>IRedisOptionsBuilder.</returns>
        public IRedisOptionsBuilder WithConnectionString(string connectionString)
        {
            options.ConnectionString = connectionString;
            return this;
        }

        /// <summary>
        /// Withes the instance.
        /// </summary>
        /// <param name="instance">The instance.</param>
        /// <returns>IRedisOptionsBuilder.</returns>
        public IRedisOptionsBuilder WithInstance(string instance)
        {
            options.Instance = instance;
            return this;
        }

        /// <summary>
        /// Builds this instance.
        /// </summary>
        /// <returns>RedisOptions.</returns>
        public RedisOptions Build()
            => options;
    }
}