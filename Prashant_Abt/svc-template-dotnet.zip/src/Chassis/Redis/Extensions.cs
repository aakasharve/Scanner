using System;
using Microsoft.Extensions.DependencyInjection;
using StackExchange.Redis;

namespace Neighborly.Chassis.Redis
{
    /// <summary>
    /// Class Extensions.
    /// </summary>
    public static class Extensions
    {
        /// <summary>
        /// The section name
        /// </summary>
        private const string SectionName = "redis";
        /// <summary>
        /// The registry name
        /// </summary>
        private const string RegistryName = "persistence.redis";

        /// <summary>
        /// Adds the redis.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <param name="sectionName">Name of the section.</param>
        /// <returns>INeighborlyBuilder.</returns>
        public static INeighborlyBuilder AddRedis(this INeighborlyBuilder builder, string sectionName = SectionName)
        {
            if (string.IsNullOrWhiteSpace(sectionName))
            {
                sectionName = SectionName;
            }

            var options = builder.GetOptions<RedisOptions>(sectionName);
            return builder.AddRedis(options);
        }

        /// <summary>
        /// Adds the redis.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <param name="buildOptions">The build options.</param>
        /// <returns>INeighborlyBuilder.</returns>
        public static INeighborlyBuilder AddRedis(this INeighborlyBuilder builder,
            Func<IRedisOptionsBuilder, IRedisOptionsBuilder> buildOptions)
        {
            var options = buildOptions(new RedisOptionsBuilder()).Build();
            return builder.AddRedis(options);
        }

        /// <summary>
        /// Adds the redis.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <param name="options">The options.</param>
        /// <returns>INeighborlyBuilder.</returns>
        public static INeighborlyBuilder AddRedis(this INeighborlyBuilder builder, RedisOptions options)
        {
            if (!builder.TryRegister(RegistryName))
            {
                return builder;
            }

            builder.Services
                .AddSingleton(options)
                .AddSingleton<IConnectionMultiplexer>(sp => ConnectionMultiplexer.Connect(options.ConnectionString))
                .AddTransient(sp => sp.GetRequiredService<IConnectionMultiplexer>().GetDatabase(options.Database))
                .AddStackExchangeRedisCache(o =>
                {
                    o.Configuration = options.ConnectionString;
                    o.InstanceName = options.Instance;
                });

            return builder;
        }
    }
}