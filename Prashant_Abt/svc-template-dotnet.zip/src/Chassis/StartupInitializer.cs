﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Neighborly.Chassis
{
    /// <summary>
    /// Class StartupInitializer.
    /// </summary>
    public class StartupInitializer : IStartupInitializer
    {
        /// <summary>
        /// The initializers
        /// </summary>
        private readonly IList<IInitializer> initializers = new List<IInitializer>();

        /// <summary>
        /// Adds the initializer.
        /// </summary>
        /// <param name="initializer">The initializer.</param>
        public void AddInitializer(IInitializer initializer)
        {
            if (initializer is null || initializers.Contains(initializer)) return;

            initializers.Add(initializer);
        }

        /// <summary>
        /// initialize as an asynchronous operation.
        /// </summary>
        public async Task InitializeAsync()
        {
            foreach (var initializer in initializers) await initializer.InitializeAsync();
        }
    }
}