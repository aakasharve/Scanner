﻿namespace Neighborly.Chassis
{
    /// <summary>
    /// Interface IStartupInitializer
    /// </summary>
    public interface IStartupInitializer : IInitializer
    {
        /// <summary>
        /// Adds the initializer.
        /// </summary>
        /// <param name="initializer">The initializer.</param>
        void AddInitializer(IInitializer initializer);
    }
}