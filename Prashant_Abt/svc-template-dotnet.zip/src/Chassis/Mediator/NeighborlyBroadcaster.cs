﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Broadcasts an event of a given type to all the handlers
    /// </summary>
    /// <typeparam name="TEvent">The event type</typeparam>
    [ExcludeFromCodeCoverage]
    public class NeighborlyBroadcaster<TEvent> : Broadcaster<TEvent> where TEvent : class, IEvent
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly Serilog.ILogger _logger;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="handlers">The handlers.</param>
        /// <param name="pipelines">The pipelines.</param>
        /// <param name="logger">The logger.</param>
        public NeighborlyBroadcaster(
            IEnumerable<IEventHandler<TEvent>> handlers,
            IEnumerable<IPipeline> pipelines,
            Serilog.ILogger logger)
            : base(handlers, pipelines)
        {
            _logger = logger;
        }

        /// <inheritdoc />
        public override async Task BroadcastAsync(TEvent evt, CancellationToken ct)
        {
            _logger.Debug("Broadcasting event");
            await base.BroadcastAsync(evt, ct);

        }
    }
}