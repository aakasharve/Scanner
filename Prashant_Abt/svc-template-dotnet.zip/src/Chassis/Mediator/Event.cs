﻿using System;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Represents an event
    /// </summary>
    public abstract class Event : IEvent
    {
        /// <inheritdoc />
        public Guid Id { get; protected set; } = Guid.NewGuid();

        /// <inheritdoc />
        public DateTimeOffset CreatedOn { get; protected set; } = DateTimeOffset.UtcNow;

        /// <inheritdoc />
        public string CreatedBy { get; protected set; } = null!;
    }
}