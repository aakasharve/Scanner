﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Sends commands of a given type into the handler
    /// </summary>
    /// <typeparam name="TCommand">The command type</typeparam>
    [ExcludeFromCodeCoverage]
    public class NeighborlySender<TCommand> : Sender<TCommand> where TCommand : class, ICommand
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly Serilog.ILogger _logger;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="handler">The handler.</param>
        /// <param name="pipelines">The pipelines.</param>
        /// <param name="logger">The logger.</param>
        public NeighborlySender(
            ICommandHandler<TCommand> handler,
            IEnumerable<IPipeline> pipelines,
            Serilog.ILogger logger)
            : base(handler, pipelines)
        {
            _logger = logger;
        }

        /// <inheritdoc />
        public override async Task SendAsync(TCommand cmd, CancellationToken ct)
        {
            _logger.Debug("Sending command");
            await base.SendAsync(cmd, ct);

        }
    }

    /// <summary>
    /// Sends commands of a given type into the handler
    /// </summary>
    /// <typeparam name="TCommand">The command type</typeparam>
    /// <typeparam name="TResult">The result type</typeparam>
    [ExcludeFromCodeCoverage]
    public class NeighborlySender<TCommand, TResult> : Sender<TCommand, TResult>
        where TCommand : class, ICommand<TResult>
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly Serilog.ILogger _logger;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="handler">The handler.</param>
        /// <param name="pipelines">The pipelines.</param>
        /// <param name="logger">The logger.</param>
        public NeighborlySender(
            ICommandHandler<TCommand, TResult> handler,
            IEnumerable<IPipeline> pipelines,
            Serilog.ILogger logger)
            : base(handler, pipelines)
        {
            _logger = logger;
        }

        /// <inheritdoc />
        public override async Task<TResult> SendAsync(TCommand cmd, CancellationToken ct)
        {
            _logger.Debug("Sending command");
            return await base.SendAsync(cmd, ct);

        }
    }
}