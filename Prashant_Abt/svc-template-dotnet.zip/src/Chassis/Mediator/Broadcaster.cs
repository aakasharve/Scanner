﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Broadcasts an event of a given type to all the handlers
    /// </summary>
    /// <typeparam name="TEvent">The event type</typeparam>
    public class Broadcaster<TEvent> : IBroadcaster<TEvent> where TEvent : class, IEvent
    {
        /// <summary>
        /// The handlers
        /// </summary>
        private readonly IEnumerable<IEventHandler<TEvent>> handlers;
        /// <summary>
        /// The pipelines
        /// </summary>
        private readonly List<IPipeline> pipelines;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="handlers">The handlers.</param>
        /// <param name="pipelines">The pipelines.</param>
        /// <exception cref="ArgumentNullException">handlers</exception>
        /// <exception cref="ArgumentNullException">pipelines</exception>
        public Broadcaster(IEnumerable<IEventHandler<TEvent>> handlers, IEnumerable<IPipeline> pipelines)
        {
            this.handlers = handlers ?? throw new ArgumentNullException(nameof(handlers));
            this.pipelines = pipelines?.ToList() ?? throw new ArgumentNullException(nameof(pipelines));
        }

        /// <inheritdoc />
        public virtual Task BroadcastAsync(TEvent evt, CancellationToken ct)
        {
            if (evt == null) throw new ArgumentNullException(nameof(evt));

            Func<TEvent, CancellationToken, Task> next = (@event, cancellationToken) =>
            {
                if (this.handlers == null)
                {

                    return Task.CompletedTask;

                }

                var handlers = this.handlers
                    .Select(handler => handler.HandleAsync(@event, cancellationToken))
                    .ToArray();

                if (handlers.Length == 0)
                {

                    return Task.CompletedTask;

                }

                var tcs = new TaskCompletionSource<bool>();

                Task.Factory.ContinueWhenAll(handlers, tasks =>
                {
                    List<Exception> exceptions = null;
                    foreach (var t in tasks)
                    {
                        if (t.Exception == null)
                            continue;

                        exceptions ??= new List<Exception>(tasks.Length);
                        exceptions.Add(t.Exception.InnerException);
                    }

                    if (exceptions == null)
                        tcs.SetResult(true);
                    else
                        tcs.SetException(new AggregateException(exceptions));
                }, CancellationToken.None, TaskContinuationOptions.ExecuteSynchronously, TaskScheduler.Current);

                return tcs.Task;
            };

            for (var i = pipelines.Count - 1; i >= 0; i--)
            {
                var pipeline = pipelines[i];

                var old = next;
                next = (@event, c) => pipeline.OnEventAsync(old, @event, c);
            }

            return next(evt, ct);
        }
    }
}