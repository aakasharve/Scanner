﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Mediator service that uses delegates to build the required services
    /// </summary>
    public class DelegateMediatorServiceProvider : IMediatorServiceProvider
    {
        /// <summary>
        /// The service collection factory
        /// </summary>
        private readonly Func<Type, IEnumerable<object>> serviceCollectionFactory;
        /// <summary>
        /// The service factory
        /// </summary>
        private readonly Func<Type, object> serviceFactory;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="serviceFactory">The factory for single services</param>
        /// <param name="serviceCollectionFactory">The factory for collections of services</param>
        /// <exception cref="ArgumentNullException">serviceFactory</exception>
        /// <exception cref="ArgumentNullException">serviceCollectionFactory</exception>
        public DelegateMediatorServiceProvider(Func<Type, object> serviceFactory,
            Func<Type, IEnumerable<object>> serviceCollectionFactory)
        {
            this.serviceFactory = serviceFactory ?? throw new ArgumentNullException(nameof(serviceFactory));
            this.serviceCollectionFactory = serviceCollectionFactory ??
                                            throw new ArgumentNullException(nameof(serviceCollectionFactory));
        }

        /// <inheritdoc />
        public T BuildService<T>() where T : class
        {
            var service = serviceFactory(typeof(T));

            return (T) service;
        }

        /// <inheritdoc />
        public IEnumerable<T> BuildServices<T>() where T : class
        {
            var services = serviceCollectionFactory(typeof(T));

            return services?.Cast<T>() ?? Enumerable.Empty<T>();
        }
    }
}