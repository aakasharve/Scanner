﻿using System.Threading;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Sends commands of a given type into the handler
    /// </summary>
    /// <typeparam name="TCommand">The command type</typeparam>
    public interface ISender<in TCommand> where TCommand : class, ICommand
    {
        /// <summary>
        /// Sends the command
        /// </summary>
        /// <param name="cmd">The command to send</param>
        /// <param name="ct">The cancellation token</param>
        /// <returns>A task to be awaited</returns>
        Task SendAsync(TCommand cmd, CancellationToken ct);
    }

    /// <summary>
    /// Sends commands of a given type into the handler
    /// </summary>
    /// <typeparam name="TCommand">The command type</typeparam>
    /// <typeparam name="TResult">The result type</typeparam>
    public interface ISender<in TCommand, TResult> where TCommand : class, ICommand<TResult>
    {
        /// <summary>
        /// Sends the command
        /// </summary>
        /// <param name="cmd">The command to send</param>
        /// <param name="ct">The cancellation token</param>
        /// <returns>A task to be awaited</returns>
        Task<TResult> SendAsync(TCommand cmd, CancellationToken ct);
    }
}