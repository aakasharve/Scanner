﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Fetches data of a given query type from the handler
    /// </summary>
    /// <typeparam name="TQuery">The query type</typeparam>
    /// <typeparam name="TResult">The result type</typeparam>
    public class Fetcher<TQuery, TResult> : IFetcher<TQuery, TResult> where TQuery : class, IQuery<TResult>
    {
        /// <summary>
        /// The handler
        /// </summary>
        private readonly IQueryHandler<TQuery, TResult> handler;
        /// <summary>
        /// The pipelines
        /// </summary>
        private readonly List<IPipeline> pipelines;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="handler">The handler.</param>
        /// <param name="pipelines">The pipelines.</param>
        /// <exception cref="ArgumentNullException">handler</exception>
        /// <exception cref="ArgumentNullException">pipelines</exception>
        public Fetcher(IQueryHandler<TQuery, TResult> handler, IEnumerable<IPipeline> pipelines)
        {
            this.handler = handler ?? throw new ArgumentNullException(nameof(handler));
            this.pipelines = (pipelines ?? throw new ArgumentNullException(nameof(pipelines))).ToList();
        }

        /// <inheritdoc />
        public virtual Task<TResult> FetchAsync(TQuery query, CancellationToken ct)
        {
            if (query == null) throw new ArgumentNullException(nameof(query));

            if (pipelines == null || pipelines.Count == 0)
                return handler.HandleAsync(query, ct);

            Func<TQuery, CancellationToken, Task<TResult>> next = (qry, c) => handler.HandleAsync(qry, c);

            for (var i = pipelines.Count - 1; i >= 0; i--)
            {
                var pipeline = pipelines[i];

                var old = next;
                next = (qry, c) => pipeline.OnQueryAsync(old, qry, c);
            }

            return next(query, ct);
        }
    }
}