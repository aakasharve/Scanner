﻿using System;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Represents a data query
    /// </summary>
    /// <typeparam name="TResult">The result type</typeparam>
    public abstract class Query<TResult> : IQuery<TResult>
    {
        /// <inheritdoc />
        public Guid Id { get; protected set; } = Guid.NewGuid();

        /// <inheritdoc />
        public DateTimeOffset CreatedOn { get; protected set; } = DateTimeOffset.UtcNow;

        /// <inheritdoc />
        public string CreatedBy { get; protected set; } = null!;
    }
}