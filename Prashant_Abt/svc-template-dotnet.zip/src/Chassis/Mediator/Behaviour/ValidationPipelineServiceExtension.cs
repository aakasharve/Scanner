﻿using System;
using System.Linq;
using System.Reflection;
using FluentValidation;
using Microsoft.Extensions.DependencyInjection;

namespace Neighborly.Chassis.Mediator.Behaviour.Validation
{
    /// <summary>
    /// Extensions for <see cref="MediatorOptions" />.
    /// </summary>
    public static class ValidationPipelineServiceExtension
    {
        /// <summary>
        /// Registers a <see cref="ValValidationPipeline" />.
        /// </summary>
        /// <param name="options">The mediator registration options</param>
        /// <param name="config">Configures the pipeline options</param>
        /// <param name="lifetime">The pipeline lifetime</param>
        /// <returns>MediatorOptions.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static MediatorOptions AddPipelineForValidation(
            this MediatorOptions options, Action<ValidationPipelineOptions> config = null,
            ServiceLifetime lifetime = ServiceLifetime.Transient)
        {
            if (config != null)
                options.Services.Configure(config);

            options.AddPipeline<ValidationPipeline>(lifetime);

            return options;
        }

        /// <summary>
        /// Registers all the <see cref="IValidator" /> found in the given assembly.
        /// </summary>
        /// <param name="options">The options.</param>
        /// <param name="assembly">The mediator options</param>
        /// <param name="lifetime">The assembly to scan</param>
        /// <returns>The options instance after changes</returns>
        /// <exception cref="IValidator"></exception>
        public static MediatorOptions AddValidatorsFromAssembly(this MediatorOptions options,
            Assembly assembly, ServiceLifetime lifetime = ServiceLifetime.Singleton)
        {

            var exportedTypes = assembly.ExportedTypes;

            foreach (var t in exportedTypes.Where(t => t.IsClass && !t.IsAbstract))
            {

                var implementedInterfaces = t.GetInterfaces();

                foreach (var i in implementedInterfaces.Where(e =>
                    e.IsGenericType && e.GetGenericTypeDefinition() == typeof(IValidator<>)))
                {

                    var serviceType = i;
                    var implementationType = t;

                    options.Services.Add(new ServiceDescriptor(serviceType, implementationType, lifetime));
                }
            }

            return options;
        }

        /// <summary>
        /// Registers all the <see cref="IValidator{T}" /> found in the assembly of the given type.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="options">The options.</param>
        /// <param name="lifetime">The lifetime.</param>
        /// <returns>MediatorOptions.</returns>
        public static MediatorOptions AddValidatorsFromAssemblyOf<T>(this MediatorOptions options,
            ServiceLifetime lifetime = ServiceLifetime.Singleton)
        {

            return options.AddValidatorsFromAssembly(typeof(T).Assembly, lifetime);

        }
    }
}