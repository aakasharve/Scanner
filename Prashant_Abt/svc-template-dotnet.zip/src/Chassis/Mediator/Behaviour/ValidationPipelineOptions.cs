﻿using System;
using System.Threading;
using System.Threading.Tasks;
using FluentValidation.Results;

namespace Neighborly.Chassis.Mediator.Behaviour.Validation
{
    /// <summary>
    /// Validation pipeline options
    /// </summary>
    public class ValidationPipelineOptions
    {
        /// <summary>
        /// Should commands be validated? Defaults to 'false'.
        /// </summary>
        /// <value><c>true</c> if [validate command]; otherwise, <c>false</c>.</value>
        public bool ValidateCommand { get; set; } = false;

        /// <summary>
        /// Should events be validated? Defaults to 'false'.
        /// </summary>
        /// <value><c>true</c> if [validate event]; otherwise, <c>false</c>.</value>
        public bool ValidateEvent { get; set; } = false;

        /// <summary>
        /// Should commands be validated? Defaults to 'false'.
        /// </summary>
        /// <value><c>true</c> if [validate query]; otherwise, <c>false</c>.</value>
        public bool ValidateQuery { get; set; } = false;

        /// <summary>
        /// Fail if the validator for a given class is not found? Defaults to 'true'.
        /// </summary>
        /// <value><c>true</c> if [fail if validator not found]; otherwise, <c>false</c>.</value>
        public bool FailIfValidatorNotFound { get; set; } = true;

        /// <summary>
        /// Invoked when a validation fails.
        /// </summary>
        /// <value>The on failed validation.</value>
        public Func<object, ValidationResult, CancellationToken, Task> OnFailedValidation { get; set; }
    }
}