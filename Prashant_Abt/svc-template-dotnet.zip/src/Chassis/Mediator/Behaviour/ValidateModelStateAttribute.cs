﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Neighborly.Chassis.Formatter;
using System.Diagnostics.CodeAnalysis;
using System.Linq;

namespace Neighborly.Chassis.Mediator.Behaviour
{
    [ExcludeFromCodeCoverage]
    public class ValidateModelStateAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (!context.ModelState.IsValid)
            {
                var errors = context.ModelState.AllErrors().ToList();

                errors.Remove(errors.SingleOrDefault(s => s.Reason.Contains("model field is required")));

                errors.Where(w => w.Reason.Contains("Error converting value") && w.Reason.Contains("System.Guid")).ToList().ForEach(x =>
                {
                    x.Reason = "Invalid Guid";
                });

                errors.Where(w => (w.Reason.Contains("Error converting value") && w.Reason.Contains("System.Boolean")) || w.Reason.Contains("Could not convert string to boolean")).ToList().ForEach(x =>
                {
                    x.Reason = "Invalid boolean value";
                });

                errors.Where(w => w.Reason.Contains("Error converting value") && w.Reason.Contains("Enums")).ToList().ForEach(x =>
                {
                    x.Reason = "Invalid Enum value";
                });
                errors.Where(w => w.Reason.Contains("Error converting value") && w.Reason.Contains("System.Int64")).ToList().ForEach(x =>
                {
                    x.Reason = "Invalid Integer value";
                });
                errors.Where(w => w.Reason.Contains("Could not convert") && w.Reason.Contains("to double")).ToList().ForEach(x =>
                {
                    x.Reason = "Invalid Decimal value";
                });
                errors.Where(w => w.Reason.Contains("Error converting value") && w.Reason.Contains("System.Int32")).ToList().ForEach(x =>
                {
                    x.Reason = "Invalid Integer value";
                });
                errors.Where(w => w.Reason.Contains("Error converting value") && w.Reason.Contains("System.Double")).ToList().ForEach(x =>
                {
                    x.Reason = "Invalid Double value";
                });
                errors.Where(w => w.Reason.Contains("Error converting value") && w.Reason.Contains("Service.DiscountType")).ToList().ForEach(x =>
                {
                    x.Reason = "Invalid Discount Type value";
                });
                CustomApiResponse customError = new CustomApiResponse(true, 400, "Fields validation error", errors);

                context.Result = new JsonResult(customError)
                {
                    StatusCode = 400
                };
            }
        }
    }
}
