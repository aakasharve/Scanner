﻿using System;
using System.Threading;
using System.Threading.Tasks;
using Serilog;
using Microsoft.Extensions.Options;
using Serilog.Events;

namespace Neighborly.Chassis.Mediator.Behaviour.Logging
{
    /// <summary>
    /// Logging pipeline
    /// </summary>
    public class LoggingPipeline : IPipeline
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger _logger;
        /// <summary>
        /// The options
        /// </summary>
        private readonly LoggingPipelineOptions _options;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="options">The options.</param>
        /// <param name="logger">The logger.</param>
        public LoggingPipeline(
            IOptions<LoggingPipelineOptions> options,
            ILogger logger)
        {
            _options = options.Value;
            _logger = logger.ForContext<LoggingPipeline>();
        }

        /// <inheritdoc />
        public Task OnCommandAsync<TCommand>(Func<TCommand, CancellationToken, Task> next, TCommand cmd,
            CancellationToken ct)
            where TCommand : class, ICommand
        {
            var name = typeof(TCommand).Name;
            Log(_options.LogCommand, "Command['{commandName}']:{command}", name, cmd);

            return next(cmd, ct);
        }

        /// <inheritdoc />
        public async Task<TResult> OnCommandAsync<TCommand, TResult>(
            Func<TCommand, CancellationToken, Task<TResult>> next, TCommand cmd, CancellationToken ct)
            where TCommand : class, ICommand<TResult>
        {
            var name = typeof(TCommand).Name;
            Log(_options.LogCommand, "Command['{commandName}']:{command}", name, cmd);

            var result = await next(cmd, ct).ConfigureAwait(false);

            Log(_options.LogCommandResult, "Command['{commandName}'].Result:{commandResult}", name, result);

            return result;
        }

        /// <inheritdoc />
        public Task OnEventAsync<TEvent>(Func<TEvent, CancellationToken, Task> next, TEvent evt, CancellationToken ct)
            where TEvent : class, IEvent
        {
            var name = typeof(TEvent).Name;
            Log(_options.LogEvent, "Event['{eventName}']:{event}", name, evt);

            return next(evt, ct);
        }

        /// <inheritdoc />
        public async Task<TResult> OnQueryAsync<TQuery, TResult>(Func<TQuery, CancellationToken, Task<TResult>> next,
            TQuery query, CancellationToken ct)
            where TQuery : class, IQuery<TResult>
        {
            var name = typeof(TQuery).Name;
            Log(_options.LogQuery, "Query['{queryName}']:{query}", name, query);

            var result = await next(query, ct).ConfigureAwait(false);

            Log(_options.LogQueryResult, "Query['{queryName}'].Result:{queryResult}", name, result);

            return result;
        }

        /// <summary>
        /// Logs the specified is active.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="isActive">if set to <c>true</c> [is active].</param>
        /// <param name="message">The message.</param>
        /// <param name="name">The name.</param>
        /// <param name="instance">The instance.</param>
        private void Log<T>(bool isActive, string message, string name, T instance)
        {
            if (!_logger.IsEnabled(LogEventLevel.Information) || !isActive)
                return;

            var serializedInstance = _options.Serializer(instance);
            switch (_options.Level)
            {
                case LogEventLevel.Information:
                    _logger.Information(message, name, serializedInstance);
                    break;
                case LogEventLevel.Debug:
                    _logger.Debug(message, name, serializedInstance);
                    break;
                
                case LogEventLevel.Warning:
                    _logger.Warning(message, name, serializedInstance);
                    break;
                case LogEventLevel.Error:
                    _logger.Error(message, name, serializedInstance);
                    break;
                case LogEventLevel.Fatal:
                    _logger.Fatal(message, name, serializedInstance);
                    break;
            }
        }
    }
}