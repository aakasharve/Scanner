﻿using System;
using Microsoft.Extensions.DependencyInjection;

namespace Neighborly.Chassis.Mediator.Behaviour.Logging
{
    /// <summary>
    /// Extensions for <see cref="MediatorOptions" />.
    /// </summary>
    public static class LogginePipelineServiceExtension
    {
        /// <summary>
        /// Registers a <see cref="LoggingPipeline" />.
        /// </summary>
        /// <param name="options">The mediator registration options</param>
        /// <param name="config">Configures the pipeline options</param>
        /// <param name="lifetime">The pipeline lifetime</param>
        /// <returns>MediatorOptions.</returns>
        /// <exception cref="ArgumentNullException"></exception>
        public static MediatorOptions AddPipelineForLogging(
            this MediatorOptions options, Action<LoggingPipelineOptions> config = null,
            ServiceLifetime lifetime = ServiceLifetime.Transient)
        {
            if (config != null)
                options.Services.Configure(config);

            options.AddPipeline<LoggingPipeline>(lifetime);

            return options;
        }
    }
}