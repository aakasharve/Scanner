﻿using System;
using System.Text.Json;
using Serilog.Events;

namespace Neighborly.Chassis.Mediator.Behaviour.Logging
{
    /// <summary>
    /// Logging pipeline options
    /// </summary>
    public class LoggingPipelineOptions
    {
        /// <summary>
        /// The serializer
        /// </summary>
        private Func<object, string> _serializer;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        public LoggingPipelineOptions()
        {
            var cachedSettings = new JsonSerializerOptions
            {
                WriteIndented = true
            };
            _serializer = instance => JsonSerializer.Serialize(instance, cachedSettings);

        }

        /// <summary>
        /// Serialize and log commands? Defaults to 'true'.
        /// </summary>
        /// <value><c>true</c> if [log command]; otherwise, <c>false</c>.</value>
        public bool LogCommand { get; set; } = true;

        /// <summary>
        /// Serialize and log the command result? Defaults to 'false'.
        /// </summary>
        /// <value><c>true</c> if [log command result]; otherwise, <c>false</c>.</value>
        public bool LogCommandResult { get; set; } = false;

        /// <summary>
        /// Serialize and log events? Defaults to 'true'.
        /// </summary>
        /// <value><c>true</c> if [log event]; otherwise, <c>false</c>.</value>
        public bool LogEvent { get; set; } = true;

        /// <summary>
        /// Serialize and log queries? Defaults to 'true'.
        /// </summary>
        /// <value><c>true</c> if [log query]; otherwise, <c>false</c>.</value>
        public bool LogQuery { get; set; } = true;

        /// <summary>
        /// Serialize and log the query result? Defaults to 'false'.
        /// </summary>
        /// <value><c>true</c> if [log query result]; otherwise, <c>false</c>.</value>
        public bool LogQueryResult { get; set; } = false;

        /// <summary>
        /// Log level to be used. Defaults to <see cref="LogEventLevel.Debug"" />.
        /// </summary>
        /// <value>The level.</value>
        public LogEventLevel Level { get; set; } = LogEventLevel.Debug;

        /// <summary>
        /// Used to serialize the instance into the logs as a string. Defaults to an indented JSON representation.
        /// </summary>
        /// <value>The serializer.</value>
        /// <exception cref="ArgumentNullException">value</exception>
        public Func<object, string> Serializer
        {
            get => _serializer;
            set => _serializer = value ?? throw new ArgumentNullException(nameof(value));
        }
    }
}