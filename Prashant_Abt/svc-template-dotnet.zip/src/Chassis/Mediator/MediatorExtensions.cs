﻿using System;
using System.Threading;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Helper methods for the <see cref="IMediator" /> interface
    /// </summary>
    public static class MediatorExtensions
    {
        /// <summary>
        /// Sends a command to an <see cref="ICommandHandler{TCommand}" />.
        /// </summary>
        /// <param name="mediator">The mediator to use</param>
        /// <param name="cmd">The command to publish</param>
        /// <exception cref="ArgumentNullException">mediator</exception>
        public static void Send(this IMediator mediator, ICommand cmd)
        {
            if (mediator == null) throw new ArgumentNullException(nameof(mediator));

            mediator.SendAsync(cmd, CancellationToken.None)
                .ConfigureAwait(false).GetAwaiter().GetResult();
        }

        /// <summary>
        /// Sends a command to an <see cref="ICommandHandler{TCommand,TResult}" /> and
        /// returns the operation result.
        /// </summary>
        /// <typeparam name="TResult">The result type</typeparam>
        /// <param name="mediator">The mediator to use</param>
        /// <param name="cmd">The command to publish</param>
        /// <returns>The handler result</returns>
        /// <exception cref="ArgumentNullException">mediator</exception>
        public static TResult Send<TResult>(this IMediator mediator, ICommand<TResult> cmd)
        {
            if (mediator == null) throw new ArgumentNullException(nameof(mediator));

            return mediator.SendAsync(cmd, CancellationToken.None)

                .ConfigureAwait(false).GetAwaiter().GetResult();

        }

        /// <summary>
        /// Broadcast the event across all <see cref="IEventHandler{TEvent}" />.
        /// </summary>
        /// <param name="mediator">The mediator to use</param>
        /// <param name="evt">The event to broadcast</param>
        /// <exception cref="ArgumentNullException">mediator</exception>
        public static void Broadcast(this IMediator mediator, IEvent evt)
        {
            if (mediator == null) throw new ArgumentNullException(nameof(mediator));

            mediator.BroadcastAsync(evt, CancellationToken.None)

                .ConfigureAwait(false).GetAwaiter().GetResult();

        }

        /// <summary>
        /// Fetches a query from a <see cref="IQueryHandler{TQuery,TResult}" /> and
        /// returns the query result.
        /// </summary>
        /// <typeparam name="TResult">The result type</typeparam>
        /// <param name="mediator">The mediator to use</param>
        /// <param name="query">The query to fetch</param>
        /// <returns>The handler result</returns>
        /// <exception cref="ArgumentNullException">mediator</exception>
        public static TResult Fetch<TResult>(this IMediator mediator, IQuery<TResult> query)
        {
            if (mediator == null) throw new ArgumentNullException(nameof(mediator));

            return mediator.FetchAsync(query, CancellationToken.None)

                .ConfigureAwait(false).GetAwaiter().GetResult();

        }
    }
}