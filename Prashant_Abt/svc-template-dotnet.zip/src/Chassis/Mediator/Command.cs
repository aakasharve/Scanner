﻿using System;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Represents a command
    /// </summary>
    public abstract class Command : ICommand
    {
        /// <inheritdoc />
        public Guid Id { get; protected set; } = Guid.NewGuid();

        /// <inheritdoc />
        public DateTimeOffset CreatedOn { get; protected set; } = DateTimeOffset.UtcNow;

        /// <inheritdoc />
        public string CreatedBy { get; protected set; }
    }

    /// <summary>
    /// Represents a command
    /// </summary>
    /// <typeparam name="TResult">The type of the t result.</typeparam>
    public abstract class Command<TResult> : ICommand<TResult>
    {
        /// <inheritdoc />
        public Guid Id { get; protected set; } = Guid.NewGuid();

        /// <inheritdoc />
        public DateTimeOffset CreatedOn { get; protected set; } = DateTimeOffset.UtcNow;

        /// <inheritdoc />
        public string CreatedBy { get; protected set; }
    }
}