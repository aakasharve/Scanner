﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Sends commands of a given type into the handler
    /// </summary>
    /// <typeparam name="TCommand">The command type</typeparam>
    public class Sender<TCommand> : ISender<TCommand> where TCommand : class, ICommand
    {
        /// <summary>
        /// The handler
        /// </summary>
        private readonly ICommandHandler<TCommand> handler;
        /// <summary>
        /// The pipelines
        /// </summary>
        private readonly List<IPipeline> pipelines;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="handler">The handler.</param>
        /// <param name="pipelines">The pipelines.</param>
        /// <exception cref="ArgumentNullException">handler</exception>
        /// <exception cref="ArgumentNullException">pipelines</exception>
        public Sender(ICommandHandler<TCommand> handler, IEnumerable<IPipeline> pipelines)
        {
            this.handler = handler ?? throw new ArgumentNullException(nameof(handler));
            this.pipelines = pipelines?.ToList() ?? throw new ArgumentNullException(nameof(pipelines));
        }

        /// <inheritdoc />
        public virtual Task SendAsync(TCommand cmd, CancellationToken ct)
        {
            if (cmd == null) throw new ArgumentNullException(nameof(cmd));

            if (pipelines == null || pipelines.Count == 0)
                return handler.HandleAsync(cmd, ct);

            Func<TCommand, CancellationToken, Task> next = (command, c) => handler.HandleAsync(command, c);

            for (var i = pipelines.Count - 1; i >= 0; i--)
            {
                var pipeline = pipelines[i];

                var old = next;
                next = (command, c) => pipeline.OnCommandAsync(old, command, c);
            }

            return next(cmd, ct);
        }
    }

    /// <summary>
    /// Sends commands of a given type into the handler
    /// </summary>
    /// <typeparam name="TCommand">The command type</typeparam>
    /// <typeparam name="TResult">The result type</typeparam>
    public class Sender<TCommand, TResult> : ISender<TCommand, TResult> where TCommand : class, ICommand<TResult>
    {
        /// <summary>
        /// The handler
        /// </summary>
        private readonly ICommandHandler<TCommand, TResult> handler;
        /// <summary>
        /// The pipelines
        /// </summary>
        private readonly List<IPipeline> pipelines;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="handler">The handler.</param>
        /// <param name="pipelines">The pipelines.</param>
        /// <exception cref="ArgumentNullException">handler</exception>
        /// <exception cref="ArgumentNullException">pipelines</exception>
        public Sender(ICommandHandler<TCommand, TResult> handler, IEnumerable<IPipeline> pipelines)
        {
            this.handler = handler ?? throw new ArgumentNullException(nameof(handler));
            this.pipelines = pipelines?.ToList() ?? throw new ArgumentNullException(nameof(pipelines));
        }

        /// <inheritdoc />
        public virtual Task<TResult> SendAsync(TCommand cmd, CancellationToken ct)
        {
            if (cmd == null) throw new ArgumentNullException(nameof(cmd));

            if (pipelines == null || pipelines.Count == 0)
                return handler.HandleAsync(cmd, ct);

            Func<TCommand, CancellationToken, Task<TResult>> next = (command, c) => handler.HandleAsync(command, c);

            for (var i = pipelines.Count - 1; i >= 0; i--)
            {
                var pipeline = pipelines[i];

                var old = next;
                next = (command, c) => pipeline.OnCommandAsync(old, command, c);
            }

            return next(cmd, ct);
        }
    }
}