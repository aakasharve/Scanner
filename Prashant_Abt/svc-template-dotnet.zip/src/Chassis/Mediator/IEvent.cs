﻿using System;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Represents an event
    /// </summary>
    public interface IEvent
    {
        /// <summary>
        /// The unique identifier
        /// </summary>
        /// <value>The identifier.</value>
        Guid Id { get; }

        /// <summary>
        /// The date and time in which the instance was created
        /// </summary>
        /// <value>The created on.</value>
        DateTimeOffset CreatedOn { get; }

        /// <summary>
        /// The identifier for the user that created this instance
        /// </summary>
        /// <value>The created by.</value>
        string CreatedBy { get; }
    }
}