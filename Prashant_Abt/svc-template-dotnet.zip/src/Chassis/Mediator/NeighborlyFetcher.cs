﻿using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Fetches data of a given query type from the handler
    /// </summary>
    /// <typeparam name="TQuery">The query type</typeparam>
    /// <typeparam name="TResult">The result type</typeparam>
    [ExcludeFromCodeCoverage]
    public class NeighborlyFetcher<TQuery, TResult> : Fetcher<TQuery, TResult> where TQuery : class, IQuery<TResult>
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly Serilog.ILogger _logger;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="handler">The handler.</param>
        /// <param name="pipelines">The pipelines.</param>
        /// <param name="logger">The logger.</param>
        public NeighborlyFetcher(
            IQueryHandler<TQuery, TResult> handler,
            IEnumerable<IPipeline> pipelines,
            Serilog.ILogger logger)
            : base(handler, pipelines)
        {
            _logger = logger;
        }

        /// <inheritdoc />
        public override async Task<TResult> FetchAsync(TQuery query, CancellationToken ct)
        {
            _logger.Debug("Fetching query data");
            return await base.FetchAsync(query, ct);

        }
    }
}