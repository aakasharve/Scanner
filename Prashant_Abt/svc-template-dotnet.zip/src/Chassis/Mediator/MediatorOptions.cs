﻿using System;
using Microsoft.Extensions.DependencyInjection;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Mediator options for container registration
    /// </summary>
    public class MediatorOptions
    {
        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="services">The service collection</param>
        /// <exception cref="ArgumentNullException">services</exception>
        public MediatorOptions(IServiceCollection services)
        {
            Services = services ?? throw new ArgumentNullException(nameof(services));
        }

        /// <summary>
        /// The service collection
        /// </summary>
        /// <value>The services.</value>
        public IServiceCollection Services { get; }

        /// <summary>
        /// The mediator instance lifetime. Defaults to '<see cref="ServiceLifetime.Transient" />'.
        /// </summary>
        /// <value>The lifetime.</value>
        public ServiceLifetime Lifetime { get; set; } = ServiceLifetime.Transient;

        /// <summary>
        /// The mediator service provider instance lifetime. Defaults to '<see cref="ServiceLifetime.Transient" />'.
        /// </summary>
        /// <value>The service provider lifetime.</value>
        public ServiceLifetime ServiceProviderLifetime { get; set; } = ServiceLifetime.Transient;
    }
}