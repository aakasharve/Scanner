﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.DependencyInjection;

namespace Neighborly.Chassis.Mediator
{
    /// <summary>
    /// Factory for mediator dependencies that build services directly from
    /// the <see cref="IServiceProvider" /> instance.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class NeighborlyMediatorServiceProvider : IMediatorServiceProvider
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly Serilog.ILogger _logger;
        /// <summary>
        /// The provider
        /// </summary>
        private readonly IServiceProvider _provider;

        /// <summary>
        /// Creates a new instance
        /// </summary>
        /// <param name="provider">The service provider</param>
        /// <param name="logger">The factory logger</param>
        /// <exception cref="ArgumentNullException">provider</exception>
        /// <exception cref="ArgumentNullException">logger</exception>
        public NeighborlyMediatorServiceProvider(IServiceProvider provider,
            Serilog.ILogger logger)
        {
            _provider = provider ?? throw new ArgumentNullException(nameof(provider));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        /// <inheritdoc />
        public T BuildService<T>() where T : class
        {
            if (_logger.IsEnabled(Serilog.Events.LogEventLevel.Debug))
                _logger.Debug("Building service for type '{type}'", typeof(T));

            return _provider.GetService<T>();
        }

        /// <inheritdoc />
        public IEnumerable<T> BuildServices<T>() where T : class
        {
            if (_logger.IsEnabled(Serilog.Events.LogEventLevel.Debug))
                _logger.Debug("Building services for type '{type}'", typeof(T));

            return _provider.GetServices<T>();
        }
    }
}