namespace Neighborly.Chassis.Swagger
{
    /// <summary>
    /// Class SwaggerOptions.
    /// </summary>
    public class SwaggerOptions
    {
        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="SwaggerOptions" /> is enabled.
        /// </summary>
        /// <value><c>true</c> if enabled; otherwise, <c>false</c>.</value>
        public bool Enabled { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [re document enabled].
        /// </summary>
        /// <value><c>true</c> if [re document enabled]; otherwise, <c>false</c>.</value>
        public bool ReDocEnabled { get; set; }
        /// <summary>
        /// Gets or sets the name.
        /// </summary>
        /// <value>The name.</value>
        public string Name { get; set; } = null!;
        /// <summary>
        /// Gets or sets the title.
        /// </summary>
        /// <value>The title.</value>
        public string Title { get; set; } = null!;
        /// <summary>
        /// Gets or sets the version.
        /// </summary>
        /// <value>The version.</value>
        public string Version { get; set; } = null!;
        /// <summary>
        /// Gets or sets the route prefix.
        /// </summary>
        /// <value>The route prefix.</value>
        public string RoutePrefix { get; set; } = null!;
        /// <summary>
        /// Gets or sets a value indicating whether [include security].
        /// </summary>
        /// <value><c>true</c> if [include security]; otherwise, <c>false</c>.</value>
        public bool IncludeSecurity { get; set; }
        /// <summary>
        /// Gets or sets a value indicating whether [serialize as open API v2].
        /// </summary>
        /// <value><c>true</c> if [serialize as open API v2]; otherwise, <c>false</c>.</value>
        public bool SerializeAsOpenApiV2 { get; set; }

        /// <summary>
        /// Gets or sets a value .
        /// </summary>
        /// <value>The server URL.</value>
        public string ServerUrl { get; set; } = null!;
    }
}