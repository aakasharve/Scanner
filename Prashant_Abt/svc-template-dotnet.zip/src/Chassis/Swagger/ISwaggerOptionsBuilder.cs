namespace Neighborly.Chassis.Swagger
{
    /// <summary>
    /// Interface ISwaggerOptionsBuilder
    /// </summary>
    public interface ISwaggerOptionsBuilder
    {
        /// <summary>
        /// Enables the specified enabled.
        /// </summary>
        /// <param name="enabled">if set to <c>true</c> [enabled].</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        ISwaggerOptionsBuilder Enable(bool enabled);
        /// <summary>
        /// Res the document enable.
        /// </summary>
        /// <param name="reDocEnabled">if set to <c>true</c> [re document enabled].</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        ISwaggerOptionsBuilder ReDocEnable(bool reDocEnabled);
        /// <summary>
        /// Withes the name.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        ISwaggerOptionsBuilder WithName(string name);
        /// <summary>
        /// Withes the title.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        ISwaggerOptionsBuilder WithTitle(string title);
        /// <summary>
        /// Withes the version.
        /// </summary>
        /// <param name="version">The version.</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        ISwaggerOptionsBuilder WithVersion(string version);
        /// <summary>
        /// Withes the route prefix.
        /// </summary>
        /// <param name="routePrefix">The route prefix.</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        ISwaggerOptionsBuilder WithRoutePrefix(string routePrefix);
        /// <summary>
        /// Includes the security.
        /// </summary>
        /// <param name="includeSecurity">if set to <c>true</c> [include security].</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        ISwaggerOptionsBuilder IncludeSecurity(bool includeSecurity);
        /// <summary>
        /// Serializes as open API v2.
        /// </summary>
        /// <param name="serializeAsOpenApiV2">if set to <c>true</c> [serialize as open API v2].</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        ISwaggerOptionsBuilder SerializeAsOpenApiV2(bool serializeAsOpenApiV2);
        /// <summary>
        /// Builds this instance.
        /// </summary>
        /// <returns>SwaggerOptions.</returns>
        SwaggerOptions Build();
    }
}