namespace Neighborly.Chassis.Swagger
{
    /// <summary>
    /// Class SwaggerOptionsBuilder. This class cannot be inherited.
    /// Implements the <see cref="ISwaggerOptionsBuilder" />
    /// </summary>
    /// <seealso cref="ISwaggerOptionsBuilder" />
    internal sealed class SwaggerOptionsBuilder : ISwaggerOptionsBuilder
    {
        /// <summary>
        /// The options
        /// </summary>
        private readonly SwaggerOptions options = new SwaggerOptions();

        /// <summary>
        /// Enables the specified enabled.
        /// </summary>
        /// <param name="enabled">if set to <c>true</c> [enabled].</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        public ISwaggerOptionsBuilder Enable(bool enabled)
        {
            options.Enabled = enabled;
            return this;
        }

        /// <summary>
        /// Res the document enable.
        /// </summary>
        /// <param name="reDocEnabled">if set to <c>true</c> [re document enabled].</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        public ISwaggerOptionsBuilder ReDocEnable(bool reDocEnabled)
        {
            options.ReDocEnabled = reDocEnabled;
            return this;
        }

        /// <summary>
        /// Withes the name.
        /// </summary>
        /// <param name="name">The name.</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        public ISwaggerOptionsBuilder WithName(string name)
        {
            options.Name = name;
            return this;
        }

        /// <summary>
        /// Withes the title.
        /// </summary>
        /// <param name="title">The title.</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        public ISwaggerOptionsBuilder WithTitle(string title)
        {
            options.Title = title;
            return this;
        }

        /// <summary>
        /// Withes the version.
        /// </summary>
        /// <param name="version">The version.</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        public ISwaggerOptionsBuilder WithVersion(string version)
        {
            options.Version = version;
            return this;
        }

        /// <summary>
        /// Withes the route prefix.
        /// </summary>
        /// <param name="routePrefix">The route prefix.</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        public ISwaggerOptionsBuilder WithRoutePrefix(string routePrefix)
        {
            options.RoutePrefix = routePrefix;
            return this;
        }

        /// <summary>
        /// Includes the security.
        /// </summary>
        /// <param name="includeSecurity">if set to <c>true</c> [include security].</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        public ISwaggerOptionsBuilder IncludeSecurity(bool includeSecurity)
        {
            options.IncludeSecurity = includeSecurity;
            return this;
        }

        /// <summary>
        /// Serializes as open API v2.
        /// </summary>
        /// <param name="serializeAsOpenApiV2">if set to <c>true</c> [serialize as open API v2].</param>
        /// <returns>ISwaggerOptionsBuilder.</returns>
        public ISwaggerOptionsBuilder SerializeAsOpenApiV2(bool serializeAsOpenApiV2)
        {
            options.SerializeAsOpenApiV2 = serializeAsOpenApiV2;
            return this;
        }

        /// <summary>
        /// Builds this instance.
        /// </summary>
        /// <returns>SwaggerOptions.</returns>
        public SwaggerOptions Build() => options;
    }
}