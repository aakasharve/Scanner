using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi.Models;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IO;

namespace Neighborly.Chassis.Swagger
{
    /// <summary>
    /// Class Extensions.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class ServiceCollectionExtensions
    {
        /// <summary>
        /// The section name
        /// </summary>
        private const string SectionName = "SwaggerSettings";
        /// <summary>
        /// The registry name
        /// </summary>
        private const string RegistryName = "docs.swagger";

        /// <summary>
        /// Adds the swagger docs.
        /// </summary>
        /// <param name="services">The builder.</param>
        /// <param name="sectionName">Name of the section.</param>
        /// <returns>INeighborlyBuilder.</returns>
        public static INeighborlyBuilder AddSwaggerDocs(this IServiceCollection services, string sectionName = SectionName)
        {
            if (string.IsNullOrWhiteSpace(sectionName))
            {
                sectionName = SectionName;
            }
            var builder = NeighborlyBuilder.Create(services);

            var options = builder.GetOptions<SwaggerOptions>(sectionName);
            return builder.AddSwaggerDocs(options);
        }

        /// <summary>
        /// Adds the swagger docs.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <param name="buildOptions">The build options.</param>
        /// <returns>INeighborlyBuilder.</returns>
        public static INeighborlyBuilder AddSwaggerDocs(this INeighborlyBuilder builder,
            Func<ISwaggerOptionsBuilder, ISwaggerOptionsBuilder> buildOptions)
        {
            var options = buildOptions(new SwaggerOptionsBuilder()).Build();
            return builder.AddSwaggerDocs(options);
        }

        /// <summary>
        /// Adds the swagger docs.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <param name="options">The options.</param>
        /// <returns>INeighborlyBuilder.</returns>
        public static INeighborlyBuilder AddSwaggerDocs(this INeighborlyBuilder builder, SwaggerOptions options)
        {
            if (!options.Enabled || !builder.TryRegister(RegistryName))
            {
                return builder;
            }

            builder.Services.AddSingleton(options);
            //Register the Swagger generator, defining 1 or more Swagger documents
            builder.Services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = options.Title, Version = options.Version });
                c.SwaggerDoc("v2", new OpenApiInfo() { Title = "Api version  2", Version = "v2", Description = "Test Description", });

                c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
                {
                    Description = @"JWT Authorization header using the Bearer scheme. <br /> 
                      Enter 'Bearer' [space] and then your token in the text input below.
                      <br />Example: 'Bearer 12345abcdef'",
                    Name = "Authorization",
                    In = ParameterLocation.Header,
                    Type = SecuritySchemeType.ApiKey,
                    Scheme = "Bearer"
                });

                c.AddSecurityRequirement(new OpenApiSecurityRequirement()
                {
                        {
                          new OpenApiSecurityScheme
                          {
                            Reference = new OpenApiReference
                              {
                                Type = ReferenceType.SecurityScheme,
                                Id = "Bearer"
                              },
                              Scheme = "oauth2",
                              Name = "Bearer",
                              In = ParameterLocation.Header,

                            },
                            new List<string>()
                          }
                });
                var filePath = Path.Combine(System.AppContext.BaseDirectory, "Template-Service.xml");
                c.IncludeXmlComments(filePath);
            }).AddSwaggerGenNewtonsoftSupport();

            return builder;
        }

        /// <summary>
        /// Uses the swagger docs.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <returns>IApplicationBuilder.</returns>
        public static IApplicationBuilder UseSwaggerDocs(this IApplicationBuilder builder)
        {

            var options = builder.ApplicationServices.GetService<SwaggerOptions>();
            if (!options!.Enabled)
            {
                return builder;
            }            

            var routePrefix = string.IsNullOrWhiteSpace(options.RoutePrefix) ? string.Empty : options.RoutePrefix;


            builder.UseSwagger(opt =>
                {
                    opt.PreSerializeFilters.Add((swaggerDoc, httpReq) =>
                    {
                        swaggerDoc.Servers = new List<OpenApiServer> { new OpenApiServer { Url = options.ServerUrl } };
                    });
                });

            return builder.UseSwaggerUI(options =>
            {

                options.DocumentTitle = "Template Service";
                options.SwaggerEndpoint($"/{routePrefix}/v1/swagger.json".FormatEmptyRoutePrefix(), $"v1");
                options.SwaggerEndpoint($"/{routePrefix}/v2/swagger.json".FormatEmptyRoutePrefix(), $"v2");
            });
        }

        /// <summary>
        /// Replaces leading double forward slash caused by an empty route prefix
        /// </summary>
        /// <param name="route">The route.</param>
        /// <returns>System.String.</returns>
        private static string FormatEmptyRoutePrefix(this string route)
        {
            return route.Replace("//", "/");
        }
    }
}