namespace Neighborly.Chassis.Logging
{
    /// <summary>
    /// Interface IMessageToLogTemplateMapper
    /// </summary>
    public interface IMessageToLogTemplateMapper
    {
        /// <summary>
        /// Maps the specified message.
        /// </summary>
        /// <typeparam name="TMessage">The type of the t message.</typeparam>
        /// <param name="message">The message.</param>
        /// <returns>HandlerLogTemplate.</returns>
        HandlerLogTemplate Map<TMessage>(TMessage message) where TMessage : class;
    }
}