﻿using Datadog.Trace;
using Microsoft.AspNetCore.Http;
using Neighborly.Chassis.Auth;
using Newtonsoft.Json;
using Serilog;
using Serilog.Context;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Logging
{
    /// <summary>
    /// Middleware to Add Additional property to serilog LogContext
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class SerilogEnricherMiddleware
    {
        readonly RequestDelegate _next;
        readonly ConcurrentDictionary<string, string> logContextDictionary = new();
        readonly ConcurrentDictionary<string, string> datadogInstrumentsDictionary = new();
        private readonly ILogger _logger;


        /// <summary>
        /// Constructor for Middleware
        /// </summary>
        /// <param name="next"></param>
        /// <param name="_logger"></param>
        public SerilogEnricherMiddleware(RequestDelegate next, ILogger _logger)
        {
            this._logger = _logger;
            if (next == null)
            {
                throw new ArgumentNullException(nameof(next));
            }

            _next = next;
        }

        /// <summary>
        /// Invoke method to intervene changes with Request Delegate
        /// </summary>
        /// <param name="httpContext"></param>
        /// <returns></returns>
        public async Task Invoke(HttpContext httpContext)
        {
            logContextDictionary.Clear();
            datadogInstrumentsDictionary.Clear();
            if (httpContext == null)
            {
                throw new ArgumentNullException(nameof(httpContext));
            }

            string? Oid, CompanyName, UserId;
            object? Action, Controller;
            GetHttpContextValues(httpContext, out Oid, out CompanyName, out UserId, out Action, out Controller);
            Microsoft.Extensions.Primitives.StringValues FsmContextHeader;
            FsmContext? FsmContextVal = null;
            if (httpContext.Request != null && httpContext.Request.Headers.TryGetValue("x-fsm-context", out FsmContextHeader))
            {
                FsmContextVal = JsonConvert.DeserializeObject<FsmContext>(FsmContextHeader.FirstOrDefault());
                logContextDictionary.TryAdd(nameof(FsmContextVal.BuId), FsmContextVal?.BuId?.ToString() ?? string.Empty);
                logContextDictionary.TryAdd(nameof(FsmContextVal.CoId), FsmContextVal?.CoId?.ToString() ?? string.Empty);
            }

            LogContextPush(Oid, CompanyName, UserId, Action, Controller);

            await CustomDatadogInstrumentationAsync(httpContext, FsmContextVal, CompanyName, Oid, UserId, httpContext.Request?.Path);

            await _next(httpContext);

        }

        private static void GetHttpContextValues(HttpContext httpContext, out string? Oid, out string? CompanyName, out string? UserId, out object? Action, out object? Controller)
        {
            Oid = httpContext.User?.Claims?.FirstOrDefault(x => x.Type == "oid")?.Value;
            CompanyName = httpContext.User?.Claims?.FirstOrDefault(x => x.Type == "company")?.Value;
            UserId = httpContext.User?.Claims?.FirstOrDefault(x => x.Type == "userId")?.Value;
            Action = httpContext.Request?.RouteValues?.FirstOrDefault(x => x.Key == "action").Value;
            Controller = httpContext.Request?.RouteValues?.FirstOrDefault(x => x.Key == "controller").Value;
        }

        private void LogContextPush(string? Oid, string? CompanyName, string? UserId, object? Action, object? Controller)
        {
            logContextDictionary.TryAdd(nameof(Oid), Oid ?? string.Empty);
            logContextDictionary.TryAdd(nameof(CompanyName), CompanyName ?? string.Empty);
            logContextDictionary.TryAdd(nameof(UserId), UserId ?? string.Empty);
            logContextDictionary.TryAdd(nameof(Action), Action?.ToString() ?? string.Empty);
            logContextDictionary.TryAdd(nameof(Controller), Controller?.ToString() ?? string.Empty);
            logContextDictionary.TryAdd("dd_trace_id", CorrelationIdentifier.TraceId.ToString());
            logContextDictionary.TryAdd("dd_span_id", CorrelationIdentifier.SpanId.ToString());
            logContextDictionary.ToList().ForEach(item =>
            {
                try
                {
                    LogContext.PushProperty(item.Key, item.Value);
                }
                catch (Exception)
                {
                    //Don't perform any action
                }
            });
        }

        private async Task CustomDatadogInstrumentationAsync(HttpContext httpContext, FsmContext? fsmContextVal, string? companyName, string? oid, string? userId, string? action)
        {
            var scope = Tracer.Instance.ActiveScope;
            if (scope != null)
            {
                InstrumentFsmContext(httpContext, fsmContextVal);
                InstrumentClaims(companyName, oid, userId);
                await InstrumentRequestValues(httpContext, action);
                SetTag(scope);
            }
        }

        private void SetTag(IScope scope)
        {
            datadogInstrumentsDictionary.ToList().ForEach(item =>
            {
                scope.Span.SetTag(item.Key, item.Value);
            });
        }

        private async Task InstrumentRequestValues(HttpContext httpContext, string? action)
        {
            var PathArr = action?.Split("/");
            var entity = PathArr?.ElementAtOrDefault(2);
            var request = httpContext.Request;

            if (request != null)
            {
                request.EnableBuffering();
                var buffer = new byte[Convert.ToInt32(request.ContentLength)];
                await request.Body.ReadAsync(buffer, 0, buffer.Length);
                //get body string here...
                var requestContent = Encoding.UTF8.GetString(buffer);

                _logger.Verbose("Request Payload", request.Method, request.Path, requestContent);
                request.Body.Position = 0;  //rewinding the stream to 0
                if ((requestContent.StartsWith("{")))
                {
                    try
                    {
                        var dict = JsonConvert.DeserializeObject<Dictionary<string, object>>(requestContent.ToLower());
                        InstrumentPayload(entity, requestContent, dict);
                    }
                    catch (Exception)
                    {
                        _logger.Warning("Could not deserialize -" + requestContent);
                    }
                }
            }
            InstrumentParams(httpContext);
        }

        private void InstrumentParams(HttpContext httpContext)
        {
            if (httpContext.Request?.Query != null && httpContext.Request.Query.Count > 0)
            {
                foreach (var item in httpContext.Request.Query)
                {
                    datadogInstrumentsDictionary.TryAdd(string.Concat("fsm.", item.Key), item.Value);
                }

            }
            if (httpContext.Request?.RouteValues != null && httpContext.Request?.RouteValues.Count > 0)
            {
                foreach (var routeVal in httpContext.Request.RouteValues)
                {
                    datadogInstrumentsDictionary.TryAdd(string.Concat("fsm.", routeVal.Key), routeVal.Value?.ToString() ?? string.Empty);
                }
            }
        }

        private void InstrumentPayload(string? entity, string requestContent, Dictionary<string, object>? dict)
        {
            if (!string.IsNullOrEmpty(requestContent) && dict != null)
            {
                datadogInstrumentsDictionary.TryAdd("fsm.Entity", entity ?? string.Empty);
                var keyList = new List<string>
                {
                    "id",
                    "name",
                    "companyid",
                    "companyname",
                    "customerid",
                    "workorderid",
                    "leadid",
                    "conceptId"
                };

                foreach (var key in keyList)
                {
                    if (dict.TryGetValue(key, out object? outVal))
                    {
                        datadogInstrumentsDictionary.TryAdd(string.Concat("fsm.", key), outVal?.ToString() ?? string.Empty);
                    }
                }
            }
        }

        private void InstrumentClaims(string? companyName, string? oid, string? userId)
        {
            datadogInstrumentsDictionary.TryAdd(string.Concat("fsm.", nameof(companyName), "-claims"), companyName ?? string.Empty);
            datadogInstrumentsDictionary.TryAdd(string.Concat("fsm.", nameof(oid)), oid ?? string.Empty);
            datadogInstrumentsDictionary.TryAdd(string.Concat("fsm.", nameof(userId)), userId ?? string.Empty);
        }

        private void InstrumentFsmContext(HttpContext httpContext, FsmContext? fsmContextVal)
        {
            if (fsmContextVal != null)
            {
                datadogInstrumentsDictionary.TryAdd(string.Concat("fsm.", nameof(fsmContextVal.BuId)), fsmContextVal?.BuId?.ToString() ?? string.Empty);
                datadogInstrumentsDictionary.TryAdd(string.Concat("fsm.", nameof(fsmContextVal.CoId)), fsmContextVal?.CoId?.ToString() ?? string.Empty);
                datadogInstrumentsDictionary.TryAdd(string.Concat("fsm.", nameof(fsmContextVal.CmId)), fsmContextVal?.CmId?.ToString() ?? string.Empty);
            }
            Microsoft.Extensions.Primitives.StringValues timeZone;
            if (httpContext.Request.Headers.TryGetValue("x-usertimezone", out timeZone))
            {
                datadogInstrumentsDictionary.TryAdd("fsm.UserTimeZone", timeZone.ToString() ?? string.Empty);
            }
        }
    }
}
