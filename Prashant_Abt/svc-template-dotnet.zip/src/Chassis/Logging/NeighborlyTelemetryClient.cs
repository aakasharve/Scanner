﻿using Microsoft.ApplicationInsights;
using Microsoft.ApplicationInsights.Extensibility;
using System;
using System.Threading;

namespace Neighborly.Chassis.Logging
{
    /// <summary>
    /// Class NeighborlyTelemetryClient.
    /// Implements the <see cref="System.IDisposable" />
    /// </summary>
    /// <seealso cref="System.IDisposable" />
    public class NeighborlyTelemetryClient : IDisposable
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="NeighborlyTelemetryClient"/> class.
        /// </summary>
        /// <param name="telemetryConfiguration">The telemetry configuration.</param>
        public NeighborlyTelemetryClient(TelemetryConfiguration telemetryConfiguration)
        {
            TelemetryClient = new TelemetryClient(telemetryConfiguration);
        }

        /// <summary>
        /// Gets the telemetry client.
        /// </summary>
        /// <value>The telemetry client.</value>
        public TelemetryClient TelemetryClient { get; }

        /// <summary>
        /// Performs application-defined tasks associated with freeing, releasing, or resetting unmanaged resources.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Releases unmanaged and - optionally - managed resources.
        /// </summary>
        /// <param name="disposing"><c>true</c> to release both managed and unmanaged resources; <c>false</c> to release only unmanaged resources.</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposing)
                return;
            TelemetryClient.Flush();
            Thread.Sleep(1000);
        }
    }
}
