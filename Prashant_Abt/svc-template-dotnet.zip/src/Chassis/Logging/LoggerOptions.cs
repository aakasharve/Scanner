using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Chassis.Logging
{

    /// <summary>
    ///  Class LoggerOptions.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class LoggerOptions
    {
        /// <summary>
        /// Gets or sets the level.
        /// </summary>
        /// <value>The level.</value>
        public string? Level { get; set; }
        /// <summary>
        /// Gets or sets the console.
        /// </summary>
        /// <value>The console.</value>
        public ConsoleOptions? Console { get; set; }
        /// <summary>
        /// Gets or sets the file.
        /// </summary>
        /// <value>The file.</value>
        public FileOptions? File { get; set; }

        /// <summary>
        /// Gets or sets the Application Insight Options
        /// </summary>
        /// <value>The application insight.</value>
        public ApplicationInsightOptions? ApplicationInsight { get; set; }
        /// <summary>
        /// Gets or sets the minimum level overrides.
        /// </summary>
        /// <value>The minimum level overrides.</value>
        public IDictionary<string, string>? MinimumLevelOverrides { get; set; }
        /// <summary>
        /// Gets or sets the exclude paths.
        /// </summary>
        /// <value>The exclude paths.</value>
        public IEnumerable<string>? ExcludePaths { get; set; }
        /// <summary>
        /// Gets or sets the exclude properties.
        /// </summary>
        /// <value>The exclude properties.</value>
        public IEnumerable<string>? ExcludeProperties { get; set; }
        /// <summary>
        /// Gets or sets the tags.
        /// </summary>
        /// <value>The tags.</value>
        public IDictionary<string, object>? Tags { get; set; }
        /// <summary>
        /// Request Payload Level
        /// </summary>
        public string? RequestPayloadLevel { get; set; }

    }
}