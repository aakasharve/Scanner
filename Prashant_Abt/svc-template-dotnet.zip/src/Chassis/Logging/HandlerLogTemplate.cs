using System;
using System.Collections.Generic;

namespace Neighborly.Chassis.Logging
{
    /// <summary>
    /// Class HandlerLogTemplate. This class cannot be inherited.
    /// </summary>
    public sealed class HandlerLogTemplate
    {
        /// <summary>
        /// Gets or sets the before.
        /// </summary>
        /// <value>The before.</value>
        public string? Before { get; set; }
        /// <summary>
        /// Gets or sets the after.
        /// </summary>
        /// <value>The after.</value>
        public string? After { get; set; }
        /// <summary>
        /// Gets or sets the on error.
        /// </summary>
        /// <value>The on error.</value>
        public IReadOnlyDictionary<Type, string> OnError { get; set; }

        /// <summary>
        /// Gets the exception template.
        /// </summary>
        /// <param name="ex">The ex.</param>
        /// <returns>System.String.</returns>
        public string GetExceptionTemplate(Exception ex)
        {
            var exceptionType = ex.GetType();

            if (OnError is null)
            {
                return null;
            }

            return OnError.TryGetValue(exceptionType, out var template) ? template : null;
        }
    }
}