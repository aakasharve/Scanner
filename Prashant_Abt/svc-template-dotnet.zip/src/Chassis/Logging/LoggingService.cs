﻿namespace Neighborly.Chassis.Logging
{
    /// <summary>
    /// Interface ILoggingService
    /// </summary>
    public interface ILoggingService
    {
        /// <summary>
        /// Sets the logging level.
        /// </summary>
        /// <param name="logEventLevel">The log event level.</param>
        public void SetLoggingLevel(string logEventLevel)
            => ServiceCollectionExtenstion.LoggingLevelSwitch.MinimumLevel = ServiceCollectionExtenstion.GetLogEventLevel(logEventLevel);


    }

    /// <summary>
    /// Class LoggingService.
    /// Implements the <see cref="ILoggingService" />
    /// </summary>
    /// <seealso cref="ILoggingService" />
    public class LoggingService : ILoggingService
    {

    }
}
