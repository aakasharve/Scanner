using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Scrutor;
using Serilog;
using Serilog.Core;
using Serilog.Events;
using Serilog.Filters;
using Serilog.Templates;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;


namespace Neighborly.Chassis.Logging
{
    /// <summary>
    /// Class Extensions.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class ServiceCollectionExtenstion
    {
        /// <summary>
        /// The logger section name
        /// </summary>
        private const string LoggerSectionName = "logger";
        /// <summary>
        /// The application section name
        /// </summary>
        private const string AppSectionName = "NeighborlyService";
        /// <summary>
        /// The logging level switch
        /// </summary>
        internal static readonly LoggingLevelSwitch LoggingLevelSwitch = new LoggingLevelSwitch();

        /// <summary>
        /// Uses the logging.
        /// </summary>
        /// <param name="hostBuilder">The host builder.</param>
        /// <param name="configure">The configure.</param>
        /// <param name="loggerSectionName">Name of the logger section.</param>
        /// <param name="appSectionName">Name of the application section.</param>
        /// <returns>IHostBuilder.</returns>
        public static IHostBuilder UseLogging(this IHostBuilder hostBuilder,
            Action<LoggerConfiguration> configure, string loggerSectionName = LoggerSectionName,
            string appSectionName = AppSectionName)
            => hostBuilder
                .ConfigureServices(services => services.AddSingleton<ILoggingService, LoggingService>())
                .UseSerilog((context, loggerConfiguration) =>
                {
                    if (string.IsNullOrWhiteSpace(loggerSectionName))
                    {
                        loggerSectionName = LoggerSectionName;
                    }

                    if (string.IsNullOrWhiteSpace(appSectionName))
                    {
                        appSectionName = AppSectionName;
                    }

                    var loggerOptions = context.Configuration.GetOptions<LoggerOptions>(loggerSectionName);
                    var appOptions = context.Configuration.GetOptions<NeighborlyServiceOptions>(appSectionName);

                    MapOptions(loggerOptions, appOptions, loggerConfiguration, context.HostingEnvironment.EnvironmentName);
                    configure?.Invoke(loggerConfiguration);
                });

        /// <summary>
        /// Uses the logging.
        /// </summary>
        /// <param name="webHostBuilder">The web host builder.</param>
        /// <param name="configure">The configure.</param>
        /// <param name="loggerSectionName">Name of the logger section.</param>
        /// <param name="appSectionName">Name of the application section.</param>
        /// <returns>IWebHostBuilder.</returns>
        public static IWebHostBuilder UseLogging(this IWebHostBuilder webHostBuilder,
            Action<LoggerConfiguration>? configure = null, string loggerSectionName = LoggerSectionName,
            string appSectionName = AppSectionName)
            => webHostBuilder
                .ConfigureServices(services => services.AddSingleton<ILoggingService, LoggingService>())
                .UseSerilog((context, loggerConfiguration) =>
                {
                    if (string.IsNullOrWhiteSpace(loggerSectionName))
                    {
                        loggerSectionName = LoggerSectionName;
                    }

                    if (string.IsNullOrWhiteSpace(appSectionName))
                    {
                        appSectionName = AppSectionName;
                    }

                    var loggerOptions = context.Configuration.GetOptions<LoggerOptions>(loggerSectionName);
                    var appOptions = context.Configuration.GetOptions<NeighborlyServiceOptions>(appSectionName);

                    MapOptions(loggerOptions, appOptions, loggerConfiguration,
                        context.HostingEnvironment.EnvironmentName.ToUpper().Substring(0, 3));
                    configure?.Invoke(loggerConfiguration);
                });

        /// <summary>
        /// Maps the log level handler.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <param name="endpointRoute">The endpoint route.</param>
        /// <returns>IEndpointConventionBuilder.</returns>
        public static IEndpointConventionBuilder MapLogLevelHandler(this IEndpointRouteBuilder builder,
            string endpointRoute = "~/logging/level")
            => builder.MapPost(endpointRoute, LevelSwitch);

        /// <summary>
        /// Maps the options.
        /// </summary>
        /// <param name="loggerOptions">The logger options.</param>
        /// <param name="appOptions">The application options.</param>
        /// <param name="loggerConfiguration">The logger configuration.</param>
        /// <param name="environmentName">Name of the environment.</param>
        private static void MapOptions(LoggerOptions loggerOptions, NeighborlyServiceOptions appOptions,
            LoggerConfiguration loggerConfiguration, string environmentName)
        {
            LoggingLevelSwitch.MinimumLevel = GetLogEventLevel(loggerOptions.Level);

            loggerConfiguration.Enrich.FromLogContext()
                .MinimumLevel.ControlledBy(LoggingLevelSwitch)
                .MinimumLevel.Override("Microsoft", LogEventLevel.Warning)
                .Enrich.WithProperty("Environment", environmentName)
                .Enrich.WithProperty("ApplicationName", appOptions.Name)
                .Enrich.WithProperty("Instance", appOptions.Instance)
                .Enrich.WithProperty("Version", appOptions.Version)
                .Enrich.WithCorrelationIdHeader("X-Correlation-ID")
                .Enrich.FromLogContext();

            foreach (var (key, value) in loggerOptions.Tags ?? new Dictionary<string, object>())
            {
                loggerConfiguration.Enrich.WithProperty(key, value);
            }

            foreach (var (key, value) in loggerOptions.MinimumLevelOverrides ?? new Dictionary<string, string>())
            {
                var logLevel = GetLogEventLevel(value);
                loggerConfiguration.MinimumLevel.Override(key, logLevel);
            }

            loggerOptions.ExcludePaths?.ToList().ForEach(p => loggerConfiguration.Filter
                .ByExcluding(Matching.WithProperty<string>("RequestPath", n => n.EndsWith(p))));


            loggerOptions.ExcludeProperties?.ToList().ForEach(p => loggerConfiguration.Filter
                .ByExcluding(Matching.WithProperty(p)));

            loggerOptions.ExcludePaths?.ToList().ForEach(p => loggerConfiguration.Filter
            .ByExcluding("RequestPath like '/health%'"));

            loggerOptions.ExcludePaths?.ToList().ForEach(p => loggerConfiguration.Filter
            .ByExcluding("RequestPath like '/swagger%'"));


            Configure(loggerConfiguration, loggerOptions);
        }

        /// <summary>
        /// Configures the specified logger configuration.
        /// </summary>
        /// <param name="loggerConfiguration">The logger configuration.</param>
        /// <param name="options">The options.</param>
        private static void Configure(LoggerConfiguration loggerConfiguration,
            LoggerOptions options)
        {
            var consoleOptions = options.Console ?? new ConsoleOptions();
            var fileOptions = options.File ?? new FileOptions();

            if (consoleOptions.Enabled)
            {
                loggerConfiguration.WriteTo.Console(new ExpressionTemplate("{ {time: @t, MSG: @m, Level: @l, exception: @x, Controller:Controller, Action:Action,UserId:UserId,CompanyName:CompanyName,Oid:Oid,CoId:CoId,BuId:BuId,ActionId:ActionId,ActionName:ActionName,RequestId:RequestId,RequestPath:RequestPath,Environment:Environment,ApplicationName:ApplicationName,Instance:Instance,Version:Version,CorrelationId:CorrelationId,dd_trace_id:dd_trace_id} }\n"));
            }

            if (fileOptions.Enabled)
            {
                var path = string.IsNullOrWhiteSpace(fileOptions.Path) ? "logs/logs.txt" : fileOptions.Path;
                if (!Enum.TryParse<RollingInterval>(fileOptions.Interval, true, out var interval))
                {
                    interval = RollingInterval.Day;
                }

                loggerConfiguration.WriteTo.File(path, rollingInterval: interval);
            }
        }

        /// <summary>
        /// Gets the log event level.
        /// </summary>
        /// <param name="level">The level.</param>
        /// <returns>LogEventLevel.</returns>
        internal static LogEventLevel GetLogEventLevel(string? level)
            => Enum.TryParse<LogEventLevel>(level, true, out var logLevel)
                ? logLevel
                : LogEventLevel.Debug;

        /// <summary>
        /// Adds the correlation context logging.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <returns>INeighborlyBuilder.</returns>
        public static INeighborlyBuilder AddCorrelationContextLogging(this INeighborlyBuilder builder)
        {
            builder.Services.AddTransient<CorrelationContextLoggingMiddleware>();

            return builder;
        }

        /// <summary>
        /// Users the correlation context logging.
        /// </summary>
        /// <param name="app">The application.</param>
        /// <returns>IApplicationBuilder.</returns>
        public static IApplicationBuilder UserCorrelationContextLogging(this IApplicationBuilder app)
        {
            app.UseMiddleware<CorrelationContextLoggingMiddleware>();

            return app;
        }

        /// <summary>
        /// Levels the switch.
        /// </summary>
        /// <param name="context">The context.</param>
        private static async Task LevelSwitch(HttpContext context)
        {
            var service = context.RequestServices.GetService<ILoggingService>();

            if (service is null)
            {
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
                await context.Response.WriteAsync("ILoggingService is not registered. Add UseLogging() to your Program.cs.");
                return;
            }

            var level = context.Request.Query["level"].ToString();

            if (string.IsNullOrEmpty(level))
            {
                context.Response.StatusCode = StatusCodes.Status400BadRequest;
                await context.Response.WriteAsync("Invalid value for logging level.");
                return;
            }

            service.SetLoggingLevel(level);

            context.Response.StatusCode = StatusCodes.Status200OK;
        }


        /// <summary>
        /// Adds the handler logging.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <param name="handlerType">Type of the handler.</param>
        /// <param name="decoratorType">Type of the decorator.</param>
        /// <param name="assembly">The assembly.</param>
        /// <returns>INeighborlyBuilder.</returns>
        private static INeighborlyBuilder AddHandlerLogging(this INeighborlyBuilder builder, Type handlerType,
            Type decoratorType, Assembly assembly = null)
        {
            assembly ??= Assembly.GetCallingAssembly();

            var handlers = assembly
                .GetTypes()
                .Where(t => t.GetInterfaces().Any(i => i.IsGenericType && i.GetGenericTypeDefinition() == handlerType))
                .ToList();

            handlers.ForEach(ch => GetExtensionMethods()
                .FirstOrDefault(mi => !mi.IsGenericMethod && mi.Name == "TryDecorate")?
                .Invoke(builder.Services, new object[]
                {
                    builder.Services,
                    ch.GetInterfaces().FirstOrDefault(),
                    decoratorType.MakeGenericType(ch.GetInterfaces().FirstOrDefault()?.GenericTypeArguments.First())
                }));

            return builder;
        }

        /// <summary>
        /// Gets the extension methods.
        /// </summary>
        /// <returns>IEnumerable&lt;MethodInfo&gt;.</returns>
        private static IEnumerable<MethodInfo> GetExtensionMethods()
        {
            var types = typeof(ReplacementBehavior).Assembly.GetTypes();

            var query = from type in types
                        where type.IsSealed && !type.IsGenericType && !type.IsNested
                        from method in type.GetMethods(BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic)
                        where method.IsDefined(typeof(ExtensionAttribute), false)
                        where method.GetParameters()[0].ParameterType == typeof(IServiceCollection)
                        select method;
            return query;
        }
    }
}