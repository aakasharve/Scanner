using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Logging
{
    /// <summary>
    /// Class CorrelationContextLoggingMiddleware.
    /// Implements the <see cref="IMiddleware" />
    /// https://vgaltes.com/post/forwarding-correlation-ids-in-aspnetcore-version-2/
    /// </summary>
    /// <seealso cref="IMiddleware" />
    public class CorrelationContextLoggingMiddleware : IMiddleware
    {
        /// <summary>
        /// The logger
        /// </summary>
        private readonly ILogger<CorrelationContextLoggingMiddleware> logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="CorrelationContextLoggingMiddleware" /> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        public CorrelationContextLoggingMiddleware(ILogger<CorrelationContextLoggingMiddleware> logger)
        {
            this.logger = logger;
        }

        /// <summary>
        /// Invokes the asynchronous.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="next">The next.</param>
        /// <returns>Task.</returns>
        public Task InvokeAsync(HttpContext context, RequestDelegate next)
        {
            //var headers = Activity.Current.Baggage
            //    .ToDictionary(x => x.Key, x => x.Value);
            //using (logger.BeginScope(headers))
            //{
            //    return next(context);
            //}

            return next(context);
        }
    }
}