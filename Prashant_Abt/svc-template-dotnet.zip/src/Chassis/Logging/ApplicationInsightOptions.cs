namespace Neighborly.Chassis.Logging
{
    /// <summary>
    /// Class ApplicationInsightOptions.
    /// </summary>
    public class ApplicationInsightOptions
    {
        /// <summary>
        /// Gets or sets a value indicating whether this <see cref="ApplicationInsightOptions" /> is enabled.
        /// </summary>
        /// <value><c>true</c> if enabled; otherwise, <c>false</c>.</value>
        public bool Enabled { get; set; }

        /// <summary>
        /// Gets or sets a InstrumentationKey <see cref="ApplicationInsightOptions" /> .
        /// </summary>
        /// <value>The instrumentation key.</value>
        public string? InstrumentationKey { get; set; }
    }
}