﻿using Neighborly.Service;
using System;
using System.Collections.Generic;

namespace Neighborly.Chassis.Auth
{
    /// <summary>
    /// Identity Helper Class
    /// </summary>
    public static class IdentityHelper
    {
        #region Identity jwt constants
        /// <summary>
        /// 
        /// </summary>
        public const string NAME = "name";
        /// <summary>
        /// 
        /// </summary>
        public const string EMAIL = "email";
        /// <summary>
        /// 
        /// </summary>
        public const string USER_ID = "userId";
        /// <summary>
        /// 
        /// </summary>
        public const string ROLES = "roles";
        /// <summary>
        /// 
        /// </summary>
        public const string CONCEPTS = "concepts";
        /// <summary>
        /// 
        /// </summary>
        public const string FRANCHISES = "franchises";
        /// <summary>
        /// 
        /// </summary>
        public const string BUSINESSUNITS = "businessUnits";
        /// <summary>
        /// 
        /// </summary>
        public const string COMPANYTENANTS = "companyTenants";
        /// <summary>
        /// 
        /// </summary>
        public const string SUB = "sub";
        /// <summary>
        /// 
        /// </summary>
        public const string OID = "oid";
        #endregion

        #region Public Member
        /// <summary>
        /// User Claim Class
        /// </summary>
        public class UserClaims
        {
            /// <summary>
            /// Name
            /// </summary>
            public string Name { get; set; } = null!;
            /// <summary>
            /// Email
            /// </summary>
            public string? Email { get; set; }
            /// <summary>
            /// UserId
            /// </summary>
            public string? UserId { get; set; }
            /// <summary>
            /// Roles
            /// </summary>
            public List<string>? Roles { get; set; }
            /// <summary>
            /// Sub
            /// </summary>
            public string? Sub { get; set; }
            /// <summary>
            /// Oid
            /// </summary>
            public string? Oid { get; set; }
            /// <summary>
            /// UserTimeZone
            /// </summary>
            public string? UserTimeZone { get; set; }
            /// <summary>
            /// Offset
            /// </summary>
            public string? Offset { get; set; }
            /// <summary>
            /// UserCultureCode
            /// </summary>
            public string? UserCultureCode { get; set; }
            /// <summary>
            /// IsExternalUser
            /// </summary>
            public bool IsExternalUser { get; set; }

            public FsmContext FsmContext { get; set; } = null!;
        }
        
        #endregion
    }
}
