﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Auth
{
    /// <summary>
    /// Class PublicPrivateMiddleware.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class PublicPrivateMiddleware
    {
        /// <summary>
        /// The next
        /// </summary>
        private readonly RequestDelegate _next;
        /// <summary>
        /// The claim type maps
        /// </summary>
        private readonly Dictionary<string, string> _claimTypeMaps;
        /// <summary>
        /// The bearer
        /// </summary>
        private const string Bearer = "Bearer";
        /// <summary>
        /// The API key
        /// </summary>
        private const string ApiKey = "api-key";

        /// <summary>
        /// Initializes a new instance of the <see cref="PublicPrivateMiddleware"/> class.
        /// </summary>
        /// <param name="next">The next.</param>
        /// <param name="claimTypeMaps">The claim type maps.</param>
        /// <exception cref="ArgumentNullException">claimTypeMaps</exception>
        public PublicPrivateMiddleware(RequestDelegate next, Dictionary<string, string> claimTypeMaps)
        {
            _next = next;
            _claimTypeMaps = claimTypeMaps ?? throw new ArgumentNullException(nameof(claimTypeMaps));
        }

        /// <summary>
        /// invoke as an asynchronous operation.
        /// </summary>
        /// <param name="context">The context.</param>
        public async Task InvokeAsync(HttpContext context)
        {
            if (!context.Request.Headers.ContainsKey("Authorization") && !context.Request.Headers.ContainsKey("api-key"))
            {
                context.Response.StatusCode = 401;
                await context.Response.WriteAsync("Unauthorized - Authorization header not found or Api key header is not found");
                return;
            }
            if (context.Request.Headers.ContainsKey("Authorization"))
            {
                var authHeader = context.Request.Headers["Authorization"].ToString();
                var tokenSplit = authHeader.Split(" ");

                if (!tokenSplit.First().Equals(Bearer, StringComparison.OrdinalIgnoreCase) || tokenSplit.Length < 2)
                {
                    context.Response.StatusCode = 401;
                    await context.Response.WriteAsync("Unauthorized - Bearer not found");
                    return;
                }


                try
                {
                    var handler = new JwtSecurityTokenHandler();
                    var token = handler.ReadJwtToken(tokenSplit[1]);

                    var identity = new ClaimsIdentity(Bearer);

                    foreach (var claim in token.Claims)
                    {
                        if (claim.Type == "role")
                        {
                            var roles = claim.Value.Split(',');
                            foreach (var role in roles)
                            {
                                identity.AddClaim(new Claim(ClaimTypes.Role, role));
                            }
                            identity.AddClaim(new Claim(ClaimTypes.Role, "private"));
                        }
                        else
                        {
                            if (_claimTypeMaps.ContainsKey(claim.Type))
                            {
                                identity.AddClaim(new Claim(_claimTypeMaps[claim.Type], claim.Value));
                            }
                            else
                            {
                                identity.AddClaim(new Claim(claim.Type, claim.Value));
                            }

                        }

                    }
                    context.User = new ClaimsPrincipal(identity);
                }
                catch (Exception)
                {
                    await context.Response.WriteAsync("Unauthorized - Unable to parse the JWT token");
                    return;
                }
            }
            else
            {
                try
                {
                    var authHeader = context.Request.Headers["api-key"].ToString();
                    var identity = new ClaimsIdentity(ApiKey);
                    var claims = new List<Claim>
                    {
                        new Claim("api-key", authHeader),
                        new Claim("role","public")
                    };
                    foreach (var claim in claims)
                    {
                        if (claim.Type == "role")
                        {
                            var roles = claim.Value.Split(',');
                            foreach (var role in roles)
                            {
                                identity.AddClaim(new Claim(ClaimTypes.Role, role));
                            }
                        }
                        else
                        {
                            identity.AddClaim(new Claim(claim.Type, claim.Value));
                        }
                    }
                    context.User = new ClaimsPrincipal(identity);
                }
                catch (Exception)
                {
                    return;
                }
            }

            await _next(context);
        }
    }
}
