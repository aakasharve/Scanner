﻿using Microsoft.AspNetCore.Builder;
using Neighborly.Chassis.Logging;
using System.Collections.Generic;
using System.Security.Claims;

namespace Neighborly.Chassis.Auth
{
    /// <summary>
    /// Class ApplicationBuilderExtensions.
    /// </summary>
    public static class ApplicationBuilderExtensions
    {
        /// <summary>
        /// Uses the neighborly JWT parser for franforce identity.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <returns>IApplicationBuilder.</returns>
        public static IApplicationBuilder UseNeighborlyJwtParserForFranforceIdentity(
           this IApplicationBuilder builder)
        {
            Dictionary<string, string> claimTypeMaps = new Dictionary<string, string>();
            claimTypeMaps.Add("userId", ClaimTypes.NameIdentifier);
            claimTypeMaps.Add("userName", ClaimTypes.Email);
            claimTypeMaps.Add("role", ClaimTypes.Role);

            return builder.UseMiddleware<JwtParserMiddleware>(claimTypeMaps);
        }
        /// <summary>
        /// Uses the neighborly private public authorization.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <returns>IApplicationBuilder.</returns>
        public static IApplicationBuilder UseNeighborlyPrivatePublicAuthorization(
          this IApplicationBuilder builder)
        {
            Dictionary<string, string> claimTypeMaps = new Dictionary<string, string>();
            claimTypeMaps.Add("userId", ClaimTypes.NameIdentifier);
            claimTypeMaps.Add("userName", ClaimTypes.Email);
            claimTypeMaps.Add("role", ClaimTypes.Role);

            return builder.UseMiddleware<PublicPrivateMiddleware>(claimTypeMaps);
        }

        /// <summary>
        /// Uses the neighborly JWT parser for azure b2 c.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <returns>IApplicationBuilder.</returns>
        public static IApplicationBuilder UseNeighborlyJwtParserForAzureB2C(
           this IApplicationBuilder builder)
        {
            Dictionary<string, string> claimTypeMaps = new Dictionary<string, string>();
            claimTypeMaps.Add("neighborlyUserId", ClaimTypes.NameIdentifier);
            claimTypeMaps.Add("email", ClaimTypes.Email);

            return builder.UseMiddleware<JwtParserMiddleware>(claimTypeMaps);
        }

        /// <summary>
        /// Adding the middleware
        /// </summary>
        /// <param name="builder"></param>
        /// <returns></returns>
        public static IApplicationBuilder UseSerilogEnricherMiddleware(
           this IApplicationBuilder builder)
        {
            return builder.UseMiddleware<SerilogEnricherMiddleware>();
        }

        /// <summary>
        /// Uses the neighborly JWT parser.
        /// </summary>
        /// <param name="builder">The builder.</param>
        /// <param name="claimTypeMaps">The claim type maps.</param>
        /// <returns>IApplicationBuilder.</returns>
        public static IApplicationBuilder UseNeighborlyJwtParser(
           this IApplicationBuilder builder, Dictionary<string, string> claimTypeMaps)
        {
            return builder.UseMiddleware<JwtParserMiddleware>(claimTypeMaps);
        }
    }
}
