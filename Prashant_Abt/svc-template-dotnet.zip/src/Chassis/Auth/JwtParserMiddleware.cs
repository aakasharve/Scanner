﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Auth
{
    /// <summary>
    /// Class JwtParserMiddleware.
    /// </summary>
    [ExcludeFromCodeCoverage]
    internal class JwtParserMiddleware
    {
        /// <summary>
        /// The next
        /// </summary>
        private readonly RequestDelegate _next;
        /// <summary>
        /// The claim type maps
        /// </summary>
        private readonly Dictionary<string, string> _claimTypeMaps;
        /// <summary>
        /// The bearer
        /// </summary>
        private const string Bearer = "Bearer";

        /// <summary>
        /// Initializes a new instance of the <see cref="JwtParserMiddleware"/> class.
        /// </summary>
        /// <param name="next">The next.</param>
        /// <param name="claimTypeMaps">The claim type maps.</param>
        /// <exception cref="ArgumentNullException">claimTypeMaps</exception>
        public JwtParserMiddleware(RequestDelegate next, Dictionary<string, string> claimTypeMaps)
        {
            _next = next;
            _claimTypeMaps = claimTypeMaps ?? throw new ArgumentNullException(nameof(claimTypeMaps));
        }
        /// <summary>
        /// invoke as an asynchronous operation.
        /// </summary>
        /// <param name="context">The context.</param>
        public async Task InvokeAsync(HttpContext context)
        {

            Regex regExclude = new Regex("/public/.*|/public");
            var excludeCheck = regExclude.IsMatch(context.Request.Path);
            if (!context.Request.Path.StartsWithSegments("/health") && !excludeCheck)
            {

                if (!(context.Request.Headers.ContainsKey("Authorization")) && !(context.Request.Query.ContainsKey("jwt")))
                {
                    await context.SetUnauthorizedErrorResponse("Unauthorized - Token not found");
                    return;
                }
                var sToken = string.Empty;
                var authHeader = context.Request.Headers["Authorization"].ToString();
                var tokenSplit = authHeader.Split(" ");
                if (tokenSplit[0].ToLower() == Bearer.ToLower())
                {
                    if (!(String.IsNullOrEmpty(context.Request.Query["jwt"].ToString())))
                    {
                        //Ignore duplicate take the 1st item
                        sToken = context.Request.Query["jwt"][0].ToString().Trim();
                    }
                    else
                    {
                        if (!tokenSplit.First().Equals(Bearer, StringComparison.OrdinalIgnoreCase) || tokenSplit.Length < 2)
                        {
                            await context.SetUnauthorizedErrorResponse("Unauthorized - Token not found");
                            return;
                        }
                        sToken = tokenSplit[1];
                    }

                    try
                    {
                        var handler = new JwtSecurityTokenHandler();
                        var token = handler.ReadJwtToken(sToken);

                        var identity = new ClaimsIdentity(Bearer);

                        foreach (var claim in token.Claims)
                        {
                            if (_claimTypeMaps.ContainsKey(claim.Type))
                            {
                                identity.AddClaim(new Claim(_claimTypeMaps[claim.Type], claim.Value));
                            }
                            else
                            {
                                identity.AddClaim(new Claim(claim.Type, claim.Value));
                            }
                        }
                        context.User = new ClaimsPrincipal(identity);
                    }
                    catch (Exception)
                    {
                        await context.SetUnauthorizedErrorResponse("Unauthorized - Unable to parse the JWT token");
                        return;
                    }
                }
            }

            await _next(context);
        }
    }
}
