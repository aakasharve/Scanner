﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Auth
{
    [ExcludeFromCodeCoverage]
    public class FsmContext
    {
        /// <summary>
        /// Company Id
        /// </summary>
        public Guid? CmId { get; set; } = default!;
        /// <summary>
        /// Business Unit Id
        /// </summary>
        public Guid? BuId { get; set; } = default!;
        /// <summary>
        /// Business Group Id
        /// </summary>
        public Guid? BgId { get; set; } = default!;
        /// <summary>
        /// Line of Business Id
        /// </summary>
        public Guid? LoBId { get; set; } = default!;
        /// <summary>
        /// Concept Id
        /// </summary>
        public int? CoId { get; set; }

        /// <summary>
        /// EnterpriseId
        /// </summary>
        public Guid? EnId { get; set; }
        /// <summary>
        /// CombinedBusiness Unit Id
        /// </summary>
        public Guid? CbuId { get; set; } = default!;
    }
}
