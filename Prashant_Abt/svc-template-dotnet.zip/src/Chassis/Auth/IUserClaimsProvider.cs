﻿
using static Neighborly.Chassis.Auth.IdentityHelper;

namespace Neighborly.Chassis.Auth
{
    public interface IUserClaimsProvider
    {
        UserClaims GetUserClaims();
    }
}