﻿using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Auth
{
    /// <summary>
    /// Class HttpContextExtensions.
    /// </summary>
    internal static class HttpContextExtensions
    {
        /// <summary>
        /// Sets the unauthorized error response.
        /// </summary>
        /// <param name="context">The context.</param>
        /// <param name="errorMessage">The error message.</param>
        internal static async Task SetUnauthorizedErrorResponse(this HttpContext context, string errorMessage)
        {
            context.Response.StatusCode = StatusCodes.Status401Unauthorized;
            context.Response.ContentType = "application/json";
            await context.Response.WriteAsync(JsonConvert.SerializeObject(errorMessage));
        }
    }
}
