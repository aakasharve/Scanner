﻿
using Microsoft.AspNetCore.Http;
using Neighborly.Chassis.Formatter;
using Neighborly.Service;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using static Neighborly.Chassis.Auth.IdentityHelper;

namespace Neighborly.Chassis.Auth
{
    [ExcludeFromCodeCoverage]
    public class UserClaimsProvider : IUserClaimsProvider
    {
        #region Private Member 

        readonly IHttpContextAccessor httpContextAccessor;

        #endregion

        #region Constructor 

        public UserClaimsProvider(IHttpContextAccessor httpContextAccessor)
        {
            this.httpContextAccessor = httpContextAccessor;
        }

        #endregion

        #region Public Methods

        public UserClaims GetUserClaims()
        {
            var authHeader = httpContextAccessor.HttpContext.Request.Headers["Authorization"].ToString();

            var tokenSplit = authHeader.Split(" ");
            if (tokenSplit[0] == "api-key")
            {
                string fsmContextExternalUser = httpContextAccessor.HttpContext.Request.Headers["x-fsm-context"].ToString();
                var fsmContextDetailsExternalUser = JsonConvert.DeserializeObject<FsmContext>(fsmContextExternalUser);
                var userTimeZone = httpContextAccessor.HttpContext.Request.Headers["x-usertimezone"].ToString();
                return new UserClaims
                {
                    Name = "ApiKeyUser",
                    Sub = "ApiKeyUser",
                    Oid = "ApiKeyUser",
                    Offset = Constants.OFFSET,
                    UserCultureCode = Constants.USERCULTURECODE,
                    UserTimeZone = string.IsNullOrEmpty(userTimeZone) ? Constants.DEFAULT_TIMEZONE : userTimeZone,
                    IsExternalUser = true,
                    FsmContext = fsmContextDetailsExternalUser ?? new FsmContext()                    
                };
            }
            else
            {
                var name = httpContextAccessor.HttpContext.User?.Claims?.First(c => c.Type == NAME).Value;
                var userid = httpContextAccessor.HttpContext.User?.Claims?.FirstOrDefault(c => c.Type == USER_ID)?.Value;
                var sub = httpContextAccessor.HttpContext.User?.Claims?.First(c => c.Type == SUB).Value;
                var oid = httpContextAccessor.HttpContext.User?.Claims?.FirstOrDefault(c => c.Type == OID)?.Value;
                //Added time zone parameters
                var offset = httpContextAccessor.HttpContext.Request.Headers["x-offset"].ToString();
                var userCultureCode = httpContextAccessor.HttpContext.Request.Headers["user-culture-code"].ToString();
                var userTimeZone = httpContextAccessor.HttpContext.Request.Headers["x-usertimezone"].ToString();
                string fsmContext = httpContextAccessor.HttpContext.Request.Headers["x-fsm-context"].ToString();
                var fsmContextDetails = JsonConvert.DeserializeObject<FsmContext>(fsmContext);
             
                return new UserClaims
                {
                    Name = string.IsNullOrEmpty(name) ? "User" : name,
                    UserId = string.IsNullOrEmpty(userid) ? string.Empty : userid,
                    Sub = string.IsNullOrEmpty(sub) ? string.Empty : sub,
                    Oid = string.IsNullOrEmpty(oid) ? string.Empty : oid,
                    Offset = string.IsNullOrEmpty(offset) ? Constants.OFFSET : offset,
                    UserCultureCode = string.IsNullOrEmpty(userCultureCode) ? Constants.USERCULTURECODE : userCultureCode,
                    UserTimeZone = string.IsNullOrEmpty(userTimeZone) ? Constants.DEFAULT_TIMEZONE : userTimeZone,
                    IsExternalUser = false,
                    FsmContext = fsmContextDetails ?? new FsmContext()
                };
            }

        }

        #endregion
    }
}