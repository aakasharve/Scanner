﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Net;
using System.Net.Http;
using System.Text;

namespace Neighborly.Chassis.EtagCache
{
    /// <summary>
    /// EtagCacheCreateValidateAttribute Class
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class EtagCacheCreateValidateAttribute : ActionFilterAttribute
    {

        #region Private field
        private readonly IDistributedCache _cache;
        private readonly string _id;
        private readonly string _serviceName;
        private readonly IConfiguration _configuration;

        #endregion Private field

        #region Constructor and Override method
        /// <summary>
        /// Constructor EtagAttributeEnabled
        /// </summary>
        /// <param name="cache"></param>
        /// <param name="srviceName"></param>
        /// <param name="id"></param>
        public EtagCacheCreateValidateAttribute(string id, string srviceName, IDistributedCache cache, IConfiguration configuration)
        {
            _cache = cache;
            _id = id;
            _serviceName = srviceName;
            _configuration = configuration;

        }
        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="context"></param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (context.HttpContext != null && context.HttpContext.Request.Method == HttpMethod.Get.Method)
            {
                switch (context.HttpContext.Request.Method)
                {
                    case "GET":
                        CheckForModiFied(context);
                        break;
                }
            }
        }

        #endregion Constructor and Override method

        #region Private Method
        /// <summary>
        /// GET CheckForModiFied
        /// </summary>
        /// <param name="context"></param>
        private void CheckForModiFied(ActionExecutingContext context)
        {
            var isMVCCEnabled = _configuration.GetSection("EtagSettings:IsMVCCEnabled").Value;
            if (isMVCCEnabled == "True" && (context.HttpContext.Request.Method == HttpMethod.Get.Method &&
                        context.HttpContext.Response.StatusCode == (int)HttpStatusCode.OK))
            {
                var body = "";
                var content = JsonConvert.SerializeObject(string.Concat(body, Convert.ToString(DateTime.Now)));
                var key = EtagGenerator.GetIdFromGetRequest(context, _id, _serviceName);
                if (context.HttpContext.Request.Headers.Keys.Contains("If-None-Match"))
                {
                    if (_cache.GetString(key) != null)
                    {
                        if (_cache.GetString(key).ToString() == context.HttpContext.Request.Headers["If-None-Match"].ToString())
                        {
                            context.Result = new StatusCodeResult(304);
                        }
                    }
                    else
                    {
                        var etag = EtagGenerator.GetETag(context.HttpContext.Request.Path.ToString(), Encoding.UTF8.GetBytes(content));
                        _cache.SetString(key, '"' + etag.ToString() + '"');

                    }
                }
                else
                {
                    var etag = EtagGenerator.GetETag(context.HttpContext.Request.Path.ToString(), Encoding.UTF8.GetBytes(content));
                    _cache.SetString(key, '"' + etag.ToString() + '"');

                }
                context.HttpContext.Response.Headers.Append("ETag", _cache.GetString(key).ToString());
            }
        }
        #endregion Private Method
    }
}

