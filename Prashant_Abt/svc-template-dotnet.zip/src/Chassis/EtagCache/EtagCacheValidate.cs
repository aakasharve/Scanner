﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Caching.Distributed;
using System.Net.Http;
using System.Threading.Tasks;

namespace Neighborly.Chassis.EtagCache
{
    /// <summary>
    /// EtagCacheValidate Class
    /// </summary>
    public class EtagCacheValidateAttribute : ActionFilterAttribute
    {
        #region Private field
        private readonly IDistributedCache _cache;
        private readonly string _id;
        private readonly string _serviceName;
        #endregion Private field

        #region Constructor and Methods
        /// <param name="cache"></param>
        /// <param name="srviceName"></param>
        /// /// <param name="id"></param>
        public EtagCacheValidateAttribute(string id, IDistributedCache cache, string srviceName)
        {
            _cache = cache;
            _id = id;
            _serviceName = srviceName;

        }
        /// <summary>
        /// Clearing cache and response header
        /// </summary>
        /// <param name="context"></param>
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            context.HttpContext.Response.OnCompleted(async () => await Task.Run(() =>
            {
                var statusCode = context.HttpContext.Response.StatusCode;
                if ((context.HttpContext.Request.Method == HttpMethod.Put.Method || context.HttpContext.Request.Method == HttpMethod.Post.Method)
                    && statusCode == 200)
                {
                    var key = context.HttpContext.Response.Headers["ETagKey"].ToString();
                    if (_cache.GetString(key) != null)
                    {
                        _cache.Remove(key);
                        context.HttpContext.Response.Headers.Remove("ETagKey");
                    }
                }
            }));
        }

        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="context"></param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (context.HttpContext.Request.Method == HttpMethod.Put.Method
                || context.HttpContext.Request.Method != HttpMethod.Post.Method)
            {
                switch (context.HttpContext.Request.Method)
                {
                    case "PUT":
                    case "POST":
                        CheckConflict(context);
                        break;

                }
            }
        }

        /// <summary>
        ///Put CheckConflict 
        /// </summary>
        /// <param name="context"></param>
        private void CheckConflict(ActionExecutingContext context)
        {
            if (context.HttpContext.Request.Method == HttpMethod.Put.Method || context.HttpContext.Request.Method == HttpMethod.Post.Method)
            {
                var key = EtagGenerator.GetIdFromRequesDetectionForupdate(context, _id, _serviceName);
                if (_cache.GetString(key) != null)
                {
                    context.HttpContext.Response.Headers.Add("ETagKey", new[] { key });

                }

            }
        }

        #endregion  Constructor and Methods
    }
}
