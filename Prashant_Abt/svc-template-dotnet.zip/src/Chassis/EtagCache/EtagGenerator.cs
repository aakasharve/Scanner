﻿using Microsoft.AspNetCore.Mvc.Controllers;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

namespace Neighborly.Chassis.EtagCache
{
    /// <summary>
    /// EtagGenerator Class
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class EtagGenerator
    {
        /// <summary>
        /// Get Etag
        /// </summary>
        /// <param name="key"></param>
        /// <param name="contentBytes"></param>
        /// <returns></returns>
        public static string GetETag(string key, byte[] contentBytes)
        {

            var keyBytes = Encoding.UTF8.GetBytes(key);
            var combinedBytes = Combine(keyBytes, contentBytes);


            return GenerateETag(combinedBytes);
        }

        /// <summary>
        /// GenerateETag from body and Timestamp
        /// </summary>
        /// <param name="data"></param>
        /// <returns></returns>
        private static string GenerateETag(byte[] data)
        {
            using (var md5 = MD5.Create())
            {
                var hash = md5.ComputeHash(data);
                string hex = BitConverter.ToString(hash);
                return hex.Replace("-", "");
            }
        }

        /// <summary>
        /// Combine Timestamp and body content
        /// </summary>
        /// <param name="a"></param>
        /// <param name="b"></param>
        /// <returns></returns>
        private static byte[] Combine(byte[] a, byte[] b)
        {
            byte[] c = new byte[a.Length + b.Length];
            Buffer.BlockCopy(a, 0, c, 0, a.Length);
            Buffer.BlockCopy(b, 0, c, a.Length, b.Length);
            return c;
        }
        /// <summary>
        /// GetIdFromRequesDetectionForupdate
        /// </summary>
        /// <param name="context"></param>
        /// <param name="id"></param>
        /// <param name="servicename"></param>
        /// <returns></returns>
        public static string GetIdFromRequesDetectionForupdate(ActionExecutingContext context, string id, string servicename)
        {
            string Id = string.Empty;
            string[] parameterName = id.Split(':');
            switch (context.HttpContext.Request.Method)
            {

                case "PUT":
                case "POST":
                    var propertyInfo = context.ActionArguments[parameterName[1]].GetType().GetProperty(parameterName[0]);
                    if (propertyInfo != null)
                    {
                        Id = Convert.ToString(propertyInfo.GetValue(context.ActionArguments[parameterName[1]], null)) ?? string.Empty;
                        Id = Id + servicename;
                    }
                    break;
            }
            return Id;
        }

        /// <summary>
        /// GetIdFromGetRequest
        /// </summary>
        /// <param name="context"></param>
        /// <param name="id"></param>
        /// <param name="serviceName"></param>
        /// <returns></returns>
        public static string GetIdFromGetRequest(ActionExecutingContext context, string id, string serviceName)
        {
            string Id = string.Empty;
            switch (context.HttpContext.Request.Method)
            {
                case "GET":
                    var descriptor = context.ActionDescriptor as ControllerActionDescriptor;
                    if (descriptor != null)
                    {
                        var prop = descriptor.MethodInfo.GetParameters();
                        var propName = prop.FirstOrDefault(s => s.Name == id).Name;
                        if (propName != null && context.ActionArguments.ContainsKey(propName))
                        {
                            Id = context.ActionArguments[propName].ToString() ?? string.Empty;
                            Id = Id + serviceName;

                        }
                    }
                    break;
            }
            return Id;

        }


    }
}