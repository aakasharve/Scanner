﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Caching.Distributed;
using System.Net.Http;

namespace Neighborly.Chassis.EtagCache
{
    /// <summary>
    /// EtagCacheMVCC Class
    /// </summary>
    public class EtagCacheMvccAttribute : ActionFilterAttribute
    {
        #region Private field
        private readonly IDistributedCache _cache;
        private readonly string _id;
        private readonly string _serviceName;
        #endregion Private field

        #region Constructor and Methods

        /// <summary>
        /// EtagCacheMVCC Constructor
        /// </summary>
        /// <param name="id"></param>
        /// <param name="cache"></param>
        /// <param name="srviceName"></param>
        public EtagCacheMvccAttribute(string id, IDistributedCache cache, string srviceName)
        {
            _cache = cache;
            _id = id;
            _serviceName = srviceName;

        }

        /// <summary>
        /// OnActionExecuted clearing cache and response header
        /// </summary>
        /// <param name="context"></param>
        public override void OnActionExecuted(ActionExecutedContext context)
        {
            context.HttpContext.Response.OnCompleted(async () => await System.Threading.Tasks.Task.Run(() =>
            {
                var statusCode = context.HttpContext.Response.StatusCode;
                if ((context.HttpContext.Request.Method == HttpMethod.Put.Method || context.HttpContext.Request.Method == HttpMethod.Post.Method)
                    && statusCode == 200)
                {
                    var key = context.HttpContext.Response.Headers["ETagKey"].ToString();
                    if (_cache.GetString(key) != null)
                    {
                        _cache.Remove(key);
                        context.HttpContext.Response.Headers.Remove("ETagKey");
                    }
                }
            }));
        }
        /// <summary>
        /// OnActionExecuting
        /// </summary>
        /// <param name="context"></param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (context.HttpContext.Request.Method == HttpMethod.Put.Method
                || context.HttpContext.Request.Method == HttpMethod.Post.Method)
            {
                switch (context.HttpContext.Request.Method)
                {
                    case "PUT":
                    case "POST":
                        CheckConflict(context);
                        break;

                }
            }
        }

        /// <summary>
        ///Put CheckConflict 
        /// </summary>
        /// <param name="context"></param>
        private void CheckConflict(ActionExecutingContext context)
        {
            if (context.HttpContext.Request.Method == HttpMethod.Put.Method || context.HttpContext.Request.Method == HttpMethod.Post.Method)
            {
                var key = EtagGenerator.GetIdFromRequesDetectionForupdate(context, _id, _serviceName);
                if (_cache.GetString(key) != null)
                {
                    if (_cache.GetString(key).ToString() == context.HttpContext.Request.Headers["If-Match"].ToString())
                    {
                        context.HttpContext.Response.Headers.Add("ETagKey", new[] { key });
                    }
                    else
                    {
                        context.Result = new StatusCodeResult(409);
                    }

                }
                else
                {
                    context.Result = new StatusCodeResult(409);

                }
            }
        }

        #endregion Constructor and Methods
    }
}
