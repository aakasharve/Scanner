﻿using System;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Storage.Blobs
{
   /// <summary>
   /// Transaction abstraction
   /// </summary>
   public interface ITransaction : IDisposable
   {
      /// <summary>
      /// Commits the transaction
      /// </summary>
      /// <returns></returns>
      Task CommitAsync();
   }
}
