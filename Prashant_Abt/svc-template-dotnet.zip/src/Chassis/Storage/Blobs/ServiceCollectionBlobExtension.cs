﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Neighborly.Chassis.Storage.Blobs
{
    public static class ServiceCollectionBlobExtension
    {

        /// <summary>
        /// The section name
        /// </summary>
        private const string SectionName = "Storage";

        public static INeighborlyBuilder AddStorage(this IServiceCollection services, IConfiguration config, string sectionName = SectionName)
        {
            if (string.IsNullOrWhiteSpace(sectionName))
            {
                sectionName = SectionName;
            }

            var builder = NeighborlyBuilder.Create(services);
           
            //builder.Services.Configure<StorageOptions>(config.GetSection(SectionName));
            var options = builder.GetOptions<StorageOptions>(sectionName);
            builder.Services.AddSingleton<IBlobStorage>(x =>
            StorageFactory.Blobs.AzureBlobStorageWithSharedKey(
                     options.BlobCredentials.AccountName,
                     options.BlobCredentials.AccountKey)
            );
            

            return builder;
        }
    }
}
