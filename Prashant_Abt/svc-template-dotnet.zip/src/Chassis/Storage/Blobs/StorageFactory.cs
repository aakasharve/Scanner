﻿namespace Neighborly.Chassis.Storage.Blobs
{
   /// <summary>
   /// Helper syntax for creating instances of storage library objects
   /// </summary>
   public static class StorageFactory
   {
      private static readonly IBlobStorageFactory _blobs = new InternalBlobsFactory();

      /// <summary>
      /// Access to creating blobs
      /// </summary>
      public static IBlobStorageFactory Blobs => _blobs;


      class InternalBlobsFactory : IBlobStorageFactory
      {
      }

   }

   /// <summary>
   /// Crates blob storage implementations
   /// </summary>
   public interface IBlobStorageFactory
   {
   }

  

   /// <summary>
   /// Creates connection strings, acts as a helper
   /// </summary>
   public interface IConnectionStringFactory
   {

   }

   /// <summary>
   /// Module initialisation primitives
   /// </summary>
   public interface IModulesFactory
   {

   }

}