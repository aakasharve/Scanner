﻿namespace Neighborly.Chassis.Storage.Blobs
{
    public class StorageOptions
    {
        public BlobCredentials BlobCredentials { get; set; }
    }
    public class BlobCredentials
    {
        public string ConnectionString { get; set; }
        public string AccountName { get; set; }
        public string AccountKey { get; set; }
        public string Container { get; set; }
    }


}
