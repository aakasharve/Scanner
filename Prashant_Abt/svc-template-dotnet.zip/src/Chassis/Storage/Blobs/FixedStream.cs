﻿using System;
using System.IO;
using System.Threading.Tasks;

namespace Neighborly.Chassis.Storage.Blobs
{
    internal class FixedStream
    {
        private MemoryStream memoryStream;
        private object p1;
        private Func<object, Task> p2;

        public FixedStream(MemoryStream memoryStream, object p1, Func<object, Task> p2)
        {
            this.memoryStream = memoryStream;
            this.p1 = p1;
            this.p2 = p2;
        }
    }
}