﻿namespace Neighborly.Chassis.Storage.Blobs
{
   /// <summary>
   /// Known storage account prefixes
   /// </summary>
   public static class KnownPrefix
   {
      
      /// <summary>
      /// Azure Blob Storage
      /// </summary>
      public const string AzureBlobStorage = "azure.blob";

   }
}
