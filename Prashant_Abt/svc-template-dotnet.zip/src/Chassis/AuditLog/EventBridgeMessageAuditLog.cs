﻿namespace Neighborly.Chassis.AuditLog
{
    /// <summary>
    /// Event Bridge Message AuditLog
    /// </summary>
    /// <typeparam name="T"></typeparam>
    public class EventBridgeMessageAuditLog<T>
    {
        /// <summary>
        /// Audit entity message text
        /// </summary>
        public T? Message { get; set; }
    }
}
