﻿using Neighborly.Chassis.Mediator;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace Neighborly.Chassis.AuditLog
{
    [ExcludeFromCodeCoverage]
    public class AuditLogEvent : Event
    {
        /// <summary>
        ///AuditLogEvent
        /// </summary>
        /// <param name="auditLogEntity"></param>
       
        public AuditLogEvent(AuditLogEntity auditLogEntity)
        {
            this.auditLogEntity = auditLogEntity;
        }
        public AuditLogEntity auditLogEntity { get; set; }
    }
}
