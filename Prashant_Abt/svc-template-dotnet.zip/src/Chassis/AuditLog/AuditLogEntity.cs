﻿using System;
using static Neighborly.Service.Enums;

namespace Neighborly.Chassis.AuditLog
{
    /// <summary>
    /// AuditLogEntity
    /// </summary>
    public class AuditLogEntity
    {

        /// <summary>
        /// LoggingDateTime
        /// </summary>
        public long LoggedDateTime { get; set; }

        /// <summary>
        /// User Id
        /// </summary>
        public string? UserId { get; set; } = string.Empty;

        /// <summary>
        /// Concept Id
        /// </summary>
        public int? CoId { get; set; }

        /// <summary>
        /// Business Unit Id
        /// </summary>
        public Guid? BuId { get; set; } = default!;

        /// <summary>
        /// Company Id
        /// </summary>
        public Guid? CmId { get; set; } = default!;

        /// <summary>
        /// Business Group Id
        /// </summary>
        public Guid? BgId { get; set; } = default!;

        /// <summary>
        /// Line of Business Id
        /// </summary>
        public Guid? LoBId { get; set; } = default!;

        /// <summary>
        /// Enterprise Id
        /// </summary>
        public Guid? EnId { get; set; }

        /// <summary>
        /// Entity Id
        /// </summary>
        public string? EntityId { get; set; } = string.Empty;

        /// <summary>
        /// Entity Type
        /// </summary>
        public AuditEntityType EntityType { get; set; }

        /// <summary>
        /// Request Type
        /// </summary>
        public AuditRequestType RequestType { get; set; }

        /// <summary>
        /// Request uri path
        /// </summary>
        public string RequestUri { get; set; } = string.Empty;

        /// <summary>
        ///  Request status code
        /// </summary>
        public RequestStatusCode RequestStatus { get; set; } = RequestStatusCode.Ok;

        /// <summary>
        /// Request payload
        /// </summary>
        public string? RequestPayload { get; set; } = string.Empty;

        /// <summary>
        /// Error message
        /// </summary>
        public string ErrorMessage { get; set; } = string.Empty;

        /// <summary>
        /// Description
        /// </summary>
        public string? Description { get; set; }
        /// <summary>
        /// Username
        /// </summary>
        public string? Username { get; set; }
        /// <summary>
        /// EntityNumber
        /// </summary>
        public string? EntityNumber { get; set; }

        public string? OldValues { get; set; }
        public string? NewValues { get; set; }


    }
}


