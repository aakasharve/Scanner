﻿using Microsoft.EntityFrameworkCore.ChangeTracking;
using Neighborly.Chassis.Auth;
using Neighborly.Chassis.Helper;
using Neighborly.Service;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using static Neighborly.Service.Enums;

namespace Neighborly.Chassis.AuditLog
{
    [ExcludeFromCodeCoverage]
    public class AuditEntry
    {
        private readonly IUserClaimsProvider userClaimsProvider;
        public AuditEntry(EntityEntry entry, IUserClaimsProvider userClaimsProvider)
        {
            Entry = entry;
            this.userClaimsProvider = userClaimsProvider;
        }
        public EntityEntry Entry { get; }
        public string UserId { get; set; }

        public Dictionary<string, object> KeyValues { get; } = new Dictionary<string, object>();
        public Dictionary<string, List<string>> OldValues { get; } = new Dictionary<string, List<string>>();
        public Dictionary<string, List<string>> NewValues { get; } = new Dictionary<string, List<string>>();
        public AuditRequestType AuditType { get; set; }
        public List<string> ChangedColumns { get; } = new List<string>();

        public string EntityName { get; set; } = string.Empty;

        public string Description { get; set; }

        public string? EntityNumber { get; set; }
        public AuditLogEntity ToAudit()
        {
            var fsmContextDetails = userClaimsProvider.GetUserClaims().FsmContext;
            var audit = new AuditLogEntity();
            audit.BuId  = fsmContextDetails.BuId;
            audit.CoId = fsmContextDetails.CoId;
            audit.ErrorMessage = "";
            audit.BgId = fsmContextDetails.BgId;
            audit.CmId = fsmContextDetails.CmId;
            audit.EnId = fsmContextDetails.EnId;
            audit.EntityType = AuditEntityType.WorkOrder;
            audit.LoggedDateTime = DateTimeUtilities.ConvertDateTimeToEpoch(DateTime.UtcNow);
            audit.UserId = UserId;
            audit.RequestType = AuditType;
            audit.UserId = userClaimsProvider.GetUserClaims().UserId;
            audit.Username = userClaimsProvider.GetUserClaims().Name;
            audit.OldValues = OldValues.Count == 0 ? null : JsonConvert.SerializeObject(OldValues);
            audit.NewValues = NewValues.Count == 0 ? null : JsonConvert.SerializeObject(NewValues);
            audit.Description = Description?.Trim().Trim(',') ;
            audit.EntityNumber = EntityNumber;
            return audit;
        }
    }
}
