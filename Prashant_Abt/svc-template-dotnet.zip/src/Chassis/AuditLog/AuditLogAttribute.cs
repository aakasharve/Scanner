﻿using Amazon.EventBridge;
using Amazon.EventBridge.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Options;
using Neighborly.Chassis.Auth;
using Neighborly.Chassis.Formatter;
using Neighborly.Chassis.Helper;
using Neighborly.Service;
using Neighborly.Settings;
using Newtonsoft.Json;
using Serilog;
using System;
using System.Collections.Concurrent;
using System.Diagnostics.CodeAnalysis;
using System.Text;
using static Neighborly.Service.Enums;

namespace Neighborly.Chassis.AuditLog
{
    /// <summary>
    /// class AuditLogAttribute
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class AuditLogAttribute : ActionFilterAttribute
    {
        /// <summary>
        /// The logger
        /// </summary>
        protected readonly ILogger logger;
      
        /// <summary>
        /// IAmazonEventBridge
        /// </summary>
        private readonly IAmazonEventBridge amazonEventBridgeClient;
        /// <summary>
        /// id
        /// </summary>
        private readonly string _id;
        /// <summary>
        /// EntityNumber
        /// </summary>
        private readonly string? EntityNumber;
        /// <summary>
        /// operationText
        /// </summary>
        private readonly string? operationDiscription;

        /// <summary>
        /// ConcurrentDictionary
        /// </summary>
        private readonly ConcurrentDictionary<string, string> requestBody = new ConcurrentDictionary<string, string>();
        /// <summary>
        /// AWS Configuration
        /// </summary>
        private readonly AWSConfig config;
        /// <summary>
        /// auditEntityType
        /// </summary>
        private readonly AuditEntityType auditEntityType;

        private readonly IUserClaimsProvider userClaimsProvider;

        /// <summary>
        /// AuditConfig
        /// </summary>
        private readonly AuditConfig auditConfig;

        #region Constants
        public const string CONCEPTS = "coids";
        public const string FRANCHISES = "frids";
        public const string BUSINESSUNITS = "buids";
        public const string COMPANYTENANTS = "tid";
        public const string USERID = "userId";
        public const string BUSINESSGROUPS = "bgsid";
        public const string COMPANYID = "cid";
        public const string ENTERPRISEID = "eid";
        #endregion Constants

        /// <summary>
        /// AuditLogAttribute
        /// </summary>
        /// <param name="id"></param>
        /// <param name="logger"></param>
        /// <param name="auditType"></param>
        /// <param name="amazonEventBridgeClient"></param>
        /// <param name="config"></param>
        /// <param name="userClaimsProvider"></param>
        /// <param name="EntityNumber"></param>
        /// <param name="operationDiscription"></param>
        /// <param name="auditConfig"></param>
        public AuditLogAttribute(string id, ILogger logger, AuditEntityType auditType, IAmazonEventBridge amazonEventBridgeClient, IOptions<AWSConfig> config,
            IUserClaimsProvider userClaimsProvider, string? EntityNumber, string? operationDiscription, IOptions<AuditConfig> auditConfig)
        {
            _id = id;
            this.logger = logger;
            this.auditEntityType = auditType;
            this.amazonEventBridgeClient = amazonEventBridgeClient;
            this.config = config.Value;
            this.userClaimsProvider = userClaimsProvider;
            this.EntityNumber = EntityNumber;
            this.operationDiscription = operationDiscription;
            this.auditConfig = auditConfig.Value;
        }
        /// <summary>
        /// OnActionExecuted to prepare audit log request to pushed the service bus
        /// </summary>
        /// <param name="context"></param>
        public override async void OnActionExecuted(ActionExecutedContext context)
        {
            if (auditConfig.IsAuditEnabled)
            {
                try
                {
                    string? requestPayLoad = string.Empty;
                    string? entityId = string.Empty;
                    string? entityNumber = string.Empty;
                    object responseBody = string.Empty;
                    requestBody.TryGetValue(context.HttpContext.TraceIdentifier, out requestPayLoad);
                    requestBody.TryGetValue(context.HttpContext.TraceIdentifier + _id, out entityId);
                    string? Propvalue = string.Empty;
                    if (context.Result != null)
                    {
                        responseBody = ((CustomApiResponse)((ObjectResult)context.Result).Value).Result;
                    }
                    var propertyInfo = (responseBody.GetType().GetProperty(_id) == null ? null : responseBody.GetType().GetProperty(_id));
                    if (propertyInfo != null)
                    {
                        Propvalue = propertyInfo.GetValue(responseBody, null) == null ? string.Empty : propertyInfo?.GetValue(responseBody, null)?.ToString();
                    }
                    //Getting entityNumber i.e autonumber for work order
                    var entityAutoNumber = responseBody.GetType().GetProperty(EntityNumber) == null ? null : responseBody.GetType().GetProperty(EntityNumber);
                    if (entityAutoNumber != null)
                    {
                        entityNumber = entityAutoNumber.GetValue(responseBody, null) == null ? string.Empty : entityAutoNumber?.GetValue(responseBody, null)?.ToString();
                    }

                    Propvalue = string.IsNullOrEmpty(Propvalue) ? entityId : Propvalue;
                    var fsmContextDetails = userClaimsProvider.GetUserClaims().FsmContext;
                    AuditLogEntity auditRequest = new AuditLogEntity
                    {
                        BuId = fsmContextDetails.BuId ?? Guid.Parse(Constants.DEFAULT_BUSINESSUNIT),
                        CoId = fsmContextDetails.CoId ?? 0,
                        EntityId = Propvalue,
                        EntityType = auditEntityType,
                        ErrorMessage = (context.Exception == null ? string.Empty : context.Exception.Message.ToString()),
                        BgId = fsmContextDetails.BgId ?? Guid.Empty,
                        CmId = fsmContextDetails.CmId ?? Guid.Empty,
                        EnId = Guid.NewGuid(),//need to change from fsm context when enid on place
                        LoggedDateTime = DateTimeUtilities.ConvertDateTimeToEpoch(DateTime.UtcNow),
                        RequestPayload = requestPayLoad,
                        RequestStatus = (RequestStatusCode)context.HttpContext.Response.StatusCode,
                        RequestType = AuditHelper.GetRequestType(context.HttpContext.Request.Method),
                        RequestUri = context.HttpContext.Request.Host + context.HttpContext.Request.Path.ToString(),
                        UserId = userClaimsProvider.GetUserClaims().UserId,
                        Description = string.Format(operationDiscription, entityNumber),
                        Username = userClaimsProvider.GetUserClaims().Name,
                        EntityNumber = entityNumber
                    };
                    PutEventsRequest putEventsRequest = AuditHelper.CreateEventBusAuditLogData(auditRequest, config.EventBus);
                    await amazonEventBridgeClient.PutEventsAsync(putEventsRequest);
                }
                catch (Exception ex)
                {
                    logger.Error(ex, "HandleAsync: AuditLogAttribute.cs");
                }
            }
        }

        /// <summary>
        /// OnActionExecuting to prepare audit log request to pushed the service bus
        /// </summary>
        /// <param name="context"></param>
        public override void OnActionExecuting(ActionExecutingContext context)
        {
            if (auditConfig.IsAuditEnabled)
            {
                StringBuilder sb = new StringBuilder();
                foreach (var arg in context.ActionArguments)
                {
                    sb.Append(arg.Key.ToString() + ":" + JsonConvert.SerializeObject(arg.Value) + "\n");
                }
                requestBody.TryAdd(context.HttpContext.TraceIdentifier, sb.ToString());
                requestBody.TryAdd(context.HttpContext.TraceIdentifier + _id, GetEntityId(context));
            }
        }

        /// <summary>
        /// GetEntityId
        /// </summary>
        /// <param name="context"></param>
        /// <returns></returns>
        private string GetEntityId(ActionExecutingContext context)
        {
            string Id = string.Empty;
            string[] parameterName = _id.Split(':');
            if (parameterName.Length == 2)
            {
                var propertyInfo = context.ActionArguments[parameterName[0]].GetType().GetProperty(parameterName[1]);
                if (propertyInfo != null)
                {
                    return Convert.ToString(propertyInfo.GetValue(context.ActionArguments[parameterName[0]], null)) ?? Id;
                }
            }
            return Id;
        }
    }
}
