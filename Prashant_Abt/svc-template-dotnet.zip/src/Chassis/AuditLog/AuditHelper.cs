﻿using Amazon.EventBridge.Model;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using static Neighborly.Service.Constants;
using static Neighborly.Service.Enums;

namespace Neighborly.Chassis.AuditLog
{
    /// <summary>
    /// class AuditHelper
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class AuditHelper
    {
        /// <summary>
        /// CreateEventBusAuditLogData
        /// </summary>
        /// <param name="request"></param>
        /// <param name="eventBusName"></param>
        /// <returns></returns>        
        public static PutEventsRequest CreateEventBusAuditLogData(AuditLogEntity request, string eventBusName)
        {
            PutEventsRequest putEventsRequest = new PutEventsRequest()
            {
                Entries = new List<PutEventsRequestEntry>()
                {
                    new PutEventsRequestEntry()
                    {
                       Source = EventBridgeConstant.Template,
                       EventBusName = eventBusName,
                       DetailType = EventBridgeConstant.Template,
                       Detail = JsonConvert.SerializeObject(
                       new EventBridgeMessageAuditLog<AuditLogEntity>
                       {
                             Message = new AuditLogEntity
                             {
                                 BuId = request.BuId,
                                 CoId = request.CoId,
                                 EntityId = request.EntityId,
                                 EntityType = request.EntityType,
                                 CmId = request.CmId,
                                 BgId = request.BgId,
                                 EnId = request.EnId,
                                 LoBId=request.LoBId,
                                 ErrorMessage = request.ErrorMessage,
                                 LoggedDateTime = request.LoggedDateTime,
                                 RequestPayload = request.RequestPayload,
                                 RequestStatus = request.RequestStatus,
                                 RequestType = request.RequestType,
                                 RequestUri = request.RequestUri,
                                 UserId = request.UserId,
                                 Description=request.Description,
                                 EntityNumber=request.EntityNumber,
                                 Username=request.Username,
                                 OldValues=request.OldValues,
                                 NewValues=request.NewValues
                             }
                       })
                    }
                }
            };
            return putEventsRequest;
        }

        /// <summary>
        /// Get http request type
        /// </summary>
        /// <param name="method"></param>
        /// <returns></returns>
        public static AuditRequestType GetRequestType(string method)
        {
            AuditRequestType type = new AuditRequestType();
            switch (method)
            {
                case "PUT":
                    type = AuditRequestType.Update;
                    break;
                case "POST":
                    type = AuditRequestType.Create;
                    break;
                case "GET":
                    type = AuditRequestType.GET;
                    break;
                case "DELETE":
                    type = AuditRequestType.Delete;
                    break;
            }
            return type;
        }

        public static class EntityConstant
        {
            /// <summary>
            /// MasterEntity
            /// </summary>
            public const string WORKORDER = "WorkOrders";

            /// <summary>
            /// WORKORDERENTITY
            /// </summary>
            public const string WORKORDERENTITY = "Work Order";

            /// <summary>
            /// WORKORDERENTITY
            /// </summary>
            public const string LINEITEM = "WorkOrderLineItem";

            /// <summary>
            /// WORKORDERENTITY
            /// </summary>
            public const string NOTES = "Notes";
            /// <summary>
            /// CUSTOMERADDITIONALDETAILS
            /// </summary>
            public const string CUSTOMERADDITIONALDETAILS = "CustomerAdditionalDetails";
        }
    }
}
