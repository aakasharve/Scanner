﻿
using Amazon.EventBridge;
using Amazon.EventBridge.Model;
using Microsoft.Extensions.Options;
using Neighborly.Service.BaseEvent;
using Neighborly.Settings;
using Serilog;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Neighborly.Chassis.AuditLog
{
    [ExcludeFromCodeCoverage]
    public class AuditLogEventHandler : ItemCreatedEventHandler<AuditLogEvent>
    {
        /// <summary>
        /// AWS Configuration
        /// </summary>
        private readonly AWSConfig config;
        /// <summary>
        /// IAmazonEventBridge
        /// </summary>
        private readonly IAmazonEventBridge amazonEventBridgeClient;
        public AuditLogEventHandler(ILogger logger, IAmazonEventBridge amazonEventBridgeClient, IOptions<AWSConfig> config) : base(logger)
        {
            this.amazonEventBridgeClient = amazonEventBridgeClient;
            this.config = config.Value;
        }

        public override async Task HandleAsync(AuditLogEvent evt, CancellationToken ct)
        {
            logger.Debug($"Executing Event handler:{0}", typeof(AuditLogEventHandler));
            PutEventsRequest putEventsRequest = AuditHelper.CreateEventBusAuditLogData(evt.auditLogEntity, config.EventBus);
            await amazonEventBridgeClient.PutEventsAsync(putEventsRequest);
        }
    }
}
