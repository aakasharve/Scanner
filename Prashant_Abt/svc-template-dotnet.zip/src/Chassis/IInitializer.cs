﻿using System.Threading.Tasks;

namespace Neighborly.Chassis
{
    /// <summary>
    /// Interface IInitializer
    /// </summary>
    public interface IInitializer
    {
        /// <summary>
        /// Initializes the asynchronous.
        /// </summary>
        /// <returns>Task.</returns>
        Task InitializeAsync();
    }
}