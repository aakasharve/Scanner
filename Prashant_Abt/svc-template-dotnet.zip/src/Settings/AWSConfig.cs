﻿namespace Neighborly.Settings
{
    /// <summary>
    /// AWS Config
    /// </summary>
    /// <summary>
    /// ASW Configuration
    /// </summary>
    public class AWSConfig
    {
        /// <summary>
        /// Event Bus
        /// </summary>
        public string EventBus { get; set; } = null!;
        /// <summary>
        /// Region
        /// </summary>
        public string Region { get; set; } = null!;

        /// <summary>
        /// S3Bucket
        /// </summary>
        public string S3Bucket { get; set; } = null!;

        /// <summary>
        /// S3BucketFolder
        /// </summary>
        public string S3BucketFolder { get; set; } = null!;
        /// <summary>
        /// S3PreSignedUrlExpirationInMin
        /// </summary>
        public string S3PreSignedUrlExpirationInMin { get; set; } = null!;
    }
}
