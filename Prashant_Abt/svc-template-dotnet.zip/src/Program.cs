using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Hosting;
using Neighborly.Chassis;
using Neighborly.Chassis.Logging;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly
{
    /// <summary>
    /// Class Program.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class Program
    {
        /// <summary>
        /// Defines the entry point of the application.
        /// </summary>
        /// <param name="args">The arguments.</param>
        public static void Main(string[] args)
        {
            CreateHostBuilder(args).Build().Run();
        }
        /// <summary>
        /// Creates the host builder.
        /// </summary>
        /// <param name="args">The arguments.</param>
        /// <returns>IHostBuilder.</returns>
        public static IHostBuilder CreateHostBuilder(string[] args)
        {
            return Host.CreateDefaultBuilder(args).ConfigureWebHostDefaults(webBuilder =>
            {
                webBuilder.ConfigureServices(services => services
                        .AddNeighborly()
                        .AddCorrelationContextLogging()
                        .Build())
                    .Configure(app => app
                        .UseNeighborly())
                    .UseLogging();
                webBuilder.UseStartup<Startup>();
            });
        }
    }
}
