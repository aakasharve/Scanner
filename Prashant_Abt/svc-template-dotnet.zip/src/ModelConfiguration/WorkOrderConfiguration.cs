﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Neighborly.Service.WorkOrder.Domain;

namespace Neighborly.ModelConfiguration
{
    /// <summary>
    /// Work Order Configuration
    /// </summary>
    public class WorkOrderConfiguration : IEntityTypeConfiguration<WorkOrder>
    {
        /// <summary>
        /// Configure
        /// </summary>
        /// <param name="builder"></param>
        public void Configure(EntityTypeBuilder<WorkOrder> builder)
        {
            builder.ToTable("ts_workorder");
            builder.HasKey(e => e.Id);

            builder.Property(e => e.Id)
                .HasColumnName("WorkOrderId");

            builder.HasIndex(e => e.CustomerId).IsClustered(false);
        }
    }
}
