﻿
namespace Neighborly.ModelConfiguration
{
    /// <summary>
    /// Constants 
    /// </summary>
    public static class Constants
    {
        #region Entity

        /// <summary>
        /// Service Appointment Entity
        /// </summary>
        public const string SERVICE_APPOINTMENT = "ServiceAppointmentEntity";
        /// <summary>
        /// Assigned Workforce Resource Entity
        /// </summary>
        public const string ASSIGNED_WORKFORCE_RESOURCE = "AssignedWorkforceResource";

        #endregion
    }
}
