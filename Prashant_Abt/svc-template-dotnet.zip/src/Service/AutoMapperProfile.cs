﻿using AutoMapper;
using WorkOrderDomain = Neighborly.Service.WorkOrder.Domain;
using Neighborly.Service.WorkOrder.Models.Response;

namespace Neighborly.Service
{
    /// <summary>
    ///  Auto mapper Profile Class
    /// </summary>
    public class AutoMapperProfile : Profile
    {
        /// <summary>
        /// Auto mapper Profile
        /// </summary>
        public AutoMapperProfile()
        {
            CreateMap<WorkOrderDomain.WorkOrder, WorkOrderResponse>();
        }
    }
    /// <summary>
    /// MappingExpressionExtensions
    /// </summary>
    public static class MappingExpressionExtensions
    {
        /// <summary>
        /// IgnoreAllUnmapped
        /// </summary>
        /// <typeparam name="TSource"></typeparam>
        /// <typeparam name="TDest"></typeparam>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static IMappingExpression<TSource, TDest> IgnoreAllUnmapped<TSource, TDest>(this IMappingExpression<TSource, TDest> expression)
        {
            expression.ForAllMembers(opt => opt.Ignore());
            return expression;
        }
    }
}