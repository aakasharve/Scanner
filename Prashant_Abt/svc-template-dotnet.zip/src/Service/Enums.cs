﻿
namespace Neighborly.Service
{
    /// <summary>
    /// Enum Class
    /// </summary>
    public static class Enums
    {
        /// <summary>
        /// Appointment Type
        /// </summary>
        public enum AppointmentType
        {
            /// <summary>
            /// Appointment Type New
            /// </summary>
            New = 1,

            /// <summary>
            /// Appointment Type Reclean
            /// </summary>
            Reclean = 2,

            /// <summary> 
            /// Appointment Type LTR
            /// </summary>
            LTR = 3,

            /// <summary>
            /// Appointment Type Other
            /// </summary>
            Other = 4,

            /// <summary>
            /// Appointment Type Assessment
            /// </summary>
            Assessment = 5,

            /// <summary>
            /// Appointment Type MultiUnit
            /// </summary>
            MultiUnit = 6,

            /// <summary>
            /// Appointment Type Estimate
            /// </summary>
            Estimate = 7
        }

        /// <summary>
        /// Workorder Status
        /// </summary>
        public enum Status
        {
            /// <summary>
            /// Workorder Status Scheduled
            /// </summary>
            Scheduled = 1,

            /// <summary>
            /// Workorder Status Assigned
            /// </summary>
            Assigned = 2,

            /// <summary>
            /// Workorder Status Dispatched
            /// </summary>
            Dispatched = 3,

            /// <summary>
            /// Workorder Status Arrived
            /// </summary>
            Arrived = 4,

            /// <summary>
            /// Workorder Status Completed
            /// </summary>
            Completed = 5,

            /// <summary>
            /// Workorder Status Canceled
            /// </summary>
            Canceled = 6,

            /// <summary>
            /// Workorder Status OnHoldCancelled
            /// </summary>
            OnHoldCancelled = 7,

            /// <summary>
            /// Workorder Status OnHoldRescheduled
            /// </summary>
            OnHoldRescheduled = 8,
            /// <summary>
            /// ApprovalPending
            /// </summary>
            ApprovalPending = 9,
            /// <summary>
            /// Approved
            /// </summary>
            Approved = 10,
            /// <summary>
            /// Converted
            /// </summary>
            Converted = 11
        }

        /// <summary>
        /// Discount Type e.g. Flag Rate or Percentage
        /// </summary>
        public enum DiscountType
        {
            /// <summary>
            /// Flat amount
            /// </summary>
            Flat = 1,
            /// <summary>
            /// Percentage
            /// </summary>
            Percent = 2
        }


        /// <summary>
        /// Priority
        /// </summary>
        public enum Priority
        {
            /// <summary>
            /// High
            /// </summary>
            High = 1,
            /// <summary>
            /// Standard
            /// </summary>
            Standard = 2,
            /// <summary>
            /// Low
            /// </summary>
            Low = 3
        }


        /// <summary>
        /// Message Type
        /// </summary>
        public enum MessageType
        {
            /// <summary>
            /// Message Type WorkOrderCreate
            /// </summary>
            WorkOrderCreate = 1,

            /// <summary>
            /// Message Type WorkOrderUpdate
            /// </summary>
            WorkOrderUpdate = 2,

            /// <summary>
            /// Message Type WorkOrderDelete
            /// </summary>
            WorkOrderDelete = 3,

            /// <summary>
            /// Message Type ManageLineItem
            /// </summary>
            ManageLineItem = 4,

            /// <summary>
            /// Message Type ManageNotes
            /// </summary>
            ManageNotes = 5
        }


        /// <summary>
        /// Notes Type
        /// </summary>
        public enum NotesType
        {
            /// <summary>
            /// Notes Type Public
            /// </summary>
            Public = 1,

            /// <summary>
            /// Notes Type Private
            /// </summary>
            Private = 2
        }


        /// <summary>
        /// Calendar View Mode
        /// </summary>
        public enum CalendarViewMode
        {
            /// <summary>
            /// Calendar View Mode DAY
            /// </summary>
            DAY = 1,

            /// <summary>
            /// Calendar View Mode Week
            /// </summary>
            Week = 2,

            /// <summary>
            /// Calendar View Mode MONTH
            /// </summary>
            MONTH = 3,

            /// <summary>
            /// DATERANGE
            /// </summary>
            DATERANGE = 4
        }

        /// <summary>
        /// Address Types
        /// </summary>
        public enum AddressTypes
        {
            /// <summary>
            /// BILLING
            /// </summary>
            BILLING = 1,
            /// <summary>
            /// SERVICE
            /// </summary>
            SERVICE = 2
        }


        /// <summary>
        /// VentingMaterial
        /// </summary>
        public enum VentingMaterial
        {
            /// <summary>
            /// VentingMaterial Aluminium
            /// </summary>
            Aluminium = 1,

            /// <summary>
            /// VentingMaterial Foil
            /// </summary>
            Foil = 2,

            /// <summary>
            /// VentingMaterial GalvySteel
            /// </summary>
            GalvySteel = 3,

            /// <summary>
            /// VentingMaterial Plastic
            /// </summary>
            Plastic = 4,

            /// <summary> 
            /// VentingMaterial PVC
            /// </summary>
            PVC = 5
        }


        /// <summary>
        /// TransitionMaterial
        /// </summary>
        public enum TransitionMaterial
        {
            /// <summary>
            /// TransitionMaterial Aluminium
            /// </summary>
            Aluminium = 1,

            /// <summary>
            /// TransitionMaterial Foil
            /// </summary>
            Foil = 2,

            /// <summary>
            /// TransitionMaterial GalvySteel
            /// </summary>
            GalvySteel = 3,

            /// <summary>
            /// TransitionMaterial Plastic
            /// </summary>
            Plastic = 4,

            /// <summary>
            /// TransitionMaterial PVC
            /// </summary>
            PVC = 5
        }


        /// <summary>
        /// MachineStyle
        /// </summary>
        public enum MachineStyle
        {
            /// <summary>
            /// MachineStyle FullStacked
            /// </summary>
            FullStacked = 1,

            /// <summary>
            /// MachineStyle AptStacked
            /// </summary>
            AptStacked = 2,

            /// <summary>
            /// MachineStyle SideBySide
            /// </summary>
            SideBySide = 3,

            /// <summary>
            /// MachineStyle Plastic
            /// </summary>
            Plastic = 4,

            /// <summary>
            /// MachineStyle Electric
            /// </summary>
            Electric = 5,

            /// <summary>
            /// MachineStyle Gas
            /// </summary>
            Gas = 6
        }


        /// <summary>
        /// LaundaryNook
        /// </summary>
        public enum LaundaryNook
        {
            /// <summary>
            /// LaundaryNook Open
            /// </summary>
            Open = 1,

            /// <summary>
            /// LaundaryNook Tight
            /// </summary>
            Tight = 2,

            /// <summary>
            /// LaundaryNook Obstructed
            /// </summary>
            Obstructed = 3,

            /// <summary>
            /// LaundaryNook OverflowPan
            /// </summary>
            OverflowPan = 4
        }


        /// <summary>
        /// VentHoodStyle
        /// </summary>
        public enum VentHoodStyle
        {
            /// <summary>
            /// VentHoodStyle Hood
            /// </summary>
            Hood = 1,

            /// <summary>
            /// VentHoodStyle Louver
            /// </summary>
            Louver = 2,

            /// <summary>
            /// VentHoodStyle Eave
            /// </summary>
            Eave = 3,

            /// <summary>
            /// VentHoodStyle Roof
            /// </summary>
            Roof = 4
        }


        /// <summary>
        /// ServiceUnitStatus
        /// </summary>
        public enum ServiceUnitStatus
        {
            /// <summary>
            /// ServiceUnitStatus Pending
            /// </summary>
            Pending = 1,

            /// <summary>
            /// ServiceUnitStatus Complete
            /// </summary>
            Complete = 2
        }


        /// <summary>
        /// VentingDesign
        /// </summary>
        public enum VentingDesign
        {
            /// <summary>
            /// Dedicated
            /// </summary>
            Dedicated = 1,

            /// <summary>
            /// StacksBranches
            /// </summary>
            StacksBranches = 2,

            /// <summary>
            /// BoosterFan
            /// </summary>
            BoosterFan = 3
        }

        /// <summary>
        /// AuditMessage
        /// </summary>
        public enum AuditMessage
        {
            /// <summary>
            /// AuditMessage AuditLogPushed
            /// </summary> 
            AuditLogPushed = 1
        }

        /// <summary>
        /// AuditEntityType
        /// </summary>
        public enum AuditEntityType
        {
            /// <summary>
            /// WorkOrder
            /// </summary>
            WorkOrder = 1,
            /// <summary>
            /// Leads
            /// </summary>
            Leads = 2,
            /// <summary>
            /// Invoice
            /// </summary>
            Invoice = 3,
            /// <summary>
            /// DispatchBoard
            /// </summary>
            DispatchBoard = 4,
            /// <summary>
            /// Customer
            /// </summary>
            Customer = 5,
            /// <summary>
            /// CompanySetup
            /// </summary>
            CompanySetup = 6,
            /// <summary>
            /// User
            /// </summary>
            User = 7,
            /// <summary>
            /// Tax
            /// </summary>
            Tax = 8,
            /// <summary>
            /// Discounts
            /// </summary>
            Discounts = 9,
            /// <summary>
            /// Pricebook
            /// </summary>
            Pricebook = 10,
            /// <summary>
            /// Qbo
            /// </summary>
            Qbo = 11,
            /// <summary>
            /// LogIn
            /// </summary>
            LogIn = 12

        }


        /// <summary>
        /// AuditRequestType
        /// </summary>
        public enum AuditRequestType
        {
            /// <summary>
            /// AuditRequestType Create
            /// </summary>
            Create,

            /// <summary>
            /// AuditRequestType Update
            /// </summary>
            Update,

            /// <summary>
            /// AuditRequestType Delete
            /// </summary>
            Delete,

            /// <summary>
            /// AuditRequestType GET
            /// </summary>
            GET
        }


        /// <summary>
        /// RequestStatusCode
        /// </summary>
        public enum RequestStatusCode
        {
            /// <summary>
            /// RequestStatusCode Ok
            /// </summary>
            Ok = 200,

            /// <summary>
            /// RequestStatusCode Created
            /// </summary>
            Created = 201,

            /// <summary>
            /// RequestStatusCode BadRequest
            /// </summary>
            BadRequest = 400,

            /// <summary>
            /// RequestStatusCode Unauthorized
            /// </summary>
            Unauthorized = 401,

            /// <summary>
            /// RequestStatusCode Forbiddern
            /// </summary>
            Forbiddern = 403,

            /// <summary>
            /// RequestStatusCode NotFound
            /// </summary>
            NotFound = 404,

            /// <summary>
            /// RequestStatusCode MethodNotFollowed
            /// </summary>
            MethodNotFollowed = 405,

            /// <summary>
            /// RequestStatusCode Conflict
            /// </summary>
            Conflict = 409,

            /// <summary>
            /// RequestStatusCode InternalServerError
            /// </summary>
            InternalServerError = 500,

            /// <summary>
            /// RequestStatusCode ServiceUnavailable
            /// </summary>
            ServiceUnavailable = 503
        }

        /// <summary>
        /// TaxType
        /// </summary>
        public enum TaxType
        {
            /// <summary>
            /// TaxType Percent
            /// </summary>
            Percent = 1,
            /// <summary>
            /// TaxType Amount
            /// </summary>
            Amount = 2
        }
        /// <summary>
        /// RoundingCode
        /// </summary>
        public enum RoundingCode
        {
            /// <summary>
            /// RoundUp
            /// </summary>
            RoundUp = 1,

            /// <summary>
            /// RoundDown
            /// </summary>
            RoundDown = 2
        }

        /// <summary>
        /// CustomerType
        /// </summary>
        public enum CustomerType
        {
            /// <summary>
            /// Commercial
            /// </summary>
            Commercial = 1,
            /// <summary>
            /// Residential
            /// </summary>
            Residential = 2
        }

        /// <summary>
        /// AddressType
        /// </summary>
        public enum AddressType
        {
            /// <summary>
            /// Billing
            /// </summary>
            Billing = 1,
            /// <summary>
            /// Service
            /// </summary>
            Service = 2
        }

        /// <summary>
        /// ContactType
        /// </summary>
        public enum ContactType
        {
            /// <summary>
            /// Email
            /// </summary>
            Email = 1,
            /// <summary>
            /// Text
            /// </summary>
            Text = 2,
            /// <summary>
            /// Phone
            /// </summary>
            Phone = 3
        }

        /// <summary>
        /// NotificationPreferences
        /// </summary>
        public enum NotificationPreferences
        {
            /// <summary>
            /// Email
            /// </summary>
            Email = 1,
            /// <summary>
            /// Text
            /// </summary>
            Text = 2,
            /// <summary>
            /// Phone
            /// </summary>
            Phone = 3
        }

        /// <summary>
        /// CustomerStatus
        /// </summary>
        public enum CustomerStatus
        {
            /// <summary>
            /// Active
            /// </summary>
            Active = 1,
            /// <summary>
            /// inActive
            /// </summary>
            inActive = 2
        }

        /// <summary>
        /// Days
        /// </summary>
        public enum Days
        {
            /// <summary>
            /// Monday
            /// </summary>
            Monday = 1,
            /// <summary>
            /// Tuesday
            /// </summary>
            Tuesday = 2,
            /// <summary>
            /// Wednesday
            /// </summary>
            Wednesday = 3,
            /// <summary>
            /// Thrusday
            /// </summary>
            Thursday = 4,
            /// <summary>
            /// Friday
            /// </summary>
            Friday = 5,
            /// <summary>
            /// Saturday
            /// </summary>
            Saturday = 6,
            /// <summary>
            /// Sunday
            /// </summary>
            Sunday = 7,
        }

        /// <summary>
        /// ConfigTypes
        /// </summary>
        public enum ConfigTypes
        {
            /// <summary>
            /// FASettings
            /// </summary>
            FASettings = 1,

            /// <summary>
            /// BOSettings
            /// </summary>
            BOSettings = 2,

            /// <summary>
            /// BUSettings
            /// </summary>
            BUSettings = 3,

            /// <summary>
            /// CheckList
            /// </summary>
            CheckList = 4,

            /// <summary>
            /// CancelReason
            /// </summary>
            CancelReason = 5,

            /// <summary>
            /// WorkOrderCancelReason
            /// </summary>
            WorkOrderCancelReason = 6,

            /// <summary>
            /// AppointmentType
            /// </summary>
            AppointmentType = 7,

            /// <summary>
            /// ReferralSources
            /// </summary>
            ReferralSources = 8,

            /// <summary>
            /// GeneralSettings
            /// </summary>
            GeneralSettings = 9,

            /// <summary>
            /// InvoiceSettings
            /// </summary>
            InvoiceSettings = 10,

            /// <summary>
            /// AccountingPackageSettings
            /// </summary>
            AccountingPackageSettings = 11,

            /// <summary>
            /// TaxSettings
            /// </summary>
            TaxSettings = 12,

            /// <summary>
            /// BusinessHoursSettings
            /// </summary>
            BusinessHoursSettings = 13,

            /// <summary>
            /// AppointmentSlotsSettings
            /// </summary>
            AppointmentSlotsSettings = 14,

            /// <summary>
            /// CompanyClosuresSettings
            /// </summary>
            CompanyClosuresSettings = 15
        }

        /// <summary>
        /// ConfigEntityTypes
        /// </summary>
        public enum ConfigEntityTypes
        {
            /// <summary>
            /// 
            /// </summary>
            Enterprise = 1,

            /// <summary>
            /// Company
            /// </summary>
            Company = 2,

            /// <summary>
            /// BusinessGroup
            /// </summary>
            BusinessGroup = 3,

            /// <summary>
            /// BusinessUnit
            /// </summary>
            BusinessUnit = 4,

            /// <summary>
            /// Franchise
            /// </summary>
            Franchise = 5,

            /// <summary>
            /// LineOfBusiness
            /// </summary>
            LineOfBusiness = 6,

            /// <summary>
            /// Concept
            /// </summary>
            Concept = 7,

            /// <summary>
            /// System
            /// </summary>
            System = 8
        }
    }

}