﻿

using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service
{

    /// <summary>
    /// AuditConfig
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class AuditConfig
    {
        /// <summary>
        /// IsAuditEnabled
        /// </summary>
        public bool IsAuditEnabled { get; set; }
    }
}
