﻿using Neighborly.Chassis.Mediator;
using Serilog;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Neighborly.Service.BaseCommand
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Represents a command handler
    /// </summary>
    /// <typeparam name="TCommand">The command type</typeparam>
    public abstract class UpdateCommandHandler<TCommand> : ICommandHandler<TCommand> where TCommand : class, ICommand
    {
        /// <summary>
        /// Handles the given command
        /// </summary>
        /// <param name="cmd">The command to handle</param>
        /// <param name="ct">The cancellation token</param>
        /// <returns>A task to be awaited</returns>
        public abstract Task HandleAsync(TCommand cmd, CancellationToken ct);
        /// <summary>
        /// The mediator
        /// </summary>
        protected readonly IMediator mediator;
        /// <summary>
        /// The logger
        /// </summary>
        protected readonly ILogger logger;
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateCommandHandler{TCommand}"/> class.
        /// </summary>
        /// <param name="mediator">The mediator.</param>
        /// <param name="logger">The logger.</param>
        protected UpdateCommandHandler(IMediator mediator, ILogger logger)
        {
            this.mediator = mediator;
            this.logger = logger;
        }
    }

    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Represents a command handler
    /// </summary>
    /// <typeparam name="TCommand">The command type</typeparam>
    /// <typeparam name="TResult">The result type</typeparam>
    public abstract class UpdateCommandHandler<TCommand, TResult> : ICommandHandler<TCommand, TResult> where TCommand : class, ICommand<TResult>
    {
        /// <summary>
        /// Handles the given command
        /// </summary>
        /// <param name="cmd">The command to handle</param>
        /// <param name="ct">The cancellation token</param>
        /// <returns>A task to be awaited for the result</returns>
        public abstract Task<TResult> HandleAsync(TCommand cmd, CancellationToken ct);
        /// <summary>
        /// The mediator
        /// </summary>
        protected readonly IMediator mediator;
        /// <summary>
        /// The logger
        /// </summary>
        protected readonly ILogger logger;
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateCommandHandler{TCommand, TResult}"/> class.
        /// </summary>
        /// <param name="mediator">The mediator.</param>
        /// <param name="logger">The logger.</param>
        protected UpdateCommandHandler(IMediator mediator, ILogger logger)
        {
            this.mediator = mediator;
            this.logger = logger;
        }
    }
}