﻿using Neighborly.Chassis.Mediator;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service.BaseCommand
{
    /// <summary>
    /// 
    /// </summary>
    /// <typeparam name="TResult"></typeparam>
    [ExcludeFromCodeCoverage]    
    public abstract class DeleteCommand<TResult> : Command<TResult>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeleteCommand{TResult}"/> class.
        /// </summary>
        /// <param name="identity">The identity.</param>
        protected DeleteCommand(string identity) => CreatedBy = identity;
    }

    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class DeleteCommand.
    /// Implements the <see cref="Command{TResult}" />
    /// </summary>
    /// <seealso cref="Command{TResult}" />
    public abstract class DeleteCommand : Command
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="DeleteCommand"/> class.
        /// </summary>
        /// <param name="identity">The identity.</param>
        protected DeleteCommand(string identity) => CreatedBy = identity;
    }
}
