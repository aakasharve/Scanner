﻿using Neighborly.Chassis.Mediator;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service.BaseCommand
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class UpdateCommand.
    /// Implements the <see cref="Command{TResult}" />
    /// </summary>
    /// <typeparam name="TResult">The type of the t result.</typeparam>
    /// <seealso cref="Command{TResult}" />
    public abstract class UpdateCommand<TResult> : Command<TResult>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateCommand{TResult}"/> class.
        /// </summary>
        /// <param name="identity">The identity.</param>
        protected UpdateCommand(string identity) => CreatedBy = identity;
    }

    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class UpdateCommand.
    /// Implements the <see cref="Command{TResult}" />
    /// </summary>
    /// <seealso cref="Command{TResult}" />
    public abstract class UpdateCommand : Command
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="UpdateCommand"/> class.
        /// </summary>
        /// <param name="identity">The identity.</param>
        protected UpdateCommand(string identity) => CreatedBy = identity;
    }
}
