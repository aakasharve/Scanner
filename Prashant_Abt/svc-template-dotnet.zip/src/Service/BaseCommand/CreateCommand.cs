﻿using Neighborly.Chassis.Mediator;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service.BaseCommand
{

    /// <summary>
    /// Class CreateCommand.
    /// Implements the <see cref="Command{TResult}" />
    /// </summary>
    /// <typeparam name="TResult">The type of the t result.</typeparam>
    /// <seealso cref="Command{TResult}" />
    [ExcludeFromCodeCoverage]
    public abstract class CreateCommand<TResult> : Command<TResult>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateCommand{TResult}"/> class.
        /// </summary>
        /// <param name="identity">The identity.</param>
        protected CreateCommand(string identity) => CreatedBy = identity;
    }

    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class CreateCommand.
    /// Implements the <see cref="Command{TResult}" />
    /// </summary>
    /// <seealso cref="Command{TResult}" />
    public abstract class CreateCommand : Command
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateCommand"/> class.
        /// </summary>
        /// <param name="identity">The identity.</param>
        protected CreateCommand(string identity) => CreatedBy = identity;
    }
}
