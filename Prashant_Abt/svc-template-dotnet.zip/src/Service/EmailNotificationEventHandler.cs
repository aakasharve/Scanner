﻿using Neighborly.Chassis.Mediator;
using Serilog;

namespace Neighborly.Service
{
    /// <summary>
    /// Class EmailNotificationEventHandler.
    /// Implements the <see cref="Neighborly.Service.IntegrationEventHandler{TEvent}" />
    /// </summary>
    /// <typeparam name="TEvent">The type of the t event.</typeparam>
    /// <seealso cref="Neighborly.Service.IntegrationEventHandler{TEvent}" />
    public abstract class EmailNotificationEventHandler<TEvent> : IntegrationEventHandler<TEvent> where TEvent : class, IEvent
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="EmailNotificationEventHandler{TEvent}"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        protected EmailNotificationEventHandler(ILogger logger) : base(logger)
        {

        }

    }

}
