﻿using Microsoft.AspNetCore.Mvc;
using Neighborly.Chassis.Mediator;
using Serilog;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class NeighborlyServiceController.
    /// Implements the <see cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    /// </summary>
    /// <seealso cref="Microsoft.AspNetCore.Mvc.ControllerBase" />
    public abstract class NeighborlyServiceController : ControllerBase
    {
        /// <summary>
        /// The logger
        /// </summary>
        protected readonly ILogger logger;
        /// <summary>
        /// The mediator
        /// </summary>
        protected readonly IMediator mediator;

        /// <summary>
        /// Initializes a new instance of the <see cref="NeighborlyServiceController"/> class.
        /// </summary>
        /// <param name="mediator">The mediator.</param>
        /// <param name="logger">The logger.</param>
        protected NeighborlyServiceController(IMediator mediator, ILogger logger)
        {
            this.mediator = mediator;
            this.logger = logger;
        }
    }
}
