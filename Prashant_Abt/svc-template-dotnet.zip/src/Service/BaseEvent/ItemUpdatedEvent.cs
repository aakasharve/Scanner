﻿using Neighborly.Chassis.Mediator;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service.BaseEvent
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class ItemUpdatedEvent.
    /// Implements the <see cref="Event" />
    /// </summary>
    /// <seealso cref="Event" />
    public abstract class ItemUpdatedEvent : Event
    {
        /// <inheritdoc />

    }
}