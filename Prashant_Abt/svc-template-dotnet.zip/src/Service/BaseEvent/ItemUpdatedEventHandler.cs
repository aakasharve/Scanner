﻿using Neighborly.Chassis.Mediator;
using Serilog;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Neighborly.Service.BaseEvent
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class ItemUpdatedEventHandler.
    /// Implements the <see cref="IEventHandler{TEvent}" />
    /// </summary>
    /// <typeparam name="TEvent">The type of the t event.</typeparam>
    /// <seealso cref="IEventHandler{TEvent}" />
    public abstract class ItemUpdatedEventHandler<TEvent> : IEventHandler<TEvent> where TEvent : class, IEvent
    {
        /// <summary>
        /// The logger
        /// </summary>
        protected readonly ILogger logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="ItemUpdatedEventHandler{TEvent}"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        protected ItemUpdatedEventHandler(ILogger logger)
        {
            this.logger = logger;
        }
        /// <summary>
        /// Handles the asynchronous.
        /// </summary>
        /// <param name="evt">The evt.</param>
        /// <param name="ct">The ct.</param>
        /// <returns>Task.</returns>
        public abstract Task HandleAsync(TEvent evt, CancellationToken ct);

    }
}