﻿using Neighborly.Chassis.Mediator;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service.BaseEvent
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class ItemCreatedEvent.
    /// Implements the <see cref="Event" />
    /// </summary>
    /// <seealso cref="Event" />
    public abstract class ItemCreatedEvent : Event
    {
        /// <inheritdoc />

    }
}