﻿using AutoMapper;
using Neighborly.Chassis.Auth;
using Neighborly.Chassis.Mediator;
using Neighborly.Chassis.Repository.PostgreSQL;
using Neighborly.Context;
using System.Diagnostics.CodeAnalysis;
using WorkOrderDomain = Neighborly.Service.WorkOrder.Domain;

namespace Neighborly.Service.WorkOrder.Repository.PostgreSQL
{
	/// <summary>
	/// 
	/// </summary>
	[ExcludeFromCodeCoverage]
	public class WorkOrderRepository : PostgreSqlRepository<WorkOrderDomain.WorkOrder>, IWorkOrderRepository
	{
		private readonly DataContext _dataContext;
		private readonly IUserClaimsProvider userClaimsProvider;
		private readonly IMapper _mapper;
		/// <summary>
		/// mediator
		/// </summary>
		private readonly IMediator _mediator;	

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="dataContext"></param>
		public WorkOrderRepository(DataContext dataContext, IUserClaimsProvider userClaimsProvider, IMapper mapper, IMediator mediator) : base(dataContext)
		{
			this._dataContext = dataContext;
			this.userClaimsProvider = userClaimsProvider;
			this._mapper = mapper;
			this._mediator = mediator;
		}
    }
}