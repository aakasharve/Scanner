﻿using Neighborly.Chassis.Repository.PostgreSQL;
using System.Diagnostics.CodeAnalysis;
using WorkOrderDomain = Neighborly.Service.WorkOrder.Domain;


namespace Neighborly.Service.WorkOrder.Repository.PostgreSQL
{
    /// <summary>
    /// Work Order Reposiotry Interface
    /// </summary>
    public interface IWorkOrderRepository : IPostgreSqlRepository<WorkOrderDomain.WorkOrder>
	{	
		
    }
}