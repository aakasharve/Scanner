﻿using Neighborly.Chassis.Repository;

namespace Neighborly.Service.WorkOrder.Domain
{
    /// <summary>
    /// Work Order
    /// </summary>
    public class WorkOrder : ItemBase
    {
        /// <summary>
        /// Id of WorkOrder.
        /// </summary>
        /// <value>The title.</value>
        public string WorkOrderNumber { get; set; } = null!;
        /// <summary>
        /// Customer Name
        /// </summary>
        public string? CustomerName { get; set; }
        /// <summary>
        /// Customer Id
        /// </summary>
        public string? CustomerId { get; set; }
        /// <summary>
        /// Email
        /// </summary>
        public string Email { get; set; } = null!;
        /// <summary>
        /// Phone
        /// </summary>
        public string Phone { get; set; } = null!;
    }
}
