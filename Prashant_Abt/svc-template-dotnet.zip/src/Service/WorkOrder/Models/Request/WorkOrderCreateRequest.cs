﻿using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Model.WorkOrder.Models.Request
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class Work Order Create Request.
    /// </summary>
    public class WorkOrderCreateRequest
    {
        /// <summary>
        /// Customer Name
        /// </summary>
        public string CustomerName { get; set; } = null!;
        /// <summary>
        /// CustomerId
        /// </summary>
        public string CustomerId { get; set; } = null!;
        /// <summary>
        /// Customer Is Taxable
        /// </summary>
        public bool? CustomerIsTaxable { get; set; }
        /// <summary>
        /// Email
        /// </summary>
        public string? Email { get; set; }
        /// <summary>
        /// Phone
        /// </summary>
        public string? Phone { get; set; }

        /// <summary>
        /// Work Order Number
        /// </summary>
        public string WorkOrderNumber { get; set; } = null!;
    }
}
