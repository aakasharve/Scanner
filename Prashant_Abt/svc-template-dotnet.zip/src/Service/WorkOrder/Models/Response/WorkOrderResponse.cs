﻿using System;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service.WorkOrder.Models.Response
{
    /// <summary>
    /// WorkOrderResponse
    /// </summary>
    [ExcludeFromCodeCoverage]   
    public class WorkOrderResponse
    {
        /// <summary>
        /// Id - Work Order Id
        /// </summary>
        public Guid Id { get; set; }
        /// <summary>
        /// Work Order Number
        /// </summary>
        public string WorkOrderNumber { get; set; } = null!;
        /// <summary>
        /// Customer Name
        /// </summary>
        public string CustomerName { get; set; } = null!;
        /// <summary>
        /// CustomerId
        /// </summary>
        public string CustomerId { get; set; } = null!;
        /// <summary>
        /// Customer Is Taxable
        /// </summary>
        public bool? CustomerIsTaxable { get; set; }
        /// <summary>
        /// Email
        /// </summary>
        public string? Email { get; set; }
        /// <summary>
        /// Phone
        /// </summary>
        public string? Phone { get; set; }
    }
}