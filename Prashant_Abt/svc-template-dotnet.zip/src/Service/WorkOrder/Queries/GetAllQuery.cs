﻿using Neighborly.Service.BaseQuery;
using Neighborly.Service.WorkOrder.Models.Response;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service.WorkOrder.Queries
{

    /// <summary>
    /// GetAllQuery
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class GetAllQuery : ListItemQuery<List<WorkOrderResponse>>
    {
        /// <summary>
        /// GetAllQuery Conctructor
        /// </summary>
        /// <param name="identity"></param>
        public GetAllQuery(string identity) : base(identity)
        {

        }
        /// <summary>
        /// Page Size, Page No
        /// </summary>
        public int pageSize, pageNo;
    }
}