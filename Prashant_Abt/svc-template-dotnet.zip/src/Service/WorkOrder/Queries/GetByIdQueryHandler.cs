﻿using AutoMapper;
using Neighborly.Chassis.Mediator;
using Neighborly.Service.BaseQuery;
using Neighborly.Service.WorkOrder.Models.Response;
using Neighborly.Service.WorkOrder.Repository.PostgreSQL;
using Serilog;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using WorkOrderDomain = Neighborly.Service.WorkOrder.Domain;

namespace Neighborly.Service.WorkOrder.Queries
{
    /// <summary>
    /// Get By Id Query Handler
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class GetByIdQueryHandler : SingleItemQueryHandler<GetByIdQuery, WorkOrderResponse>
    {
        /// <summary>
        /// Work order repository
        /// </summary>
        private readonly IWorkOrderRepository workOrderRepository;
        private readonly IMapper mapper;
        /// <summary>
        /// mediator
        /// </summary>
        protected readonly IMediator mediator;

        /// <summary>
        /// GetAllQueryHandler
        /// </summary>
        /// <param name="workOrderRepository"></param>
        /// <param name="logger"></param>
        /// <param name="mapper"></param>
        /// <param name="mediator"></param>
        public GetByIdQueryHandler(IWorkOrderRepository workOrderRepository, ILogger logger, IMapper mapper, IMediator mediator) : base(logger)
        {
            this.workOrderRepository = workOrderRepository;
            this.mapper = mapper;
            this.mediator = mediator;
        }

        /// <summary>
        /// Handle Async
        /// </summary>
        /// <param name="query"></param>
        /// <param name="ct"></param>
        /// <returns></returns>
        public override async Task<WorkOrderResponse> HandleAsync(GetByIdQuery query, CancellationToken ct)
        {
            WorkOrderResponse workOrder = new WorkOrderResponse();
            logger.Debug($"Executing Query handler:{0}", typeof(GetByIdQueryHandler));
            var result = await workOrderRepository.GetByIdAsync(query.Id) as WorkOrderDomain.WorkOrder;

            if (result != null)
            {
                workOrder = mapper.Map<WorkOrderResponse>(result);
            }
            return workOrder;
        }
    }
}