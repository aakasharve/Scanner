﻿using AutoMapper;
using Neighborly.Chassis.Mediator;
using Neighborly.Service.BaseQuery;
using Neighborly.Service.WorkOrder.Models.Response;
using Neighborly.Service.WorkOrder.Repository.PostgreSQL;
using Serilog;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using WorkOrderDomain = Neighborly.Service.WorkOrder.Domain;

namespace Neighborly.Service.WorkOrder.Queries
{

    /// <summary>
    /// GetAllQueryHandler
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class GetAllQueryHandler : ListItemQueryHandler<GetAllQuery, List<WorkOrderResponse>>
    {
        /// <summary>
        /// Work order repository
        /// </summary>
        private readonly IWorkOrderRepository workOrderRepository;
        private readonly IMapper mapper;
        /// <summary>
        /// mediator
        /// </summary>
        protected readonly IMediator mediator;

        /// <summary>
        /// GetAllQueryHandler
        /// </summary>
        /// <param name="workOrderRepository"></param>
        /// <param name="logger"></param>
        /// <param name="mapper"></param>
        /// <param name="mediator"></param>
        public GetAllQueryHandler(IWorkOrderRepository workOrderRepository, ILogger logger, IMapper mapper, IMediator mediator) : base(logger)
        {
            this.workOrderRepository = workOrderRepository;
            this.mapper = mapper;
            this.mediator = mediator;
        }

        /// <summary>
        /// Handle Async
        /// </summary>
        /// <param name="query"></param>
        /// <param name="ct"></param>
        /// <returns></returns>
        public override async Task<List<WorkOrderResponse>> HandleAsync(GetAllQuery query, CancellationToken ct)
        {
            List<WorkOrderResponse> workOrders = new List<WorkOrderResponse>();
            logger.Debug($"Executing Query handler:{0}", typeof(GetAllQueryHandler));
            var result = await workOrderRepository.GetAllAsync(query.pageSize, query.pageNo, null, null, null) as List<WorkOrderDomain.WorkOrder>;

            if (result != null && result.Any())
            {
                workOrders = mapper.Map<List<WorkOrderResponse>>(result);
            }
            return workOrders;
        }
    }
}