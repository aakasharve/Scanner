﻿using Neighborly.Service.BaseQuery;
using Neighborly.Service.WorkOrder.Models.Response;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service.WorkOrder.Queries
{
    /// <summary>
    /// Get By Id Query
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class GetByIdQuery : SingleItemQuery<WorkOrderResponse>
    {
        /// <summary>
        /// GetAllQuery Conctructor
        /// </summary>
        /// <param name="identity"></param>
        public GetByIdQuery(string identity) : base(identity)
        {

        }

        /// <summary>
        /// Gets or sets the identifier.
        /// </summary>
        /// <value>The identifier.</value>
        public new Guid Id { get; set; }
    }
}
