﻿using AutoMapper;
using Neighborly.Chassis.Auth;
using Neighborly.Chassis.Mediator;
using Neighborly.Service.BaseCommand;
using Neighborly.Service.WorkOrder.Repository.PostgreSQL;
using Serilog;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;
using WorkOrderDomain = Neighborly.Service.WorkOrder.Domain;


namespace Neighborly.Service.WorkOrder.Commands
{
    /// <summary>
    /// 
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class CreateWorkOrderCommandHandler : CreateCommandHandler<CreateWorkOrderCommand, WorkOrderDomain.WorkOrder>
    {
        /// <summary>
        /// To do item repository
        /// </summary>
        private readonly IWorkOrderRepository workOrderRepository;

        /// <summary>
        /// mapper
        /// </summary>
        private readonly IMapper mapper;

        /// <summary>
        /// UserClaimsProvider Interface
        /// </summary>
        private readonly IUserClaimsProvider userClaimsProvider;

        /// <summary>
        /// 
        /// </summary>
        /// <param name="workOrderRepository"></param>
        /// <param name="mediator"></param>
        /// <param name="logger"></param>
        /// <param name="mapper"></param>
        /// <param name="userClaimsProvider"></param>
        public CreateWorkOrderCommandHandler( IWorkOrderRepository workOrderRepository, IMediator mediator, ILogger logger
            , IMapper mapper,IUserClaimsProvider userClaimsProvider) : base(mediator, logger)
        {
            this.workOrderRepository = workOrderRepository;   
            this.mapper = mapper;
            this.userClaimsProvider = userClaimsProvider;
        }

        /// <summary>
        /// handle as an asynchronous operation.
        /// </summary>
        /// <param name="cmd">The command.</param>
        /// <param name="ct">The ct.</param>
        /// <returns>WorkOrderEntity.</returns>
        public override async Task<WorkOrderDomain.WorkOrder> HandleAsync(CreateWorkOrderCommand cmd, CancellationToken ct)
        {
            
            var newWorkOrder = new WorkOrderDomain.WorkOrder
            {
                Id = Guid.NewGuid(),
                CustomerId = cmd.CustomerId,
                CustomerName = cmd.CustomerName,
                Email = cmd.Email ?? string.Empty,
                Phone = cmd.Phone ?? string.Empty ,
                WorkOrderNumber = cmd.WorkOrderNumber ?? String.Empty
            };

            var result = await workOrderRepository.AddAsync(newWorkOrder);
            logger.Debug("CreateWorkOrderCommandHandler.cs:workOrderRepository.SaveWorkOrderAsync");
           
            return result;
        }
    }
}
