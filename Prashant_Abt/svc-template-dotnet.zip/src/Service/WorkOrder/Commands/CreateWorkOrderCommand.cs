﻿using Neighborly.Service.BaseCommand;
using System;
using System.Diagnostics.CodeAnalysis;
using WorkOrderDomain = Neighborly.Service.WorkOrder.Domain;

namespace Neighborly.Service.WorkOrder.Commands
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// 
    /// </summary>
    public class CreateWorkOrderCommand : CreateCommand<WorkOrderDomain.WorkOrder>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateWorkOrderCommand"/> class.
        /// </summary>
        /// <param name="identity">The identity.</param>
        public CreateWorkOrderCommand(string identity) : base(identity)
        {
            this.CreatedBy = identity;
            this.CreatedOn = DateTime.UtcNow;
        }
        /// <summary>
        /// CustomerName
        /// </summary>
        public string? CustomerName { get; set; }
        /// <summary>
        ///CustomerId
        /// </summary>
        public string? CustomerId { get; set; }
        /// <summary>
        ///CustomerIsTaxable
        /// </summary>
        public bool? CustomerIsTaxable { get; set; }
        /// <summary>
        /// Email
        /// </summary>
        public string? Email { get; set; }
        /// <summary>
        /// Phone
        /// </summary>
        public string? Phone { get; set; }
        /// <summary>
        /// BusinessUnit
        /// </summary>
        /// <value>The Business Unit.</value>
        public Guid? BusinessUnit { get; set; }

        /// <summary>
        /// Work Order Number
        /// </summary>
        public string WorkOrderNumber { get; set; } = null!;

    }
}
