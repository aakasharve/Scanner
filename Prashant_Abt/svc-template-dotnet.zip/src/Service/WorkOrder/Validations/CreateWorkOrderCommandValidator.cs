﻿using FluentValidation;

using Neighborly.Service.WorkOrder.Commands;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service.WorkOrder.Validations

{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// 
    /// </summary>
    public class CreateWorkOrderCommandValidator : AbstractValidator<CreateWorkOrderCommand>
    {
       
        /// <summary>
        /// Initializes a new instance of the <see cref="CreateWorkOrderCommandValidator"/> class.
        /// </summary>
        public CreateWorkOrderCommandValidator()
        {
            RuleFor(e => e.Id)
                .NotEmpty();
        }       
    }    
}