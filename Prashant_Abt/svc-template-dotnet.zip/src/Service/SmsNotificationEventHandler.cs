﻿using Neighborly.Chassis.Mediator;
using Serilog;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class SmsNotificationEventHandler.
    /// Implements the <see cref="Neighborly.Service.IntegrationEventHandler{TEvent}" />
    /// </summary>
    /// <typeparam name="TEvent">The type of the t event.</typeparam>
    /// <seealso cref="Neighborly.Service.IntegrationEventHandler{TEvent}" />
    public abstract class SmsNotificationEventHandler<TEvent> : IntegrationEventHandler<TEvent> where TEvent : class, IEvent
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SmsNotificationEventHandler{TEvent}"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        protected SmsNotificationEventHandler(ILogger logger) : base(logger)
        {

        }
    }
}
