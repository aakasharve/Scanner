﻿using System;

namespace Neighborly.Service.BaseEntity
{
    /// <summary>
    /// CompanySpecificBase
    /// </summary>
    public class CompanySpecificBase : ItemBaseTracking
    {
        /// <summary>
        /// Company Id
        /// </summary>
        public Guid? CmId { get; set; } = default!;
        /// <summary>
        /// Business Unit Id
        /// </summary>
        public Guid? BuId { get; set; } = default!;
        /// <summary>
        /// Business Group Id
        /// </summary>
        public Guid? BgId { get; set; } = default!;
        /// <summary>
        /// Line of Business Id
        /// </summary>
        public Guid? LoBId { get; set; } = default!;
        /// <summary>
        /// Concept Id
        /// </summary>
        public int? CoId { get; set; }

    }
}
