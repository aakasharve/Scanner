﻿using Neighborly.Chassis.Repository;

namespace Neighborly.Service.BaseEntity
{
    public class ItemBaseTracking : ItemBase, ITrackingEntityBase
    {
        public string CreatedBy { get; set; } = null!;
        public long CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public long? UpdatedOn { get; set; }
    }
}
