﻿namespace Neighborly.Service.BaseEntity
{
    public interface ITrackingEntityBase
    {

        public string CreatedBy { get; set; }
        public long CreatedOn { get; set; }
        public string? UpdatedBy { get; set; }
        public long? UpdatedOn { get; set; }
    }
}
