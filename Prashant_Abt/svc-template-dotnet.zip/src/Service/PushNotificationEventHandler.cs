﻿using Neighborly.Chassis.Mediator;
using Serilog;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class PushNotificationEventHandler.
    /// Implements the <see cref="Neighborly.Service.IntegrationEventHandler{TEvent}" />
    /// </summary>
    /// <typeparam name="TEvent">The type of the t event.</typeparam>
    /// <seealso cref="Neighborly.Service.IntegrationEventHandler{TEvent}" />
    public abstract class PushNotificationEventHandler<TEvent> : IntegrationEventHandler<TEvent> where TEvent : class, IEvent
    {

        /// <summary>
        /// Initializes a new instance of the <see cref="PushNotificationEventHandler{TEvent}"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        protected PushNotificationEventHandler(ILogger logger) : base(logger)
        {

        }
    }
}
