﻿using Neighborly.Chassis.Mediator;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service.BaseQuery
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class SingleItemQuery.
    /// Implements the <see cref="Query{TResult}" />
    /// </summary>
    /// <typeparam name="TResult">The type of the t result.</typeparam>
    /// <seealso cref="Query{TResult}" />
    public abstract class SingleItemQuery<TResult> : Query<TResult>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="SingleItemQuery{TResult}"/> class.
        /// </summary>
        /// <param name="identity">The identity.</param>
        protected SingleItemQuery(string identity) => CreatedBy = identity;
    }
}
