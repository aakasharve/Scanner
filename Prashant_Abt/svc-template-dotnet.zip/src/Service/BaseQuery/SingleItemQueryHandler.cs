﻿using Neighborly.Chassis.Mediator;
using Serilog;
using System.Diagnostics.CodeAnalysis;
using System.Threading;
using System.Threading.Tasks;

namespace Neighborly.Service.BaseQuery
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Represents a query handler
    /// </summary>
    /// <typeparam name="TQuery">The query type</typeparam>
    /// <typeparam name="TResult">The result type</typeparam>
    public abstract class SingleItemQueryHandler<TQuery, TResult> : IQueryHandler<TQuery, TResult> where TQuery : class, IQuery<TResult>
    {
        /// <summary>
        /// The logger
        /// </summary>
        protected readonly ILogger logger;

        /// <summary>
        /// Initializes a new instance of the <see cref="SingleItemQueryHandler{TQuery, TResult}"/> class.
        /// </summary>
        /// <param name="logger">The logger.</param>
        protected SingleItemQueryHandler(ILogger logger)
        {
            this.logger = logger;
        }
        /// <summary>
        /// Handles the given <see cref="IQuery{TResult}" /> and returns the
        /// corresponding result.
        /// </summary>
        /// <param name="query">The query to handle</param>
        /// <param name="ct">The cancellation token</param>
        /// <returns>A task to be awaited for the result</returns>


        public abstract Task<TResult> HandleAsync(TQuery query, CancellationToken ct);
    }

}