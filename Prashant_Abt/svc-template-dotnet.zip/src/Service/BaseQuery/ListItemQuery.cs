﻿using Neighborly.Chassis.Mediator;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly.Service.BaseQuery
{
    [ExcludeFromCodeCoverage]
    /// <summary>
    /// Class ListItemQuery.
    /// Implements the <see cref="Query{TResult}" />
    /// </summary>
    /// <typeparam name="TResult">The type of the t result.</typeparam>
    /// <seealso cref="Query{TResult}" />
    public abstract class ListItemQuery<TResult> : Query<TResult>
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ListItemQuery{TResult}"/> class.
        /// </summary>
        /// <param name="identity">The identity.</param>
        protected ListItemQuery(string identity) => CreatedBy = identity;
    }
}
