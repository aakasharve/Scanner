﻿namespace Neighborly.Service
{
    /// <summary>
    /// Constants
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// Offset
        /// </summary>
        public const string OFFSET = "en-US";
        /// <summary>
        ///USERCULTURECODE
        /// </summary>
        public const string USERCULTURECODE = "-5.5";
        /// <summary>
        /// USERTIMEZONE
        /// </summary>
        public const string USERTIMEZONE = "India Standard Time";
        /// <summary>
        /// DEFAULT_CURRENCY
        /// </summary>
        public const string DEFAULT_CURRENCY = "USD";
        /// <summary>
        /// DEFAULT_TIMEZONE
        /// </summary>
        public const string DEFAULT_TIMEZONE = "Central Standard Time";
        /// <summary>
        /// DEFAULT_FRANCHISE
        /// </summary>
        public const string DEFAULT_FRANCHISE = "2FE4DB9C-F5A7-451F-A935-D2A51179E995";
        /// <summary>
        /// DEFAULT_CONCEPT
        /// </summary>
        public const int DEFAULT_CONCEPT = 26;
        /// <summary>
        /// DEFAULT_BUSINESSUNIT
        /// </summary>
        public const string DEFAULT_BUSINESSUNIT = "60aa93d1-8e0e-4131-8e6b-7ea7c11c2319";
        /// <summary>
        /// DEFAULT_FRANCHISE_NUMBER
        /// </summary>
        public const int DEFAULT_FRANCHISE_NUMBER = 47256;
        /// <summary>
        /// API_KEY
        /// </summary>
        public const string API_KEY = "api-key fbd81ae5-57f6-4796-bc9f-e9a64257dcad";

        /// <summary>
        /// EventBridgeConstant
        /// </summary>
        public static class EventBridgeConstant
        {
            /// <summary>
            /// Template
            /// </summary>
            public const string Template = "Service Template";

            /// <summary>
            /// Detailtype
            /// </summary>
            public const string DispatchAuditLog = "AuditLogEntry";

        }
        /// <summary>
        /// AuditLog
        /// </summary>
        public static class AuditLog
        {
            /// <summary>
            /// ID
            /// </summary>
            public const string ID = "WorkOrderId";
            /// <summary>
            /// SERVICEAPPOINTEMENTCREATED
            /// </summary>
            public const string SERVICEAPPOINTEMENTCREATED = "created service appointment for work order {0}";
            /// <summary>
            /// SERVICE_APPOINTEMENTSTATUS_UPDATED
            /// </summary>
            public const string SERVICE_APPOINTEMENTSTATUS_UPDATED = "service appointment status updated";
            /// <summary>
            /// SERVICE_APPOINTEMENT_UPDATED
            /// </summary>
            public const string SERVICE_APPOINTEMENT_UPDATED = "service appointment updated";
            /// <summary>
            /// SERVICE_APPOINTEMENT_CANCELLED
            /// </summary>
            public const string SERVICE_APPOINTEMENT_CANCELLED = "service appointment cancelled";
            /// <summary>
            /// SERVICE_CONFLICTIGNORE_UPDATED
            /// </summary>
            public const string SERVICE_CONFLICTIGNORE_UPDATED = "service conflict ignore updated";
        }
    }
}
