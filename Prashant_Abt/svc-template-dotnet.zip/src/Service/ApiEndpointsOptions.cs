﻿namespace Neighborly.Service
{
    /// <summary>
    /// ApiEndpointsOptions
    /// </summary>
    public class ApiEndpointsOptions
    {
        /// <summary>
        /// WorkOrderApi
        /// </summary>
        public string? WorkOrderApi { get; set; }        
    }
}
