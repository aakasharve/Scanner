﻿using Amazon.Runtime;
using Npgsql.EntityFrameworkCore.PostgreSQL.Infrastructure;
using System.Diagnostics.CodeAnalysis;

namespace Neighborly
{
    /// <summary>
    /// NpgsqlAwsRdsDbContextOptionsBuilderExtensions
    /// </summary>
    [ExcludeFromCodeCoverage]
    public static class NpgsqlAwsRdsDbContextOptionsBuilderExtensions
    {
        /// <summary>
        /// UseAwsIamAuthentication
        /// </summary>
        /// <param name="optionsBuilder"></param>
        /// <returns></returns>
        public static NpgsqlDbContextOptionsBuilder UseAwsIamAuthentication(this NpgsqlDbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.ProvidePasswordCallback(GenerateAwsIamAuthToken);
            return optionsBuilder;
        }

        static string GenerateAwsIamAuthToken(string host, int port, string database, string username)
        {
            return Amazon.RDS.Util.RDSAuthTokenGenerator.GenerateAuthToken(AssumeRoleWithWebIdentityCredentials.FromEnvironmentVariables(), host, port, username);
        }
    }
}
