﻿CREATE TABLE IF NOT EXISTS "__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL,
    CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId")
);

START TRANSACTION;


DO $EF$
BEGIN
    IF NOT EXISTS(SELECT 1 FROM "__EFMigrationsHistory" WHERE "MigrationId" = '20230223054821_InitialCreate') THEN
    CREATE TABLE ts_workorder (
        "WorkOrderId" uuid NOT NULL,
        "WorkOrderNumber" text NOT NULL,
        "CustomerName" text NULL,
        "CustomerId" text NULL,
        "Email" text NOT NULL,
        "Phone" text NOT NULL,
        CONSTRAINT "PK_ts_workorder" PRIMARY KEY ("WorkOrderId")
    );
    END IF;
END $EF$;

DO $EF$
BEGIN
    IF NOT EXISTS(SELECT 1 FROM "__EFMigrationsHistory" WHERE "MigrationId" = '20230223054821_InitialCreate') THEN
    CREATE INDEX "IX_ts_workorder_CustomerId" ON ts_workorder ("CustomerId");
    END IF;
END $EF$;

DO $EF$
BEGIN
    IF NOT EXISTS(SELECT 1 FROM "__EFMigrationsHistory" WHERE "MigrationId" = '20230223054821_InitialCreate') THEN
    INSERT INTO "__EFMigrationsHistory" ("MigrationId", "ProductVersion")
    VALUES ('20230223054821_InitialCreate', '6.0.10');
    END IF;
END $EF$;
COMMIT;

