using Amazon;
using Amazon.EventBridge;
using Amazon.Extensions.NETCore.Setup;
using Amazon.Runtime;
using Amazon.S3;
using Dwyer.Utilities.Fsm.Abac;
using FluentValidation.AspNetCore;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Versioning;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Caching.StackExchangeRedis;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Hosting;
using Neighborly.Chassis;
using Neighborly.Chassis.Auth;
using Neighborly.Chassis.AWSHelper;
using Neighborly.Chassis.Formatter;
using Neighborly.Chassis.Logging;
using Neighborly.Chassis.Mediator;
using Neighborly.Chassis.Mediator.Behaviour;
using Neighborly.Chassis.Mediator.Behaviour.Logging;
using Neighborly.Chassis.Mediator.Behaviour.Validation;
using Neighborly.Chassis.Swagger;
using Neighborly.Context;
using Neighborly.Service;
using Neighborly.Settings;
using Polly;
using Serilog.Events;
using System;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;


namespace Neighborly
{
    /// <summary>
    /// Class Startup.
    /// </summary>
    [ExcludeFromCodeCoverage]
    public class Startup
    {
        private readonly IWebHostEnvironment _currentEnvironment;
        /// <summary>
        /// Initializes a new instance of the <see cref="Startup" /> class.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        /// /// <param name="currentEnvironment">The configuration.</param>
        public Startup(IConfiguration configuration, IWebHostEnvironment currentEnvironment)
        {
            Configuration = configuration;
            _currentEnvironment = currentEnvironment;
        }

        /// <summary>
        /// Gets the configuration.
        /// </summary>
        /// <value>The configuration.</value>
        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        /// <summary>
        /// Configures the services.
        /// </summary>
        /// <param name="services">The services.</param>
        public void ConfigureServices(IServiceCollection services)
        {
            ThreadPool.SetMinThreads(100, 100);

            services.AddApiVersioning(config =>
            {
                config.DefaultApiVersion = new ApiVersion(1, 0);
                config.ReportApiVersions = true;
                config.AssumeDefaultVersionWhenUnspecified = true;
                config.ApiVersionReader = new HeaderApiVersionReader("x-api-version");
            });

            // Default Policy
            services.AddCors(options =>
            {
                options.AddDefaultPolicy(
                    builder =>
                    {
                        builder.WithOrigins("http://localhost:3000")
                                            .AllowAnyHeader()
                                            .AllowAnyMethod();
                    });
            });

            services.AddMvc(options =>
            {
                options.Filters.Add(typeof(ValidateModelStateAttribute));
                options.CacheProfiles.Add("CacheProfile", new CacheProfile()
                {
                    Duration = 2592000,
                    Location = ResponseCacheLocation.Any
                });
            })
                 .AddFluentValidation(fvc => fvc.RegisterValidatorsFromAssemblyContaining<Startup>())
                 .AddNewtonsoftJson();



            services.Configure<ApiBehaviorOptions>(options =>
            {
                options.SuppressModelStateInvalidFilter = true;
            });
            services.Configure<LoggerOptions>(options => Configuration.GetSection("logger").Bind(options));
            services.AddControllers();
            services.AddMediator(o =>
            {
                // order of pipeline execution is the same as the order of registration
                // in this case
                // logging -> validation -> transaction -> handlers

                o.AddPipelineForLogging(cfg =>
                {
                    cfg.Level = LogEventLevel.Verbose;
                    // will also serialize command results as JSON into the log
                    cfg.LogCommandResult = false;
                    cfg.LogQueryResult = false;
                    cfg.LogQuery = false;
                    cfg.LogCommand = false;
                });
                o.AddPipelineForValidation(cfg =>
                {
                    // will search for IValidator<TCommand> from the container
                    // and will fail if something is invalid
                    cfg.ValidateCommand = true;
                });
                // searches for all IValidator<T> and adds them into the IServiceCollection
                o.AddValidatorsFromAssemblyOf<Startup>();

                // searches for all ICommandHandler, IQueryHandler and IEventHandler
                // and adds them into the IServiceCollection
                o.AddHandlersFromAssemblyOf<Startup>();
            });
            //services.AddCosmosDB();
            services.AddSwaggerDocs();
            services.AddSwaggerGen(c =>
            {
                c.OperationFilter<AddRequiredHeaderParameter>();
                c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
            });

            services.AddAutoMapper(typeof(AutoMapperProfile));


            // Kubernetes liveness 
            services.AddHealthChecks()
                 .AddCheck("self", () => HealthCheckResult.Healthy());

            //Kubernetes readiness
            services.AddSingleton<IUserClaimsProvider, UserClaimsProvider>();
            services.AddSingleton<IAbacService, AbacService>();

            services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.Configure<ApiEndpointsOptions>(options => Configuration.GetSection("APIBaseEndpoints").Bind(options));

            services.AddDwyerAbac(Configuration);

            services.Configure<AWSConfig>(options => Configuration.GetSection("AWSConfig").Bind(options));
            services.AddOptions<AuditConfig>()
        .Bind(Configuration.GetSection("AuditConfig"));
            if (_currentEnvironment.EnvironmentName != "Local")
            {
                services.AddStackExchangeRedisCache(options =>
                {
                    options.Configuration = Configuration["Redis:ConnectionString"];
                });
                services.Add(ServiceDescriptor.Singleton<IDistributedCache, RedisCache>());

                services.AddDbContext<DataContext>(options =>
                 options.UseNpgsql(Configuration["PostgreSqlDB:ConnectionSetting"], npgsqlOptions =>
                 {
                     npgsqlOptions.UseAwsIamAuthentication();
                 }));
                services.AddDefaultAWSOptions(new AWSOptions()
                {
                    Credentials = AssumeRoleWithWebIdentityCredentials.FromEnvironmentVariables(),
                    Region = RegionEndpoint.GetBySystemName(Configuration.GetValue<string>("AWSConfig:Region"))
                });
            }
            else
            {
                services.AddDbContext<DataContext>(options =>
                options.UseNpgsql(Configuration["PostgreSqlDB:ConnectionSetting"]));
                //services.AddDefaultAWSOptions(new AWSOptions()
                //{
                //    Region = RegionEndpoint.GetBySystemName(Configuration.GetValue<string>("AWSConfig:Region")),
                //    //Credentials = new GetTokenDetails(Configuration.GetValue<string>("AwsConfig:Access_Key"), Configuration.GetValue<string>("AwsConfig:Secret-Key"), Configuration.GetValue<string>("AwsConfig:Security-Token"))
                //});

            }

       
            services.AddAWSService<IAmazonEventBridge>();
            services.AddAWSService<IAmazonS3>();
            services.AddAWSS3Bucket();
            services.AddTransient<Service.WorkOrder.Repository.PostgreSQL.IWorkOrderRepository, Service.WorkOrder.Repository.PostgreSQL.WorkOrderRepository>();
            services.AddSingleton(serviceProvider =>
            {
                return Policy.Handle<Refit.ApiException>(x => x.StatusCode >= System.Net.HttpStatusCode.InternalServerError)
                .CircuitBreakerAsync(
                exceptionsAllowedBeforeBreaking: Convert.ToInt32(Configuration["CircuitBreakerPolicies:NoOfRequestsBeforeTripping"]),
                durationOfBreak: TimeSpan.FromSeconds(Convert.ToInt32(Configuration["CircuitBreakerPolicies:TripDurationInSec"]))
                );
            });

        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        /// <summary>
        /// Configures the specified application.
        /// </summary>
        /// <param name="app">The application.</param>
        /// <param name="env">The env.</param>
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            //app.Use(async (context, next) =>
            //{
            //    //context.Response.Headers.Add("X-Content-Type-Options", "nosniff");
            //    //context.Response.Headers.Add(
            //    //"Content-Security-Policy",
           
            //    //"font-src 'self'; " +
            //    //"style-src 'self'; " +
            //    //"frame-src 'self';" +
            //    //"connect-src 'self';"
            //    //);
            //    await next();
            //});
            app.UseNeighborly();

            app.UserCorrelationContextLogging();
            app.UseHttpsRedirection();
            app.UseApiResponseAndExceptionWrapper(new FormatterOptions
            {
                //UseApiProblemDetailsException = true
                UseCustomSchema = true,
                UseCustomExceptionFormat = true,
                ExcludePaths = new FormatterExcludePath[] {
                                new FormatterExcludePath("/public/.*|/public", ExcludeMode.Regex)
                }

            });

            //app.Use((context, next) =>
            //{
            //    context.Response.Headers.Add("Cache-Control", "public");
            //    return next();
            //});

            app.UseSwaggerDocs();

            app.UseRouting();
            app.UseCors();

            app.UseNeighborlyJwtParserForAzureB2C();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseSerilogEnricherMiddleware();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });

            app.UseHealthChecks("/health/live", new HealthCheckOptions
            {
                Predicate = r => r.Name.Contains("self")
            });

            app.UseHealthChecks("/health/ready", new HealthCheckOptions
            {
                Predicate = r => r.Tags.Contains("services")
            });

        }
    }
}
