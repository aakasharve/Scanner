﻿using Microsoft.EntityFrameworkCore;
using Neighborly.Chassis.Auth;
using Neighborly.Chassis.Mediator;
using Neighborly.Chassis.Repository.PostgreSQL;
using Neighborly.ModelConfiguration;
using Neighborly.Service.WorkOrder.Domain;

namespace Neighborly.Context
{
    /// <summary>
    /// Data Context
    /// </summary>
    public class DataContext : PostgreSqlDataContext
    {
        #region Constructor
        /// <summary>
        /// dbContextOptions
        /// </summary>
        private readonly DbContextOptions<DataContext> dbContextOptions;
        /// <summary>
        /// userClaimsProvider
        /// </summary>
        private readonly IUserClaimsProvider userClaimsProvider;

        /// <summary>
        /// mediator
        /// </summary>
        public readonly IMediator mediator;
        /// <summary>
        /// Data Context Constructor
        /// </summary>
        /// <param name="options"></param>
        public DataContext(DbContextOptions<DataContext> options, IUserClaimsProvider userClaimsProvider, IMediator mediator) : base(options, userClaimsProvider, mediator)
        {
            this.dbContextOptions = options;
            this.userClaimsProvider = userClaimsProvider;
            this.mediator = mediator;
        }

        /// <summary>
        /// Clone
        /// </summary>
        /// <returns></returns>
        public DataContext Clone()
        {
            return new DataContext(dbContextOptions, userClaimsProvider, mediator);
        }

        #endregion

        #region DB Set

        /// <summary>
        /// Work Order
        /// </summary>
        public DbSet<WorkOrder> WorkOrder { get; set; } = default!;

        #endregion

        #region Overrides 
        /// <summary>
        /// On Model Creating
        /// </summary>
        /// <param name="modelBuilder"></param>
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new WorkOrderConfiguration());
        }

        #endregion

    }
}
